
create or replace function public.task_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare lbl text;
begin
  if tg_op = 'INSERT' then
    perform public.log_activity('task', new.id, new.team_id, 'created', 'created task "' || new.title || '"');
    if new.assignee_id is not null then
      perform public.log_activity('task', new.id, new.team_id, 'assigned', 'assigned "' || new.title || '"', jsonb_build_object('assignee_id', new.assignee_id));
      perform public.notify(new.assignee_id, 'assignment', null, 'New task assigned', new.title, '/tasks/' || new.id);
    end if;
    return new;
  end if;
  if new.assignee_id is distinct from old.assignee_id and new.assignee_id is not null then
    perform public.log_activity('task', new.id, new.team_id, 'assigned', 'reassigned "' || new.title || '"', jsonb_build_object('assignee_id', new.assignee_id));
    perform public.notify(new.assignee_id, 'assignment', null, 'New task assigned', new.title, '/tasks/' || new.id);
  end if;
  if new.status is distinct from old.status then
    lbl := replace(new.status::text, '_', ' ');
    if new.status = 'completed' then
      perform public.log_activity('task', new.id, new.team_id, 'approved', 'marked "' || new.title || '" completed');
    else
      perform public.log_activity('task', new.id, new.team_id, 'status_changed', 'changed "' || new.title || '" to ' || lbl, jsonb_build_object('from', old.status, 'to', new.status));
    end if;
    perform public.notify(new.assignee_id, 'status', 'status_changes', 'Task status: ' || lbl, new.title, '/tasks/' || new.id);
  end if;
  if new.awaiting_review and not old.awaiting_review then
    perform public.log_activity('task', new.id, new.team_id, 'submitted', 'submitted "' || new.title || '" for review');
    if exists (select 1 from public.team_members m where m.team_id = new.team_id and m.is_lead) then
      perform public.notify(m.user_id, 'review', null, 'Task submitted for review', new.title, '/tasks/' || new.id)
        from public.team_members m where m.team_id = new.team_id and m.is_lead;
    else
      perform public.notify(r.user_id, 'review', null, 'Task submitted for review', new.title, '/tasks/' || new.id)
        from (select distinct ur.user_id from public.user_roles ur join public.profiles p on p.id = ur.user_id where p.status = 'active') r;
    end if;
  end if;
  if new.feedback is distinct from old.feedback and coalesce(new.feedback, '') <> '' then
    perform public.log_activity('task', new.id, new.team_id, 'feedback', 'left feedback on "' || new.title || '"');
    perform public.notify(new.assignee_id, 'feedback', null, 'Feedback on your task', new.title, '/tasks/' || new.id);
  end if;
  if new.due_date is distinct from old.due_date then
    perform public.log_activity('task', new.id, new.team_id, 'deadline_changed', 'changed the deadline of "' || new.title || '"', jsonb_build_object('from', old.due_date, 'to', new.due_date));
  end if;
  return new;
end $$;
