create table public.signup_invitations (id uuid primary key default gen_random_uuid(), token_hash text not null unique, created_by uuid not null references public.profiles(id), expires_at timestamptz not null default now() + interval '7 days', used_by uuid references public.profiles(id), used_at timestamptz, revoked boolean not null default false, created_at timestamptz not null default now());
grant select, update on public.signup_invitations to authenticated;
grant all on public.signup_invitations to service_role;
alter table public.signup_invitations enable row level security;
create policy invitations_admin_read on public.signup_invitations for select to authenticated using(public.is_admin(auth.uid()));
create policy invitations_admin_revoke on public.signup_invitations for update to authenticated using(public.is_admin(auth.uid())) with check(public.is_admin(auth.uid()));
create table public.assignment_requests (user_id uuid primary key references public.profiles(id) on delete cascade, status text not null default 'pending' check(status in ('pending','approved','rejected')), requested_at timestamptz not null default now(), resolved_at timestamptz, resolved_by uuid references public.profiles(id));
grant select on public.assignment_requests to authenticated;
grant all on public.assignment_requests to service_role;
alter table public.assignment_requests enable row level security;
create policy requests_self_admin_read on public.assignment_requests for select to authenticated using(user_id = auth.uid() or public.is_admin(auth.uid()));
create or replace function public.create_signup_invitation() returns text language plpgsql security definer set search_path=public as $$ declare token text; begin
if not public.is_admin(auth.uid()) then raise exception 'Only administrators can create invitations'; end if;
token := replace(gen_random_uuid()::text,'-','') || replace(gen_random_uuid()::text,'-','');
insert into public.signup_invitations(token_hash,created_by) values(encode(sha256(convert_to(token,'UTF8')),'hex'),auth.uid());
perform public.log_activity('invitation',null,null,'created','created a signup invitation'); return token; end $$;
revoke all on function public.create_signup_invitation() from public,anon; grant execute on function public.create_signup_invitation() to authenticated;
create or replace function public.valid_signup_invitation(_token text) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.signup_invitations where token_hash=encode(sha256(convert_to(_token,'UTF8')),'hex') and expires_at>now() and used_at is null and not revoked) $$;
revoke all on function public.valid_signup_invitation(text) from public; grant execute on function public.valid_signup_invitation(text) to anon,authenticated;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ declare invitation uuid; token text; begin
 token := new.raw_user_meta_data->>'invitation_token';
 if token is not null then
 select id into invitation from public.signup_invitations where token_hash=encode(sha256(convert_to(token,'UTF8')),'hex') and expires_at>now() and used_at is null and not revoked for update;
 if invitation is null then raise exception 'Invitation is invalid or expired'; end if;
 end if;
 insert into public.profiles(id,full_name,status) values(new.id,coalesce(nullif(new.raw_user_meta_data->>'full_name',''),split_part(new.email,'@',1)),'pending') on conflict(id) do nothing;
 insert into public.profile_private(user_id,email,phone) values(new.id,lower(new.email),left(new.raw_user_meta_data->>'phone',50)) on conflict(user_id) do nothing;
 if invitation is not null then update public.signup_invitations set used_by=new.id,used_at=now() where id=invitation; end if;
 if new.email_confirmed_at is not null then perform public.claim_owner_if_eligible(new.id,new.email); end if; return new; end $$;
create or replace function public.request_team_assignment(_full_name text,_phone text) returns void language plpgsql security definer set search_path=public as $$ declare uid uuid:=auth.uid(); begin
if uid is null or not exists(select 1 from public.profiles where id=uid and status<>'deactivated') then raise exception 'Sign in to request access'; end if;
if not exists(select 1 from auth.users where id=uid and email_confirmed_at is not null) then raise exception 'Confirm your email first'; end if;
if length(trim(_full_name)) not between 1 and 200 or length(trim(_phone)) not between 3 and 50 then raise exception 'Enter your full name and phone number'; end if;
if exists(select 1 from public.assignment_requests where user_id=uid and status='pending') then return; end if;
update public.profiles set full_name=trim(_full_name) where id=uid;
update public.profile_private set phone=trim(_phone) where user_id=uid;
insert into public.assignment_requests(user_id) values(uid) on conflict(user_id) do update set status='pending',requested_at=now(),resolved_at=null,resolved_by=null;
perform public.notify(r.user_id,'access_request',null,'Team assignment requested',trim(_full_name),'/admin/members') from public.user_roles r where public.is_admin(r.user_id);
perform public.log_activity('user',uid,null,'access_requested','requested team assignment'); end $$;
revoke all on function public.request_team_assignment(text,text) from public,anon; grant execute on function public.request_team_assignment(text,text) to authenticated;
create or replace function public.approve_assignment_request(_target uuid,_teams uuid[],_coadmin boolean default false) returns void language plpgsql security definer set search_path=public as $$ declare tid uuid; begin
if not public.is_admin(auth.uid()) then raise exception 'Only administrators can approve requests'; end if;
if _coadmin and not public.is_owner(auth.uid()) then raise exception 'Only the Primary Owner can grant Co-Administrator access'; end if;
if cardinality(_teams)=0 and not _coadmin then raise exception 'Choose at least one team or Co-Administrator access'; end if;
if not exists(select 1 from public.assignment_requests where user_id=_target and status='pending' for update) then raise exception 'No pending request'; end if;
if exists(select 1 from public.teams where id=any(_teams) and archived) then raise exception 'Choose active teams'; end if;
perform public.set_account_status(_target,'active');
foreach tid in array _teams loop perform public.set_team_membership(tid,_target,true,false); end loop;
if _coadmin then perform public.set_admin_role(_target,true); end if;
update public.assignment_requests set status='approved',resolved_at=now(),resolved_by=auth.uid() where user_id=_target;
perform public.notify(_target,'access_approved',null,'Your portal access is ready',null,'/dashboard'); end $$;
revoke all on function public.approve_assignment_request(uuid,uuid[],boolean) from public,anon; grant execute on function public.approve_assignment_request(uuid,uuid[],boolean) to authenticated;
create policy tasks_member_self_insert on public.tasks for insert to authenticated with check(public.is_team_member(auth.uid(),team_id) and assignee_id=auth.uid() and created_by=auth.uid() and status<>'completed' and completed_at is null and feedback is null);
create or replace function public.guard_task_creation() returns trigger language plpgsql security definer set search_path=public as $$ begin
if auth.uid() is not null then
if new.created_by is distinct from auth.uid() then raise exception 'Task creator must be the signed-in user'; end if;
if not public.can_manage_team(auth.uid(),new.team_id) and (not public.is_team_member(auth.uid(),new.team_id) or new.assignee_id is distinct from auth.uid() or new.status='completed' or new.completed_at is not null or new.feedback is not null) then raise exception 'Volunteers can create tasks assigned only to themselves and must submit completion for review'; end if;
end if; return new; end $$;
create trigger guard_task_creation before insert on public.tasks for each row execute function public.guard_task_creation();
create or replace function public.handle_user_confirmed() returns trigger language plpgsql security definer set search_path=public as $$ begin
if new.email_confirmed_at is not null and old.email_confirmed_at is null then perform public.claim_owner_if_eligible(new.id,new.email); end if;
if new.email is distinct from old.email then update public.profile_private set email=lower(new.email) where user_id=new.id; end if; return new; end $$;
create or replace function public.guard_private_fields() returns trigger language plpgsql security definer set search_path=public as $$ begin
if auth.uid() is not null and new.email is distinct from old.email and not exists(select 1 from auth.users where id=new.user_id and lower(email)=new.email and email_confirmed_at is not null) then new.email:=old.email; end if;
new.updated_at:=now(); return new; end $$;