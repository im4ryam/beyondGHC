
create policy "admin profiles visible to active users" on public.profiles for select to authenticated
  using (public.is_active(auth.uid()) and exists (select 1 from public.user_roles r where r.user_id = profiles.id));
