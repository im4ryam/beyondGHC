
-- ============ ENUMS ============
create type public.app_role as enum ('owner', 'admin');
create type public.account_status as enum ('pending', 'active', 'deactivated');
create type public.task_status as enum ('incomplete', 'in_progress', 'revised', 'completed');
create type public.priority_level as enum ('low', 'medium', 'high', 'urgent');
create type public.project_status as enum ('planning', 'active', 'on_hold', 'completed', 'archived');
create type public.submission_status as enum ('new', 'reviewing', 'approved', 'converted', 'rejected', 'archived');
create type public.event_kind as enum ('event', 'meeting', 'milestone', 'deadline');
create type public.resource_category as enum ('templates', 'guidelines', 'forms', 'training', 'reference', 'shared_folders', 'links');
create type public.dataset_kind as enum ('member_contacts', 'speaker_pipeline', 'volunteer_pipeline', 'public_member_info');

-- ============ PROFILES ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  linkedin_url text,
  timezone text not null default 'America/New_York',
  availability text,
  monthly_hours integer,
  bio text,
  status public.account_status not null default 'pending',
  onboarded boolean not null default false,
  joined_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.profile_private (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  email text not null,
  phone text,
  notification_prefs jsonb not null default '{"announcements": true, "comments": true, "project_updates": true, "status_changes": true}'::jsonb,
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profile_private to authenticated;
grant all on public.profile_private to service_role;
alter table public.profile_private enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create unique index one_primary_owner on public.user_roles ((role)) where role = 'owner';

-- ============ TEAMS ============
create table public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  objectives text,
  color text not null default 'blue',
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.teams to authenticated;
grant all on public.teams to service_role;
alter table public.teams enable row level security;

create table public.team_members (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  is_lead boolean not null default false,
  created_at timestamptz not null default now(),
  unique (team_id, user_id)
);
grant select, insert, update, delete on public.team_members to authenticated;
grant all on public.team_members to service_role;
alter table public.team_members enable row level security;

create table public.team_dataset_access (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  dataset public.dataset_kind not null,
  leads_only boolean not null default true,
  created_at timestamptz not null default now(),
  unique (team_id, dataset)
);
grant select, insert, update, delete on public.team_dataset_access to authenticated;
grant all on public.team_dataset_access to service_role;
alter table public.team_dataset_access enable row level security;

-- ============ HELPER FUNCTIONS ============
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_owner(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _uid and role = 'owner')
$$;

create or replace function public.is_active(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = _uid and status = 'active')
$$;

create or replace function public.is_admin(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_active(_uid) and exists (select 1 from public.user_roles where user_id = _uid and role in ('owner','admin'))
$$;

create or replace function public.is_team_member(_uid uuid, _team uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_active(_uid) and exists (select 1 from public.team_members where user_id = _uid and team_id = _team)
$$;

create or replace function public.is_team_lead(_uid uuid, _team uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_active(_uid) and exists (select 1 from public.team_members where user_id = _uid and team_id = _team and is_lead)
$$;

create or replace function public.can_manage_team(_uid uuid, _team uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin(_uid) or public.is_team_lead(_uid, _team)
$$;

create or replace function public.can_view_team(_uid uuid, _team uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin(_uid) or public.is_team_member(_uid, _team)
$$;

create or replace function public.shares_team(_uid uuid, _other uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_active(_uid) and exists (
    select 1 from public.team_members a join public.team_members b on a.team_id = b.team_id
    where a.user_id = _uid and b.user_id = _other)
$$;

create or replace function public.leads_team_of(_uid uuid, _other uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_active(_uid) and exists (
    select 1 from public.team_members a join public.team_members b on a.team_id = b.team_id
    where a.user_id = _uid and a.is_lead and b.user_id = _other)
$$;

create or replace function public.has_dataset(_uid uuid, _ds public.dataset_kind)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin(_uid) or (public.is_active(_uid) and exists (
    select 1 from public.team_dataset_access d join public.team_members m on m.team_id = d.team_id
    where m.user_id = _uid and d.dataset = _ds and (not d.leads_only or m.is_lead)))
$$;

-- ============ PROFILE POLICIES ============
create policy "profiles readable by self, admins, teammates" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin(auth.uid()) or public.shares_team(auth.uid(), id));
create policy "profiles self update" on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin(auth.uid())) with check (id = auth.uid() or public.is_admin(auth.uid()));

create policy "private readable by self, admins, leads, own lead" on public.profile_private for select to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid()) or public.leads_team_of(auth.uid(), user_id) or (public.is_active(auth.uid()) and public.leads_team_of(user_id, auth.uid())));
create policy "private self update" on public.profile_private for update to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid())) with check (user_id = auth.uid() or public.is_admin(auth.uid()));

create policy "roles readable" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.is_active(auth.uid()));

create or replace function public.guard_profile_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then new.updated_at := now(); return new; end if;
  if not public.is_admin(auth.uid()) then
    new.status := old.status;
    new.joined_at := old.joined_at;
  end if;
  if new.status <> old.status and public.is_owner(new.id) then
    raise exception 'The Primary Owner account cannot be deactivated';
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger guard_profile_fields before update on public.profiles for each row execute function public.guard_profile_fields();

create or replace function public.guard_private_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null then new.email := old.email; end if;
  new.updated_at := now();
  return new;
end $$;
create trigger guard_private_fields before update on public.profile_private for each row execute function public.guard_private_fields();

-- ============ TEAM POLICIES ============
create policy "teams visible to active users" on public.teams for select to authenticated using (public.is_active(auth.uid()));
create policy "teams admin insert" on public.teams for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "teams admin or lead update" on public.teams for update to authenticated using (public.can_manage_team(auth.uid(), id)) with check (public.can_manage_team(auth.uid(), id));
create policy "teams admin delete" on public.teams for delete to authenticated using (public.is_admin(auth.uid()));

create or replace function public.guard_team_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin(auth.uid()) then
    new.name := old.name; new.archived := old.archived; new.color := old.color;
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger guard_team_fields before update on public.teams for each row execute function public.guard_team_fields();

create policy "members visible to team and admins" on public.team_members for select to authenticated
  using (public.can_view_team(auth.uid(), team_id) or user_id = auth.uid());
create policy "members admin insert" on public.team_members for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "members admin update" on public.team_members for update to authenticated using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));
create policy "members admin delete" on public.team_members for delete to authenticated using (public.is_admin(auth.uid()));

create policy "dataset access readable" on public.team_dataset_access for select to authenticated using (public.can_view_team(auth.uid(), team_id));
create policy "dataset access admin insert" on public.team_dataset_access for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "dataset access admin update" on public.team_dataset_access for update to authenticated using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));
create policy "dataset access admin delete" on public.team_dataset_access for delete to authenticated using (public.is_admin(auth.uid()));

-- ============ PROJECTS & TASKS ============
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  title text not null,
  description text,
  status public.project_status not null default 'active',
  priority public.priority_level not null default 'medium',
  due_date date,
  created_by uuid references public.profiles(id) on delete set null,
  completed_at timestamptz,
  completed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.projects to authenticated;
grant all on public.projects to service_role;
alter table public.projects enable row level security;
create policy "projects visible to team" on public.projects for select to authenticated using (public.can_view_team(auth.uid(), team_id));
create policy "projects lead insert" on public.projects for insert to authenticated with check (public.can_manage_team(auth.uid(), team_id));
create policy "projects lead update" on public.projects for update to authenticated using (public.can_manage_team(auth.uid(), team_id)) with check (public.can_manage_team(auth.uid(), team_id));
create policy "projects admin delete" on public.projects for delete to authenticated using (public.is_admin(auth.uid()));

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  assignee_id uuid references public.profiles(id) on delete set null,
  title text not null,
  description text,
  instructions text,
  status public.task_status not null default 'incomplete',
  priority public.priority_level not null default 'medium',
  due_date timestamptz,
  resource_links jsonb not null default '[]'::jsonb,
  awaiting_review boolean not null default false,
  feedback text,
  created_by uuid references public.profiles(id) on delete set null,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index tasks_assignee_idx on public.tasks(assignee_id);
create index tasks_team_idx on public.tasks(team_id);
create index tasks_project_idx on public.tasks(project_id);
grant select, insert, update, delete on public.tasks to authenticated;
grant all on public.tasks to service_role;
alter table public.tasks enable row level security;
create policy "tasks visible to team" on public.tasks for select to authenticated using (public.can_view_team(auth.uid(), team_id) or assignee_id = auth.uid());
create policy "tasks lead insert" on public.tasks for insert to authenticated with check (public.can_manage_team(auth.uid(), team_id));
create policy "tasks lead or assignee update" on public.tasks for update to authenticated
  using (public.can_manage_team(auth.uid(), team_id) or (assignee_id = auth.uid() and public.is_active(auth.uid())))
  with check (public.can_manage_team(auth.uid(), team_id) or (assignee_id = auth.uid() and public.is_active(auth.uid())));
create policy "tasks lead delete" on public.tasks for delete to authenticated using (public.can_manage_team(auth.uid(), team_id));

create or replace function public.guard_task_fields()
returns trigger language plpgsql security definer set search_path = public as $$
declare manager boolean;
begin
  if new.project_id is not null and not exists (select 1 from public.projects where id = new.project_id and team_id = new.team_id) then
    raise exception 'Project belongs to a different team';
  end if;
  if new.assignee_id is not null and (tg_op = 'INSERT' or new.assignee_id is distinct from old.assignee_id or new.team_id is distinct from old.team_id)
     and not exists (select 1 from public.team_members where team_id = new.team_id and user_id = new.assignee_id) then
    raise exception 'Assignee must be a member of the task''s team';
  end if;
  if tg_op = 'UPDATE' then
    manager := auth.uid() is null or public.can_manage_team(auth.uid(), old.team_id);
    if not manager then
      if new.status = 'completed' and old.status <> 'completed' then
        raise exception 'Only a team lead or admin can mark a task completed. Submit it for review instead.';
      end if;
      new.title := old.title; new.description := old.description; new.instructions := old.instructions;
      new.team_id := old.team_id; new.project_id := old.project_id; new.assignee_id := old.assignee_id;
      new.priority := old.priority; new.due_date := old.due_date; new.resource_links := old.resource_links;
      new.feedback := old.feedback; new.created_by := old.created_by; new.created_at := old.created_at;
    end if;
    if new.status = 'completed' and old.status <> 'completed' then
      new.completed_at := now(); new.awaiting_review := false;
    elsif new.status <> 'completed' then
      new.completed_at := null;
    end if;
    new.updated_at := now();
  else
    if new.status = 'completed' then new.completed_at := now(); end if;
  end if;
  return new;
end $$;
create trigger guard_task_fields before insert or update on public.tasks for each row execute function public.guard_task_fields();

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at := now(); return new; end $$;
create trigger projects_touch before update on public.projects for each row execute function public.touch_updated_at();

-- ============ COMMENTS ============
create table public.task_comments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.task_comments(id) on delete cascade,
  kind text not null default 'comment' check (kind in ('comment','update','question','feedback')),
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);
grant select, insert, delete on public.task_comments to authenticated;
grant all on public.task_comments to service_role;
alter table public.task_comments enable row level security;
create or replace function public.can_view_task(_uid uuid, _task uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.tasks t where t.id = _task and (public.can_view_team(_uid, t.team_id) or t.assignee_id = _uid))
$$;
create policy "comments visible with task" on public.task_comments for select to authenticated using (public.can_view_task(auth.uid(), task_id));
create policy "comments insert own" on public.task_comments for insert to authenticated with check (author_id = auth.uid() and public.is_active(auth.uid()) and public.can_view_task(auth.uid(), task_id));
create policy "comments delete own or admin" on public.task_comments for delete to authenticated using (author_id = auth.uid() or public.is_admin(auth.uid()));

-- ============ ACTIVITY LOG ============
create table public.activity_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  entity_type text not null,
  entity_id uuid,
  team_id uuid references public.teams(id) on delete set null,
  action text not null,
  summary text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index activity_entity_idx on public.activity_log(entity_type, entity_id);
create index activity_created_idx on public.activity_log(created_at desc);
grant select on public.activity_log to authenticated;
grant all on public.activity_log to service_role;
alter table public.activity_log enable row level security;
create policy "activity visible" on public.activity_log for select to authenticated
  using (public.is_admin(auth.uid()) or (team_id is not null and public.is_team_member(auth.uid(), team_id)) or actor_id = auth.uid());

create or replace function public.log_activity(_entity text, _entity_id uuid, _team uuid, _action text, _summary text, _details jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.activity_log(actor_id, entity_type, entity_id, team_id, action, summary, details)
  values (auth.uid(), _entity, _entity_id, _team, _action, _summary, coalesce(_details, '{}'::jsonb));
$$;
revoke execute on function public.log_activity(text, uuid, uuid, text, text, jsonb) from public, anon, authenticated;

-- ============ NOTIFICATIONS ============
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null,
  title text not null,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);
grant select, update, delete on public.notifications to authenticated;
grant all on public.notifications to service_role;
alter table public.notifications enable row level security;
create policy "own notifications" on public.notifications for select to authenticated using (user_id = auth.uid());
create policy "own notifications update" on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own notifications delete" on public.notifications for delete to authenticated using (user_id = auth.uid());

create or replace function public.notify(_user uuid, _kind text, _pref text, _title text, _body text, _link text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if _user is null or _user = auth.uid() then return; end if;
  if _pref is not null and exists (select 1 from public.profile_private where user_id = _user and coalesce((notification_prefs->>_pref)::boolean, true) = false) then
    return;
  end if;
  insert into public.notifications(user_id, kind, title, body, link) values (_user, _kind, _title, _body, _link);
end $$;
revoke execute on function public.notify(uuid, text, text, text, text, text) from public, anon, authenticated;

create or replace function public.task_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare lbl text;
begin
  if tg_op = 'INSERT' then
    perform public.log_activity('task', new.id, new.team_id, 'created', 'created task "' || new.title || '"');
    if new.assignee_id is not null then
      perform public.log_activity('task', new.id, new.team_id, 'assigned', 'assigned "' || new.title || '"', jsonb_build_object('assignee_id', new.assignee_id));
      perform public.notify(new.assignee_id, 'assignment', null, 'New task assigned', new.title, '/tasks/' || new.id);
    end if;
    return new;
  end if;
  if new.assignee_id is distinct from old.assignee_id and new.assignee_id is not null then
    perform public.log_activity('task', new.id, new.team_id, 'assigned', 'reassigned "' || new.title || '"', jsonb_build_object('assignee_id', new.assignee_id));
    perform public.notify(new.assignee_id, 'assignment', null, 'New task assigned', new.title, '/tasks/' || new.id);
  end if;
  if new.status is distinct from old.status then
    lbl := replace(new.status::text, '_', ' ');
    if new.status = 'completed' then
      perform public.log_activity('task', new.id, new.team_id, 'approved', 'marked "' || new.title || '" completed');
    else
      perform public.log_activity('task', new.id, new.team_id, 'status_changed', 'changed "' || new.title || '" to ' || lbl, jsonb_build_object('from', old.status, 'to', new.status));
    end if;
    perform public.notify(new.assignee_id, 'status', 'status_changes', 'Task status: ' || lbl, new.title, '/tasks/' || new.id);
  end if;
  if new.awaiting_review and not old.awaiting_review then
    perform public.log_activity('task', new.id, new.team_id, 'submitted', 'submitted "' || new.title || '" for review');
    perform public.notify(m.user_id, 'review', null, 'Task submitted for review', new.title, '/tasks/' || new.id)
      from public.team_members m where m.team_id = new.team_id and m.is_lead;
  end if;
  if new.feedback is distinct from old.feedback and coalesce(new.feedback, '') <> '' then
    perform public.log_activity('task', new.id, new.team_id, 'feedback', 'left feedback on "' || new.title || '"');
    perform public.notify(new.assignee_id, 'feedback', null, 'Feedback on your task', new.title, '/tasks/' || new.id);
  end if;
  if new.due_date is distinct from old.due_date then
    perform public.log_activity('task', new.id, new.team_id, 'deadline_changed', 'changed the deadline of "' || new.title || '"', jsonb_build_object('from', old.due_date, 'to', new.due_date));
  end if;
  return new;
end $$;
create trigger task_after_change after insert or update on public.tasks for each row execute function public.task_after_change();

create or replace function public.comment_after_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare t record;
begin
  select * into t from public.tasks where id = new.task_id;
  perform public.log_activity('task', t.id, t.team_id, 'commented', 'commented on "' || t.title || '"');
  perform public.notify(t.assignee_id, 'comment', 'comments', 'New comment on your task', t.title, '/tasks/' || t.id);
  if t.created_by is distinct from t.assignee_id then
    perform public.notify(t.created_by, 'comment', 'comments', 'New comment on a task you created', t.title, '/tasks/' || t.id);
  end if;
  return new;
end $$;
create trigger comment_after_insert after insert on public.task_comments for each row execute function public.comment_after_insert();

create or replace function public.project_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    perform public.log_activity('project', new.id, new.team_id, 'created', 'created project "' || new.title || '"');
  elsif new.status is distinct from old.status then
    perform public.log_activity('project', new.id, new.team_id, 'status_changed', 'set project "' || new.title || '" to ' || replace(new.status::text,'_',' '));
    perform public.notify(m.user_id, 'project', 'project_updates', 'Project ' || replace(new.status::text,'_',' '), new.title, '/projects/' || new.id)
      from public.team_members m where m.team_id = new.team_id;
  elsif new.title is distinct from old.title or new.description is distinct from old.description or new.due_date is distinct from old.due_date or new.priority is distinct from old.priority then
    perform public.log_activity('project', new.id, new.team_id, 'updated', 'updated project "' || new.title || '"');
  end if;
  return new;
end $$;
create trigger project_after_change after insert or update on public.projects for each row execute function public.project_after_change();

-- ============ RESOURCES / ANNOUNCEMENTS / EVENTS ============
create table public.resources (
  id uuid primary key default gen_random_uuid(),
  team_id uuid references public.teams(id) on delete cascade,
  title text not null,
  description text,
  category public.resource_category not null default 'links',
  url text not null,
  requires_access boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.resources to authenticated;
grant all on public.resources to service_role;
alter table public.resources enable row level security;
create policy "resources visible" on public.resources for select to authenticated
  using ((team_id is null and public.is_active(auth.uid())) or (team_id is not null and public.can_view_team(auth.uid(), team_id)));
create policy "resources insert" on public.resources for insert to authenticated
  with check ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create policy "resources update" on public.resources for update to authenticated
  using ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)))
  with check ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create policy "resources delete" on public.resources for delete to authenticated
  using ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create trigger resources_touch before update on public.resources for each row execute function public.touch_updated_at();

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  team_id uuid references public.teams(id) on delete cascade,
  title text not null,
  body text not null,
  link text,
  pinned boolean not null default false,
  author_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.announcements to authenticated;
grant all on public.announcements to service_role;
alter table public.announcements enable row level security;
create policy "announcements visible" on public.announcements for select to authenticated
  using ((team_id is null and public.is_active(auth.uid())) or (team_id is not null and public.can_view_team(auth.uid(), team_id)));
create policy "announcements insert" on public.announcements for insert to authenticated
  with check (author_id = auth.uid() and ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id))));
create policy "announcements update" on public.announcements for update to authenticated
  using ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)))
  with check ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create policy "announcements delete" on public.announcements for delete to authenticated
  using ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create trigger announcements_touch before update on public.announcements for each row execute function public.touch_updated_at();

create or replace function public.announcement_after_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.log_activity('announcement', new.id, new.team_id, 'posted', 'posted announcement "' || new.title || '"');
  if new.team_id is null then
    perform public.notify(p.id, 'announcement', 'announcements', 'New announcement', new.title, '/announcements') from public.profiles p where p.status = 'active';
  else
    perform public.notify(m.user_id, 'announcement', 'announcements', 'New team announcement', new.title, '/announcements') from public.team_members m where m.team_id = new.team_id;
  end if;
  return new;
end $$;
create trigger announcement_after_insert after insert on public.announcements for each row execute function public.announcement_after_insert();

create table public.events (
  id uuid primary key default gen_random_uuid(),
  team_id uuid references public.teams(id) on delete cascade,
  title text not null,
  description text,
  kind public.event_kind not null default 'event',
  starts_at timestamptz not null,
  ends_at timestamptz,
  location text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.events to authenticated;
grant all on public.events to service_role;
alter table public.events enable row level security;
create policy "events visible" on public.events for select to authenticated
  using ((team_id is null and public.is_active(auth.uid())) or (team_id is not null and public.can_view_team(auth.uid(), team_id)));
create policy "events insert" on public.events for insert to authenticated
  with check ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create policy "events update" on public.events for update to authenticated
  using ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)))
  with check ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));
create policy "events delete" on public.events for delete to authenticated
  using ((team_id is null and public.is_admin(auth.uid())) or (team_id is not null and public.can_manage_team(auth.uid(), team_id)));

-- ============ INTEREST FORM SUBMISSIONS ============
create table public.interest_submissions (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  full_name text not null default '',
  phone text,
  linkedin_url text,
  background text,
  ghc_connection text,
  timezone text,
  participation text,
  topics text,
  formats text,
  community_spaces text,
  availability text,
  platform_pref text,
  volunteer_interest boolean not null default false,
  volunteer_areas text,
  preferred_team text,
  volunteer_experience text,
  speaker_interest boolean not null default false,
  proposed_topics text,
  comments text,
  status public.submission_status not null default 'new',
  speaker_status text not null default 'not_contacted',
  admin_notes text,
  public_bio text,
  public_approved boolean not null default false,
  profile_id uuid references public.profiles(id) on delete set null,
  source text not null default 'import',
  external_id text,
  submitted_at timestamptz not null default now(),
  submission_count integer not null default 1,
  history jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index interest_email_unique on public.interest_submissions (lower(email));
grant select, insert, update, delete on public.interest_submissions to authenticated;
grant all on public.interest_submissions to service_role;
alter table public.interest_submissions enable row level security;
create policy "submissions visible to authorized" on public.interest_submissions for select to authenticated
  using (
    public.is_admin(auth.uid())
    or public.has_dataset(auth.uid(), 'member_contacts')
    or (speaker_interest and public.has_dataset(auth.uid(), 'speaker_pipeline'))
    or (volunteer_interest and public.has_dataset(auth.uid(), 'volunteer_pipeline'))
  );
create policy "submissions admin insert" on public.interest_submissions for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "submissions update" on public.interest_submissions for update to authenticated
  using (public.is_admin(auth.uid()) or (speaker_interest and public.has_dataset(auth.uid(), 'speaker_pipeline')))
  with check (public.is_admin(auth.uid()) or (speaker_interest and public.has_dataset(auth.uid(), 'speaker_pipeline')));
create policy "submissions admin delete" on public.interest_submissions for delete to authenticated using (public.is_admin(auth.uid()));

create or replace function public.guard_submission_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin(auth.uid()) then
    new := jsonb_populate_record(new, (to_jsonb(old) - 'speaker_status' - 'admin_notes'));
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger guard_submission_fields before update on public.interest_submissions for each row execute function public.guard_submission_fields();

create or replace function public.public_member_info()
returns table (id uuid, full_name text, linkedin_url text, public_bio text, proposed_topics text, speaker_interest boolean)
language sql stable security definer set search_path = public as $$
  select s.id, s.full_name, s.linkedin_url, s.public_bio, case when s.speaker_interest then s.proposed_topics end, s.speaker_interest
  from public.interest_submissions s
  where s.public_approved and public.has_dataset(auth.uid(), 'public_member_info')
  order by s.full_name
$$;

-- ============ INTEGRATION SETTINGS ============
create table public.integration_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.integration_settings to authenticated;
grant all on public.integration_settings to service_role;
alter table public.integration_settings enable row level security;
create policy "settings admin read" on public.integration_settings for select to authenticated using (public.is_admin(auth.uid()));
create policy "settings admin insert" on public.integration_settings for insert to authenticated with check (public.is_admin(auth.uid()) and key <> 'primary_owner');
create policy "settings admin update" on public.integration_settings for update to authenticated using (public.is_admin(auth.uid()) and key <> 'primary_owner') with check (public.is_admin(auth.uid()) and key <> 'primary_owner');
create policy "settings admin delete" on public.integration_settings for delete to authenticated using (public.is_admin(auth.uid()) and key not in ('primary_owner','organization'));

create or replace function public.organization_name()
returns text language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'name' from public.integration_settings where key = 'organization'), 'Beyond GHC')
$$;
grant execute on function public.organization_name() to anon, authenticated;

-- ============ IMPORT RPC (dedupe by email) ============
create or replace function public.upsert_submission(_row jsonb, _source text)
returns text language plpgsql security definer set search_path = public as $$
declare existing public.interest_submissions; em text; ts timestamptz;
begin
  em := lower(trim(coalesce(_row->>'email','')));
  if em = '' or position('@' in em) = 0 then return 'skipped'; end if;
  begin
    ts := coalesce(nullif(_row->>'submitted_at','')::timestamptz, now());
  exception when others then ts := now();
  end;
  select * into existing from public.interest_submissions where lower(email) = em;
  if existing.id is null then
    insert into public.interest_submissions(email, full_name, phone, linkedin_url, background, ghc_connection, timezone, participation, topics, formats,
      community_spaces, availability, platform_pref, volunteer_interest, volunteer_areas, preferred_team, volunteer_experience, speaker_interest,
      proposed_topics, comments, source, external_id, submitted_at, history)
    values (em, coalesce(_row->>'full_name',''), _row->>'phone', _row->>'linkedin_url', _row->>'background', _row->>'ghc_connection', _row->>'timezone',
      _row->>'participation', _row->>'topics', _row->>'formats', _row->>'community_spaces', _row->>'availability', _row->>'platform_pref',
      coalesce((_row->>'volunteer_interest')::boolean, false), _row->>'volunteer_areas', _row->>'preferred_team', _row->>'volunteer_experience',
      coalesce((_row->>'speaker_interest')::boolean, false), _row->>'proposed_topics', _row->>'comments', _source, _row->>'external_id', ts,
      jsonb_build_array(jsonb_build_object('received_at', now(), 'submitted_at', ts, 'source', _source, 'data', _row)));
    return 'inserted';
  end if;
  if exists (select 1 from jsonb_array_elements(existing.history) h where (h->>'submitted_at')::timestamptz = ts) then
    return 'duplicate';
  end if;
  update public.interest_submissions set
    full_name = coalesce(nullif(_row->>'full_name',''), full_name),
    phone = coalesce(nullif(_row->>'phone',''), phone),
    linkedin_url = coalesce(nullif(_row->>'linkedin_url',''), linkedin_url),
    background = coalesce(nullif(_row->>'background',''), background),
    ghc_connection = coalesce(nullif(_row->>'ghc_connection',''), ghc_connection),
    timezone = coalesce(nullif(_row->>'timezone',''), timezone),
    participation = coalesce(nullif(_row->>'participation',''), participation),
    topics = coalesce(nullif(_row->>'topics',''), topics),
    formats = coalesce(nullif(_row->>'formats',''), formats),
    community_spaces = coalesce(nullif(_row->>'community_spaces',''), community_spaces),
    availability = coalesce(nullif(_row->>'availability',''), availability),
    platform_pref = coalesce(nullif(_row->>'platform_pref',''), platform_pref),
    volunteer_interest = volunteer_interest or coalesce((_row->>'volunteer_interest')::boolean, false),
    volunteer_areas = coalesce(nullif(_row->>'volunteer_areas',''), volunteer_areas),
    preferred_team = coalesce(nullif(_row->>'preferred_team',''), preferred_team),
    volunteer_experience = coalesce(nullif(_row->>'volunteer_experience',''), volunteer_experience),
    speaker_interest = speaker_interest or coalesce((_row->>'speaker_interest')::boolean, false),
    proposed_topics = coalesce(nullif(_row->>'proposed_topics',''), proposed_topics),
    comments = coalesce(nullif(_row->>'comments',''), comments),
    submission_count = submission_count + 1,
    submitted_at = greatest(submitted_at, ts),
    history = history || jsonb_build_array(jsonb_build_object('received_at', now(), 'submitted_at', ts, 'source', _source, 'data', _row))
  where id = existing.id;
  return 'updated';
end $$;
revoke execute on function public.upsert_submission(jsonb, text) from public, anon, authenticated;

create or replace function public.import_submissions(_rows jsonb, _source text default 'import')
returns jsonb language plpgsql security definer set search_path = public as $$
declare r jsonb; res text; ins int := 0; upd int := 0; skp int := 0; dup int := 0;
begin
  if not public.is_admin(auth.uid()) then raise exception 'Only administrators can import submissions'; end if;
  for r in select * from jsonb_array_elements(_rows) loop
    res := public.upsert_submission(r, _source);
    if res = 'inserted' then ins := ins + 1; elsif res = 'updated' then upd := upd + 1; elsif res = 'duplicate' then dup := dup + 1; else skp := skp + 1; end if;
  end loop;
  perform public.log_activity('submission', null, null, 'imported', 'imported ' || jsonb_array_length(_rows) || ' interest form rows', jsonb_build_object('inserted', ins, 'updated', upd, 'duplicates', dup, 'skipped', skp));
  return jsonb_build_object('inserted', ins, 'updated', upd, 'duplicates', dup, 'skipped', skp);
end $$;

-- ============ ROLE / ACCOUNT RPCs ============
create or replace function public.set_admin_role(_target uuid, _grant boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner(auth.uid()) or not public.is_active(auth.uid()) then raise exception 'Only the Primary Owner can change administrator roles'; end if;
  if public.is_owner(_target) then raise exception 'The Primary Owner role cannot be changed here'; end if;
  if _grant then
    if not public.is_active(_target) then raise exception 'Only active accounts can become Co-Administrators'; end if;
    insert into public.user_roles(user_id, role) values (_target, 'admin') on conflict do nothing;
    perform public.log_activity('user', _target, null, 'role_granted', 'granted Co-Administrator access to ' || coalesce((select full_name from public.profiles where id = _target), 'a user'));
  else
    delete from public.user_roles where user_id = _target and role = 'admin';
    perform public.log_activity('user', _target, null, 'role_revoked', 'removed Co-Administrator access from ' || coalesce((select full_name from public.profiles where id = _target), 'a user'));
  end if;
end $$;

create or replace function public.transfer_ownership(_target uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner(auth.uid()) then raise exception 'Only the Primary Owner can transfer ownership'; end if;
  if _target = auth.uid() then raise exception 'You already own the platform'; end if;
  if not public.is_admin(_target) then raise exception 'Ownership can only be transferred to an active Co-Administrator'; end if;
  delete from public.user_roles where user_id = auth.uid() and role = 'owner';
  insert into public.user_roles(user_id, role) values (auth.uid(), 'admin') on conflict do nothing;
  insert into public.user_roles(user_id, role) values (_target, 'owner');
  delete from public.user_roles where user_id = _target and role = 'admin';
  perform public.log_activity('user', _target, null, 'ownership_transferred', 'transferred Primary Ownership to ' || coalesce((select full_name from public.profiles where id = _target), 'a user'));
end $$;

create or replace function public.set_account_status(_target uuid, _status public.account_status)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin(auth.uid()) then raise exception 'Only administrators can change account status'; end if;
  if public.is_owner(_target) then raise exception 'The Primary Owner account cannot be deactivated'; end if;
  if public.has_role(_target, 'admin') and not public.is_owner(auth.uid()) then raise exception 'Only the Primary Owner can change a Co-Administrator''s status'; end if;
  update public.profiles set status = _status where id = _target;
  perform public.log_activity('user', _target, null, 'status_changed', 'set account of ' || coalesce((select full_name from public.profiles where id = _target), 'a user') || ' to ' || _status::text);
end $$;

create or replace function public.set_team_membership(_team uuid, _user uuid, _member boolean, _lead boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare tname text; uname text;
begin
  if not public.is_admin(auth.uid()) then raise exception 'Only administrators can change team membership'; end if;
  select name into tname from public.teams where id = _team;
  select full_name into uname from public.profiles where id = _user;
  if _member then
    insert into public.team_members(team_id, user_id, is_lead) values (_team, _user, _lead)
      on conflict (team_id, user_id) do update set is_lead = excluded.is_lead;
    perform public.log_activity('team', _team, _team, 'member_set', (case when _lead then 'set ' || coalesce(uname,'a user') || ' as lead of ' else 'added ' || coalesce(uname,'a user') || ' to ' end) || coalesce(tname,'a team'));
    perform public.notify(_user, 'team', null, case when _lead then 'You are now a team lead' else 'You were added to a team' end, tname, '/teams/' || _team);
  else
    delete from public.team_members where team_id = _team and user_id = _user;
    perform public.log_activity('team', _team, _team, 'member_removed', 'removed ' || coalesce(uname,'a user') || ' from ' || coalesce(tname,'a team'));
  end if;
end $$;

create or replace function public.owner_exists()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where role = 'owner')
$$;
grant execute on function public.owner_exists() to anon, authenticated;

-- ============ NEW USER HANDLING ============
create or replace function public.claim_owner_if_eligible(_uid uuid, _email text)
returns void language plpgsql security definer set search_path = public as $$
declare owner_email text;
begin
  select value->>'email' into owner_email from public.integration_settings where key = 'primary_owner';
  if owner_email is null or lower(_email) <> lower(owner_email) then return; end if;
  if exists (select 1 from public.user_roles where role = 'owner') then return; end if;
  insert into public.user_roles(user_id, role) values (_uid, 'owner');
  update public.profiles set status = 'active' where id = _uid;
  insert into public.activity_log(actor_id, entity_type, entity_id, action, summary) values (_uid, 'user', _uid, 'owner_setup', 'completed Primary Owner setup');
end $$;
revoke execute on function public.claim_owner_if_eligible(uuid, text) from public, anon, authenticated;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, status)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'full_name',''), split_part(new.email, '@', 1)), 'pending')
  on conflict (id) do nothing;
  insert into public.profile_private(user_id, email) values (new.id, lower(new.email)) on conflict (user_id) do nothing;
  if new.email_confirmed_at is not null then perform public.claim_owner_if_eligible(new.id, new.email); end if;
  return new;
end $$;

create or replace function public.handle_user_confirmed()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.email_confirmed_at is not null and old.email_confirmed_at is null then
    perform public.claim_owner_if_eligible(new.id, new.email);
  end if;
  if new.email is distinct from old.email then
    update public.profile_private set email = lower(new.email) where user_id = new.id;
  end if;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
create trigger on_auth_user_confirmed after update on auth.users for each row execute function public.handle_user_confirmed();

-- ============ SEED: owner email, org name, starter teams ============
insert into public.integration_settings(key, value) values
  ('primary_owner', '{"email": "artive101@gmail.com"}'::jsonb),
  ('organization', '{"name": "Beyond GHC"}'::jsonb);

insert into public.teams(name, description, color) values
  ('Programs & Speakers', 'Responsible for planning sessions, finding and coordinating speakers, reviewing presentation proposals, organizing speaker schedules, and supporting presenters.', 'blue'),
  ('Community & Member Experience', 'Responsible for welcoming members, onboarding volunteers, organizing networking opportunities, gathering feedback, and helping maintain an inclusive and engaging community.', 'sage'),
  ('Marketing & Communications', 'Responsible for brand development, social media, graphics, event promotion, announcements, content calendars, and post-event recaps.', 'orange'),
  ('Operations & Technology', 'Responsible for platform setup, registration systems, forms, attendance tracking, virtual event logistics, technical support, and internal systems.', 'lavender');

insert into public.team_dataset_access(team_id, dataset, leads_only)
select id, 'speaker_pipeline'::public.dataset_kind, true from public.teams where name = 'Programs & Speakers'
union all select id, 'member_contacts'::public.dataset_kind, true from public.teams where name = 'Community & Member Experience'
union all select id, 'public_member_info'::public.dataset_kind, false from public.teams where name = 'Marketing & Communications'
union all select id, 'volunteer_pipeline'::public.dataset_kind, true from public.teams where name = 'Operations & Technology';
