// Organization display name. The live name is editable by admins (Integrations > Organization);
// this is the fallback shown before it loads.
export const ORG_NAME_FALLBACK = "Beyond GHC";
