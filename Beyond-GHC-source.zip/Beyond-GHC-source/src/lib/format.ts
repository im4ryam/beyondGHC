import type { Database } from "@/integrations/supabase/types";
import type { BadgeProps } from "@/components/ui/badge";

export type TaskStatus = Database["public"]["Enums"]["task_status"];
export type Priority = Database["public"]["Enums"]["priority_level"];
export type ProjectStatus = Database["public"]["Enums"]["project_status"];
export type SubmissionStatus = Database["public"]["Enums"]["submission_status"];
type Variant = NonNullable<BadgeProps["variant"]>;

export const TASK_STATUSES: { value: TaskStatus; label: string; variant: Variant }[] = [
  { value: "incomplete", label: "Incomplete", variant: "slate" },
  { value: "in_progress", label: "In Progress", variant: "dusty" },
  { value: "revised", label: "Revised", variant: "amber" },
  { value: "completed", label: "Completed", variant: "sage" },
];
export const taskStatusMeta = (s: TaskStatus) => TASK_STATUSES.find((x) => x.value === s)!;

export const PRIORITIES: { value: Priority; label: string; variant: Variant; rank: number }[] = [
  { value: "low", label: "Low", variant: "slate", rank: 1 },
  { value: "medium", label: "Medium", variant: "dusty", rank: 2 },
  { value: "high", label: "High", variant: "amber", rank: 3 },
  { value: "urgent", label: "Urgent", variant: "destructive", rank: 4 },
];
export const priorityMeta = (p: Priority) => PRIORITIES.find((x) => x.value === p)!;

export const PROJECT_STATUSES: { value: ProjectStatus; label: string; variant: Variant }[] = [
  { value: "planning", label: "Planning", variant: "lavender" },
  { value: "active", label: "Active", variant: "dusty" },
  { value: "on_hold", label: "On hold", variant: "amber" },
  { value: "completed", label: "Completed", variant: "sage" },
  { value: "archived", label: "Archived", variant: "slate" },
];
export const projectStatusMeta = (s: ProjectStatus) => PROJECT_STATUSES.find((x) => x.value === s)!;

export const SUBMISSION_STATUSES: { value: SubmissionStatus; label: string; variant: Variant }[] = [
  { value: "new", label: "New", variant: "dusty" },
  { value: "reviewing", label: "Reviewing", variant: "lavender" },
  { value: "approved", label: "Approved", variant: "sage" },
  { value: "converted", label: "Account created", variant: "sage" },
  { value: "rejected", label: "Rejected", variant: "destructive" },
  { value: "archived", label: "Archived", variant: "slate" },
];
export const submissionStatusMeta = (s: SubmissionStatus) => SUBMISSION_STATUSES.find((x) => x.value === s)!;

export const SPEAKER_STATUSES = [
  { value: "not_contacted", label: "Not contacted" },
  { value: "contacted", label: "Contacted" },
  { value: "in_discussion", label: "In discussion" },
  { value: "confirmed", label: "Confirmed" },
  { value: "scheduled", label: "Scheduled" },
  { value: "presented", label: "Presented" },
  { value: "declined", label: "Declined" },
];

export const RESOURCE_CATEGORIES = [
  { value: "templates", label: "Templates" },
  { value: "guidelines", label: "Guidelines" },
  { value: "forms", label: "Forms" },
  { value: "training", label: "Training materials" },
  { value: "reference", label: "Reference documents" },
  { value: "shared_folders", label: "Shared folders" },
  { value: "links", label: "Useful links" },
] as const;

export const TEAM_COLORS: Record<string, { variant: Variant; dot: string; soft: string }> = {
  blue: { variant: "dusty", dot: "bg-dusty", soft: "bg-dusty-soft" },
  sage: { variant: "sage", dot: "bg-sage", soft: "bg-sage-soft" },
  orange: { variant: "amber", dot: "bg-highlight", soft: "bg-amber-soft" },
  lavender: { variant: "lavender", dot: "bg-lavender", soft: "bg-lavender-soft" },
  plum: { variant: "plum", dot: "bg-plum", soft: "bg-plum-soft" },
  slate: { variant: "slate", dot: "bg-slate", soft: "bg-slate-soft" },
};
const DEFAULT_TEAM_COLOR = { variant: "dusty" as Variant, dot: "bg-dusty", soft: "bg-dusty-soft" };
export const teamColor = (c?: string | null) => TEAM_COLORS[c ?? "blue"] ?? DEFAULT_TEAM_COLOR;

export const TIMEZONES = [
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Phoenix",
  "America/Los_Angeles",
  "America/Anchorage",
  "Pacific/Honolulu",
  "America/Toronto",
  "America/Sao_Paulo",
  "Europe/London",
  "Europe/Berlin",
  "Europe/Paris",
  "Africa/Lagos",
  "Africa/Nairobi",
  "Asia/Dubai",
  "Asia/Riyadh",
  "Asia/Kolkata",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney",
  "UTC",
];

export function fmtDate(d: string | Date | null | undefined, tz?: string, opts?: Intl.DateTimeFormatOptions) {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: tz, ...opts }).format(date);
}
export function fmtDateTime(d: string | Date | null | undefined, tz?: string) {
  return fmtDate(d, tz, { hour: "numeric", minute: "2-digit" });
}
export function fmtRelative(d: string | Date | null | undefined) {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  const diff = (Date.now() - date.getTime()) / 1000;
  const abs = Math.abs(diff);
  const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  if (abs < 60) return "just now";
  if (abs < 3600) return rtf.format(-Math.round(diff / 60), "minute");
  if (abs < 86400) return rtf.format(-Math.round(diff / 3600), "hour");
  if (abs < 86400 * 30) return rtf.format(-Math.round(diff / 86400), "day");
  return fmtDate(date);
}

export type DueState = "none" | "overdue" | "soon" | "later" | "done";
/** Overdue = past due and not completed. Due soon = within the next 3 days. */
export function dueState(due: string | null | undefined, status: TaskStatus, now: Date = new Date()): DueState {
  if (status === "completed") return "done";
  if (!due) return "none";
  const t = new Date(due).getTime();
  if (t < now.getTime()) return "overdue";
  if (t - now.getTime() <= 3 * 86400 * 1000) return "soon";
  return "later";
}

/** Share of a project's checklist items that are completed (0–100). */
export function projectProgress(items: { status: TaskStatus }[]) {
  if (!items.length) return 0;
  return Math.round((items.filter((i) => i.status === "completed").length / items.length) * 100);
}

export function initials(name?: string | null) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? "") : "")).toUpperCase() || "?";
}

export function errMsg(e: unknown) {
  if (e && typeof e === "object" && "message" in e) return String((e as { message: unknown }).message);
  return "Something went wrong";
}

/** Convert a date input (yyyy-mm-dd) to an ISO timestamp at 23:59 in the given time zone. */
export function endOfDayInZone(dateStr: string, tz: string) {
  const [y = 1970, m = 1, d = 1] = dateStr.split("-").map(Number);
  const guess = new Date(Date.UTC(y, m - 1, d, 23, 59, 0));
  const inTz = new Date(guess.toLocaleString("en-US", { timeZone: tz }));
  const inUtc = new Date(guess.toLocaleString("en-US", { timeZone: "UTC" }));
  return new Date(guess.getTime() - (inTz.getTime() - inUtc.getTime())).toISOString();
}
export function dateInputValue(iso: string | null | undefined, tz: string) {
  if (!iso) return "";
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(iso));
  return parts;
}
