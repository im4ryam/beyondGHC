// Maps interest-form columns (Google Forms / Microsoft Forms / the curated workbook) to
// submission fields. Shared by the in-app spreadsheet import and the automatic intake endpoint.

export type SubmissionRow = {
  email?: string;
  full_name?: string;
  phone?: string;
  linkedin_url?: string;
  background?: string;
  ghc_connection?: string;
  timezone?: string;
  participation?: string;
  topics?: string;
  formats?: string;
  community_spaces?: string;
  availability?: string;
  platform_pref?: string;
  volunteer_interest?: boolean;
  volunteer_areas?: string;
  preferred_team?: string;
  volunteer_experience?: string;
  speaker_interest?: boolean;
  proposed_topics?: string;
  comments?: string;
  submitted_at?: string;
  external_id?: string;
};

type Field = keyof SubmissionRow;

// Order matters: first matching rule wins for a header.
const RULES: [Field, RegExp][] = [
  ["submitted_at", /^(timestamp|submitted|submission date|start time|completion time|date submitted)/i],
  ["external_id", /^(response id|id)$/i],
  ["email", /e-?mail/i],
  ["full_name", /^(full name|name)$|your name/i],
  ["phone", /phone|mobile/i],
  ["linkedin_url", /linkedin/i],
  ["background", /best describes you|^background$/i],
  ["ghc_connection", /connection to ghc|ghc connection/i],
  ["timezone", /time ?zone/i],
  ["speaker_interest", /^speaker interest$/i],
  ["volunteer_interest", /^volunteer interest$/i],
  ["proposed_topics", /present|proposed topics/i],
  ["volunteer_areas", /like to volunteer|volunteer areas/i],
  ["preferred_team", /team preference|preferred team/i],
  ["volunteer_experience", /volunteer experience|other skills/i],
  ["participation", /like to participate|participation/i],
  ["topics", /topics (interest|of interest)|what topics/i],
  ["formats", /format/i],
  ["community_spaces", /stay connected|community spaces/i],
  ["availability", /available|availability/i],
  ["platform_pref", /whatsapp|platform/i],
  ["comments", /anything else|comments|suggest/i],
];

export function mapHeader(header: string): Field | null {
  const h = header.replace(/\s+/g, " ").trim();
  for (const [field, re] of RULES) if (re.test(h)) return field;
  return null;
}

const truthy = (v: string) => /^(yes|y|true|1|x)$/i.test(v.trim());

export function mapRecord(record: Record<string, unknown>): SubmissionRow {
  const out: SubmissionRow = {};
  for (const [header, raw] of Object.entries(record)) {
    const field = mapHeader(header);
    if (!field || raw === null || raw === undefined) continue;
    let value: string;
    if (raw instanceof Date) value = raw.toISOString();
    else value = String(raw).trim();
    if (!value) continue;
    if (field === "volunteer_interest" || field === "speaker_interest") {
      out[field] = truthy(value);
    } else if (!(field in out)) {
      (out as Record<string, unknown>)[field] = value;
    }
  }
  if (out.email) out.email = out.email.toLowerCase();
  // Infer interests from form answers when no explicit flag column exists.
  const part = (out.participation ?? "").toLowerCase();
  if (out.volunteer_interest === undefined)
    out.volunteer_interest = /volunteer|help organize/.test(part) || !!out.volunteer_areas;
  if (out.speaker_interest === undefined)
    out.speaker_interest = /speak|present|showcas/.test(part) || !!out.proposed_topics;
  return out;
}

export function isValidEmail(email?: string) {
  return !!email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
