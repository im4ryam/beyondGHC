import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type InviteInput = {
  email: string;
  full_name: string;
  team_ids: string[];
  lead_team_ids: string[];
  submission_id?: string | null;
  redirect_to: string;
};

async function assertAdmin(context: { supabase: { rpc: (fn: "is_admin", args: { _uid: string }) => PromiseLike<{ data: unknown }> }; userId: string }) {
  const { data } = await context.supabase.rpc("is_admin", { _uid: context.userId });
  if (!data) throw new Error("Only administrators can do this");
}

/** Create (or re-activate) a volunteer account and email them an invitation to set a password. */
export const inviteMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: InviteInput) => {
    const email = String(input.email ?? "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Enter a valid email address");
    const full_name = String(input.full_name ?? "").trim().slice(0, 200);
    if (!full_name) throw new Error("Name is required");
    const redirect_to = String(input.redirect_to ?? "");
    if (!/^https?:\/\//.test(redirect_to)) throw new Error("Invalid redirect");
    return {
      email,
      full_name,
      team_ids: Array.isArray(input.team_ids) ? input.team_ids.map(String) : [],
      lead_team_ids: Array.isArray(input.lead_team_ids) ? input.lead_team_ids.map(String) : [],
      submission_id: input.submission_id ? String(input.submission_id) : null,
      redirect_to,
    };
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let userId: string | null = null;
    let invited = false;
    const { data: existing } = await supabaseAdmin.from("profile_private").select("user_id").eq("email", data.email).maybeSingle();
    if (existing) {
      userId = existing.user_id;
    } else {
      const { data: inv, error } = await supabaseAdmin.auth.admin.inviteUserByEmail(data.email, {
        redirectTo: data.redirect_to,
        data: { full_name: data.full_name },
      });
      if (error) throw new Error(error.message);
      userId = inv.user.id;
      invited = true;
    }
    if (!userId) throw new Error("Could not create the account");

    // Copy useful details from the interest form submission, if any.
    let extra: { linkedin_url?: string | null; availability?: string | null } = {};
    if (data.submission_id) {
      const { data: sub } = await supabaseAdmin.from("interest_submissions").select("linkedin_url, availability").eq("id", data.submission_id).maybeSingle();
      if (sub) extra = { linkedin_url: sub.linkedin_url, availability: sub.availability };
    }
    const { error: pErr } = await supabaseAdmin
      .from("profiles")
      .update({ status: "active", full_name: data.full_name, ...extra })
      .eq("id", userId);
    if (pErr) throw new Error(pErr.message);

    const teamRows = Array.from(new Set([...data.team_ids, ...data.lead_team_ids])).map((team_id) => ({
      team_id,
      user_id: userId,
      is_lead: data.lead_team_ids.includes(team_id),
    }));
    if (teamRows.length) {
      const { error } = await supabaseAdmin.from("team_members").upsert(teamRows, { onConflict: "team_id,user_id" });
      if (error) throw new Error(error.message);
    }
    if (data.submission_id) {
      await supabaseAdmin.from("interest_submissions").update({ status: "converted", profile_id: userId }).eq("id", data.submission_id);
    }
    await supabaseAdmin.from("activity_log").insert({
      actor_id: context.userId,
      entity_type: "user",
      entity_id: userId,
      action: invited ? "invited" : "activated",
      summary: `${invited ? "invited" : "activated the account of"} ${data.full_name}`,
    });
    return { userId, invited };
  });

/** Generate a new secret key for the automatic form-intake endpoint. Returned once; only a hash is stored. */
export const rotateIntakeKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const bytes = new Uint8Array(24);
    crypto.getRandomValues(bytes);
    const key = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    const hash = await sha256(key);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: cur } = await supabaseAdmin.from("integration_settings").select("value").eq("key", "form_intake").maybeSingle();
    const prev = (cur?.value as Record<string, unknown>) ?? {};
    const { error } = await supabaseAdmin.from("integration_settings").upsert({
      key: "form_intake",
      value: { ...prev, key_hash: hash, key_hint: key.slice(-4), rotated_at: new Date().toISOString(), enabled: true },
      updated_by: context.userId,
    });
    if (error) throw new Error(error.message);
    await supabaseAdmin.from("activity_log").insert({ actor_id: context.userId, entity_type: "integration", action: "key_rotated", summary: "generated a new form-intake key" });
    return { key };
  });

export async function sha256(s: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
}
