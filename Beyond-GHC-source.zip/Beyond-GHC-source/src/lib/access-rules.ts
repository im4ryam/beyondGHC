export function canCreateTeamTask(user: { isAdmin: boolean; teamIds: string[] }, teamId: string) {
  return user.isAdmin || user.teamIds.includes(teamId);
}

export function taskAssignee(user: { id: string; isAdmin: boolean; leadTeamIds: string[] }, teamId: string, selected: string | null) {
  return user.isAdmin || user.leadTeamIds.includes(teamId) ? selected : user.id;
}

export function needsAssignment(user: { isAdmin: boolean; profile: { status: string }; memberships: { team: { archived: boolean } }[] }) {
  return user.profile.status !== "deactivated" && !user.isAdmin && !user.memberships.some((m) => !m.team.archived);
}