import { queryOptions, useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Profile = Tables<"profiles">;
export type Team = Tables<"teams">;
export type TeamMember = Tables<"team_members">;
export type Task = Tables<"tasks">;
export type Project = Tables<"projects">;
export type Resource = Tables<"resources">;
export type Announcement = Tables<"announcements">;
export type CalEvent = Tables<"events">;
export type Submission = Tables<"interest_submissions">;
export type Notification = Tables<"notifications">;
export type Activity = Tables<"activity_log">;

export type Me = {
  id: string;
  email: string;
  profile: Profile;
  phone: string | null;
  notificationPrefs: Record<string, boolean>;
  roles: ("owner" | "admin")[];
  isOwner: boolean;
  isAdmin: boolean;
  memberships: (TeamMember & { team: Team })[];
  teamIds: string[];
  leadTeamIds: string[];
  isLead: boolean;
  datasets: { dataset: string; team_id: string }[];
};

async function must<T>(p: PromiseLike<{ data: T; error: unknown }>): Promise<T> {
  const { data, error } = await p;
  if (error) throw error;
  return data;
}

export const meQuery = queryOptions({
  queryKey: ["me"],
  refetchInterval: 15000,
  queryFn: async (): Promise<Me | null> => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return null;
    const [profile, priv, roles, memberships] = await Promise.all([
      must(supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()),
      must(supabase.from("profile_private").select("*").eq("user_id", user.id).maybeSingle()),
      must(supabase.from("user_roles").select("role").eq("user_id", user.id)),
      must(supabase.from("team_members").select("*, team:teams(*)").eq("user_id", user.id)),
    ]);
    if (!profile) return null;
    const r = (roles ?? []).map((x) => x.role);
    const ms = (memberships ?? []).filter((m) => m.team) as Me["memberships"];
    const active = profile.status === "active";
    let datasets: Me["datasets"] = [];
    if (active && ms.length) {
      const grants = await must(
        supabase.from("team_dataset_access").select("*").in("team_id", ms.map((m) => m.team_id)),
      );
      datasets = (grants ?? [])
        .filter((g) => !g.leads_only || ms.some((m) => m.team_id === g.team_id && m.is_lead))
        .map((g) => ({ dataset: g.dataset, team_id: g.team_id }));
    }
    const leadTeamIds = ms.filter((m) => m.is_lead && !m.team.archived).map((m) => m.team_id);
    return {
      id: user.id,
      email: priv?.email ?? user.email ?? "",
      profile,
      phone: priv?.phone ?? null,
      notificationPrefs: (priv?.notification_prefs as Record<string, boolean>) ?? {},
      roles: r,
      isOwner: active && r.includes("owner"),
      isAdmin: active && (r.includes("owner") || r.includes("admin")),
      memberships: ms,
      teamIds: ms.map((m) => m.team_id),
      leadTeamIds,
      isLead: leadTeamIds.length > 0,
      datasets,
    };
  },
});

/** Signed-in user's context. Only call inside the portal (the shell loads it first). */
export function useMe(): Me {
  const { data } = useSuspenseQuery(meQuery);
  if (!data) throw new Error("Not signed in");
  return data;
}

export function canManageTeam(me: Me, teamId: string | null | undefined) {
  if (me.isAdmin) return true;
  return !!teamId && me.leadTeamIds.includes(teamId);
}

export const teamsQuery = queryOptions({
  queryKey: ["teams"],
  queryFn: () => must(supabase.from("teams").select("*").order("name")),
});

export const profilesQuery = queryOptions({
  queryKey: ["profiles"],
  queryFn: () => must(supabase.from("profiles").select("*").order("full_name")),
});

export const membersQuery = queryOptions({
  queryKey: ["team_members"],
  queryFn: () => must(supabase.from("team_members").select("*")),
});

export const tasksQuery = queryOptions({
  queryKey: ["tasks"],
  queryFn: () => must(supabase.from("tasks").select("*").order("due_date", { ascending: true, nullsFirst: false }).limit(2000)),
});

export const projectsQuery = queryOptions({
  queryKey: ["projects"],
  queryFn: () => must(supabase.from("projects").select("*").order("updated_at", { ascending: false })),
});

export const announcementsQuery = queryOptions({
  queryKey: ["announcements"],
  queryFn: () =>
    must(supabase.from("announcements").select("*").order("pinned", { ascending: false }).order("created_at", { ascending: false }).limit(200)),
});

export const resourcesQuery = queryOptions({
  queryKey: ["resources"],
  queryFn: () => must(supabase.from("resources").select("*").order("created_at", { ascending: false })),
});

export const eventsQuery = queryOptions({
  queryKey: ["events"],
  queryFn: () => must(supabase.from("events").select("*").order("starts_at")),
});

export const notificationsQuery = queryOptions({
  queryKey: ["notifications"],
  queryFn: () => must(supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(100)),
  refetchInterval: 60_000,
});

export const orgNameQuery = queryOptions({
  queryKey: ["org_name"],
  queryFn: async () => {
    const { data } = await supabase.rpc("organization_name");
    return (data as string | null) ?? "Beyond GHC";
  },
  staleTime: 5 * 60_000,
});

export function useLookup() {
  const profiles = useQuery(profilesQuery).data ?? [];
  const teams = useQuery(teamsQuery).data ?? [];
  const projects = useQuery(projectsQuery).data ?? [];
  const profileById = new Map(profiles.map((p) => [p.id, p]));
  const teamById = new Map(teams.map((t) => [t.id, t]));
  const projectById = new Map(projects.map((p) => [p.id, p]));
  return { profiles, teams, projects, profileById, teamById, projectById };
}

export { must };
