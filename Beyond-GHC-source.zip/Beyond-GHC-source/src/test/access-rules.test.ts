import { describe, expect, it } from "vitest";
import { canCreateTeamTask, taskAssignee, needsAssignment } from "@/lib/access-rules";

describe("volunteer task creation", () => {
  const volunteer = { id: "volunteer", isAdmin: false, leadTeamIds: [], teamIds: ["community"] };
  it("allows volunteers to create tasks in their own team only", () => {
    expect(canCreateTeamTask(volunteer, "community")).toBe(true);
    expect(canCreateTeamTask(volunteer, "marketing")).toBe(false);
  });
  it("assigns volunteer-created tasks only to the volunteer", () => {
    expect(taskAssignee(volunteer, "community", "other-person")).toBe("volunteer");
    expect(taskAssignee(volunteer, "community", null)).toBe("volunteer");
  });
  it("lets leads assign specific members only in the teams they lead", () => {
    const lead = { ...volunteer, leadTeamIds: ["community"] };
    expect(taskAssignee(lead, "community", "member")).toBe("member");
    expect(taskAssignee(lead, "marketing", "member")).toBe("volunteer");
  });
});

describe("assignment waiting", () => {
  it("shows the request screen to a member without a team", () => {
    expect(needsAssignment({ isAdmin: false, profile: { status: "pending" }, memberships: [] })).toBe(true);
  });
  it("unlocks team members and co-admins", () => {
    expect(needsAssignment({ isAdmin: false, profile: { status: "active" }, memberships: [{ team: { archived: false } }] })).toBe(false);
    expect(needsAssignment({ isAdmin: true, profile: { status: "active" }, memberships: [] })).toBe(false);
  });
  it("does not offer requests to deactivated accounts", () => {
    expect(needsAssignment({ isAdmin: false, profile: { status: "deactivated" }, memberships: [] })).toBe(false);
  });
});