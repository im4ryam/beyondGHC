import { describe, expect, it } from "vitest";
import { dueState, projectProgress, endOfDayInZone } from "@/lib/format";
import { mapRecord, isValidEmail } from "@/lib/submission-mapping";

const now = new Date("2026-11-16T12:00:00Z");

describe("task deadlines", () => {
  it("marks a past-due open task as overdue", () => {
    expect(dueState("2026-11-15T12:00:00Z", "in_progress", now)).toBe("overdue");
  });
  it("marks a task due within 3 days as due soon", () => {
    expect(dueState("2026-11-18T12:00:00Z", "incomplete", now)).toBe("soon");
  });
  it("never marks a completed task overdue", () => {
    expect(dueState("2026-11-01T12:00:00Z", "completed", now)).toBe("done");
  });
  it("stores a date deadline as end of day in the person's time zone", () => {
    expect(endOfDayInZone("2026-11-20", "America/New_York")).toBe("2026-11-21T04:59:00.000Z");
  });
});

describe("project progress", () => {
  it("is the share of checklist items that are completed", () => {
    expect(projectProgress([{ status: "completed" }, { status: "in_progress" }])).toBe(50);
  });
  it("is 0 for a project with no items", () => {
    expect(projectProgress([])).toBe(0);
  });
});

describe("interest form mapping", () => {
  it("matches people by lowercased email", () => {
    expect(mapRecord({ "Email Address": "Jane.Doe@Example.com" }).email).toBe("jane.doe@example.com");
  });
  it("flags volunteers from the participation answer", () => {
    const r = mapRecord({ Email: "a@b.co", "How would you like to participate?": "Attend workshops, Help organize or volunteer" });
    expect(r.volunteer_interest).toBe(true);
    expect(r.speaker_interest).toBe(false);
  });
  it("flags speakers when they propose a topic", () => {
    const r = mapRecord({ Email: "a@b.co", "If you're interested in presenting, what topics or sessions would you like to present?": "LLM evals" });
    expect(r.speaker_interest).toBe(true);
  });
  it("rejects a last name typed into the email field", () => {
    expect(isValidEmail("REPIN")).toBe(false);
  });
});
