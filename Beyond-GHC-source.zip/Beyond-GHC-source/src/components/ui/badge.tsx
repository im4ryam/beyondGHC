import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-sm border px-2 py-0.5 text-[11px] font-medium leading-4 whitespace-nowrap transition-colors",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground",
        secondary: "border-transparent bg-secondary text-secondary-foreground",
        destructive: "border-transparent bg-danger-soft text-destructive",
        outline: "text-foreground bg-card",
        slate: "border-slate/20 bg-slate-soft text-slate",
        dusty: "border-dusty/25 bg-dusty-soft text-dusty",
        sage: "border-sage/25 bg-sage-soft text-sage",
        amber: "border-amber/25 bg-amber-soft text-amber",
        lavender: "border-lavender/25 bg-lavender-soft text-lavender",
        plum: "border-plum/25 bg-plum-soft text-plum",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
