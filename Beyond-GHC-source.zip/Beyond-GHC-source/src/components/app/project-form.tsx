import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { teamsQuery, useMe, canManageTeam, type Project } from "@/lib/queries";
import { PRIORITIES, PROJECT_STATUSES, errMsg, type Priority, type ProjectStatus } from "@/lib/format";

export function ProjectFormDialog({
  open,
  onOpenChange,
  project,
  defaultTeamId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  project?: Project | null | undefined;
  defaultTeamId?: string | undefined;
}) {
  const me = useMe();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const teams = (useQuery(teamsQuery).data ?? []).filter((t) => !t.archived && canManageTeam(me, t.id));
  const [teamId, setTeamId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [status, setStatus] = useState<ProjectStatus>("active");
  const [due, setDue] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTeamId(project?.team_id ?? defaultTeamId ?? teams[0]?.id ?? "");
    setTitle(project?.title ?? "");
    setDescription(project?.description ?? "");
    setPriority(project?.priority ?? "medium");
    setStatus(project?.status ?? "active");
    setDue(project?.due_date ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, project?.id]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) { toast.error("Give the project a title"); return; }
    if (!teamId) { toast.error("Choose a team"); return; }
    setSaving(true);
    const payload = {
      team_id: teamId,
      title: title.trim(),
      description: description.trim() || null,
      priority,
      status,
      due_date: due || null,
      ...(status === "completed" && project?.status !== "completed" ? { completed_at: new Date().toISOString(), completed_by: me.id } : {}),
    };
    const res = project
      ? await supabase.from("projects").update(payload).eq("id", project.id).select().single()
      : await supabase.from("projects").insert({ ...payload, created_by: me.id }).select().single();
    setSaving(false);
    if (res.error) { toast.error(errMsg(res.error)); return; }
    toast.success(project ? "Project updated" : "Project created");
    qc.invalidateQueries({ queryKey: ["projects"] });
    onOpenChange(false);
    if (!project && res.data) navigate({ to: "/projects/$projectId", params: { projectId: res.data.id } });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{project ? "Edit project" : "New team project"}</DialogTitle>
          <DialogDescription>Projects hold a shared checklist. Each checklist item is a task you can assign.</DialogDescription>
        </DialogHeader>
        {teams.length === 0 ? (
          <p className="text-sm text-muted-foreground">You need to be a team lead or administrator to create projects.</p>
        ) : (
          <form onSubmit={save} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="p-title">Title</Label>
              <Input id="p-title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} placeholder="e.g. Launch Organization LinkedIn Page" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Team</Label>
                <Select value={teamId} onValueChange={setTeamId} disabled={!!project}>
                  <SelectTrigger><SelectValue placeholder="Choose team" /></SelectTrigger>
                  <SelectContent>{teams.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="p-due">Target date</Label>
                <Input id="p-due" type="date" value={due} onChange={(e) => setDue(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PRIORITIES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={status} onValueChange={(v) => setStatus(v as ProjectStatus)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PROJECT_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p-desc">Description</Label>
              <Textarea id="p-desc" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving…" : project ? "Save changes" : "Create project"}</Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
