import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useLookup, useMe } from "@/lib/queries";
import { fmtDateTime } from "@/lib/format";
import { UserAvatar } from "./bits";

export function ActivityList({ entityType, entityId, teamId, limit = 50 }: { entityType?: string; entityId?: string; teamId?: string; limit?: number }) {
  const me = useMe();
  const { profileById } = useLookup();
  const { data = [], isLoading } = useQuery({
    queryKey: ["activity", entityType, entityId, teamId, limit],
    queryFn: async () => {
      let q = supabase.from("activity_log").select("*").order("created_at", { ascending: false }).limit(limit);
      if (entityType) q = q.eq("entity_type", entityType);
      if (entityId) q = q.eq("entity_id", entityId);
      if (teamId) q = q.eq("team_id", teamId);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });
  if (isLoading) return <p className="text-sm text-muted-foreground">Loading history…</p>;
  if (!data.length) return <p className="text-sm text-muted-foreground">No activity recorded yet.</p>;
  return (
    <ol className="relative space-y-3 border-l border-dashed pl-4">
      {data.map((a) => {
        const actor = a.actor_id ? profileById.get(a.actor_id) : null;
        return (
          <li key={a.id} className="relative">
            <span className="absolute -left-[21px] top-1 size-2.5 rounded-sm border border-border-strong bg-highlight" aria-hidden />
            <div className="flex items-start gap-2">
              <UserAvatar name={actor?.full_name ?? "System"} url={actor?.avatar_url} size="sm" />
              <div className="min-w-0 text-sm">
                <span className="font-medium">{actor?.full_name ?? "System"}</span> <span className="text-muted-foreground">{a.summary}</span>
                <div className="font-mono text-[11px] text-muted-foreground">{fmtDateTime(a.created_at, me.profile.timezone)}</div>
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
