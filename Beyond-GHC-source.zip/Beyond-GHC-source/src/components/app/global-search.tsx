import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { BookOpen, CheckSquare, FolderKanban, Megaphone, User } from "lucide-react";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { announcementsQuery, profilesQuery, projectsQuery, resourcesQuery, tasksQuery } from "@/lib/queries";

export function GlobalSearch({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const enabled = open;
  const tasks = useQuery({ ...tasksQuery, enabled }).data ?? [];
  const projects = useQuery({ ...projectsQuery, enabled }).data ?? [];
  const resources = useQuery({ ...resourcesQuery, enabled }).data ?? [];
  const announcements = useQuery({ ...announcementsQuery, enabled }).data ?? [];
  const people = useQuery({ ...profilesQuery, enabled }).data ?? [];

  const term = q.trim().toLowerCase();
  const match = (...s: (string | null | undefined)[]) => !term || s.some((x) => x?.toLowerCase().includes(term));
  const res = useMemo(
    () => ({
      tasks: tasks.filter((t) => match(t.title, t.description)).slice(0, 6),
      projects: projects.filter((p) => match(p.title, p.description)).slice(0, 5),
      resources: resources.filter((r) => match(r.title, r.description, r.url)).slice(0, 5),
      announcements: announcements.filter((a) => match(a.title, a.body)).slice(0, 4),
      people: people.filter((p) => p.status === "active" && match(p.full_name)).slice(0, 5),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [term, tasks, projects, resources, announcements, people],
  );

  const go = (fn: () => void) => {
    onOpenChange(false);
    setQ("");
    fn();
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Search tasks, projects, resources, announcements, people…" value={q} onValueChange={setQ} />
      <CommandList>
        <CommandEmpty>No results you have access to.</CommandEmpty>
        {res.tasks.length > 0 && (
          <CommandGroup heading="Tasks">
            {res.tasks.map((t) => (
              <CommandItem key={t.id} value={`task-${t.id}-${t.title}`} onSelect={() => go(() => navigate({ to: "/tasks/$taskId", params: { taskId: t.id } }))}>
                <CheckSquare /> {t.title}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.projects.length > 0 && (
          <CommandGroup heading="Projects">
            {res.projects.map((p) => (
              <CommandItem key={p.id} value={`project-${p.id}-${p.title}`} onSelect={() => go(() => navigate({ to: "/projects/$projectId", params: { projectId: p.id } }))}>
                <FolderKanban /> {p.title}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.resources.length > 0 && (
          <CommandGroup heading="Resources">
            {res.resources.map((r) => (
              <CommandItem key={r.id} value={`res-${r.id}-${r.title}`} onSelect={() => go(() => window.open(r.url, "_blank", "noopener"))}>
                <BookOpen /> {r.title}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.announcements.length > 0 && (
          <CommandGroup heading="Announcements">
            {res.announcements.map((a) => (
              <CommandItem key={a.id} value={`ann-${a.id}-${a.title}`} onSelect={() => go(() => navigate({ to: "/announcements" }))}>
                <Megaphone /> {a.title}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.people.length > 0 && (
          <CommandGroup heading="Team members">
            {res.people.map((p) => (
              <CommandItem key={p.id} value={`person-${p.id}-${p.full_name}`} onSelect={() => go(() => navigate({ to: "/teams" }))}>
                <User /> {p.full_name}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
    </CommandDialog>
  );
}
