import { Link } from "@tanstack/react-router";
import { FolderKanban, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { dueState } from "@/lib/format";
import { useLookup, useMe, type Task } from "@/lib/queries";
import { DueLabel, PriorityBadge, TaskStatusBadge, TeamBadge } from "./bits";

export function TaskRow({ task, showTeam = true, showAssignee = true, showProject = true }: { task: Task; showTeam?: boolean; showAssignee?: boolean; showProject?: boolean }) {
  const me = useMe();
  const { profileById, teamById, projectById } = useLookup();
  const ds = dueState(task.due_date, task.status);
  const assignee = task.assignee_id ? profileById.get(task.assignee_id) : null;
  const project = task.project_id ? projectById.get(task.project_id) : null;
  return (
    <Link
      to="/tasks/$taskId"
      params={{ taskId: task.id }}
      className={cn(
        "group flex flex-col gap-2 rounded-md border bg-card px-3 py-2.5 transition-all hover:-translate-y-px hover:border-border-strong hover:shadow-pixel-sm sm:flex-row sm:items-center",
        ds === "overdue" && "border-l-4 border-l-destructive",
        ds === "soon" && "border-l-4 border-l-highlight",
        ds === "done" && "opacity-75",
      )}
    >
      <div className="min-w-0 flex-1">
        <div className={cn("truncate text-sm font-medium text-foreground", task.status === "completed" && "line-through decoration-muted-foreground")}>{task.title}</div>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          {showTeam && <TeamBadge team={teamById.get(task.team_id)} />}
          {showProject && project && (
            <span className="inline-flex items-center gap-1"><FolderKanban className="size-3" />{project.title}</span>
          )}
          {showAssignee && (
            <span className="inline-flex items-center gap-1"><User className="size-3" />{assignee ? (assignee.id === me.id ? "You" : assignee.full_name) : "Unassigned"}</span>
          )}
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2 sm:justify-end">
        <DueLabel due={task.due_date} status={task.status} tz={me.profile.timezone} />
        <PriorityBadge priority={task.priority} />
        <TaskStatusBadge status={task.status} awaitingReview={task.awaiting_review} />
      </div>
    </Link>
  );
}
