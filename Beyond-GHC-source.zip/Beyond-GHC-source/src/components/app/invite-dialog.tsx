import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { MailPlus } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { teamsQuery } from "@/lib/queries";
import { inviteMember } from "@/lib/admin.functions";
import { errMsg } from "@/lib/format";

export function InviteDialog({
  open,
  onOpenChange,
  initial,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initial?: { email?: string; full_name?: string; submission_id?: string; suggestedTeam?: string | null };
}) {
  const qc = useQueryClient();
  const invite = useServerFn(inviteMember);
  const teams = (useQuery(teamsQuery).data ?? []).filter((t) => !t.archived);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [member, setMember] = useState<string[]>([]);
  const [lead, setLead] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setEmail(initial?.email ?? "");
    setName(initial?.full_name ?? "");
    setMember([]);
    setLead([]);
  }, [open, initial?.email, initial?.full_name]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await invite({
        data: {
          email,
          full_name: name,
          team_ids: member,
          lead_team_ids: lead,
          submission_id: initial?.submission_id ?? null,
          redirect_to: `${window.location.origin}/reset-password`,
        },
      });
      toast.success(res.invited ? `Invitation emailed to ${email}` : "Existing account activated and assigned");
      qc.invalidateQueries();
      onOpenChange(false);
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  const toggle = (list: string[], set: (v: string[]) => void, id: string, on: boolean) => set(on ? [...list, id] : list.filter((x) => x !== id));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><MailPlus className="size-5" /> Create volunteer account</DialogTitle>
          <DialogDescription>They'll get an email with a secure link to choose their password. Their account is active immediately.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5"><Label htmlFor="iv-n">Full name</Label><Input id="iv-n" value={name} onChange={(e) => setName(e.target.value)} required /></div>
            <div className="space-y-1.5"><Label htmlFor="iv-e">Email</Label><Input id="iv-e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
          </div>
          {initial?.suggestedTeam && <p className="rounded-md bg-muted p-2 text-xs text-muted-foreground">Their stated preference: {initial.suggestedTeam}</p>}
          <div className="space-y-2">
            <Label>Teams</Label>
            <div className="divide-y rounded-md border">
              {teams.map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                  <label className="flex items-center gap-2">
                    <Checkbox checked={member.includes(t.id) || lead.includes(t.id)} onCheckedChange={(v) => { toggle(member, setMember, t.id, !!v); if (!v) toggle(lead, setLead, t.id, false); }} />
                    {t.name}
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Checkbox checked={lead.includes(t.id)} onCheckedChange={(v) => { toggle(lead, setLead, t.id, !!v); if (v && !member.includes(t.id)) setMember([...member, t.id]); }} />
                    Team lead
                  </label>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={busy}>{busy ? "Creating…" : "Create & send invite"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
