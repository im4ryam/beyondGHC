import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bell,
  BookOpen,
  CalendarDays,
  CheckSquare,
  ClipboardList,
  Database,
  FileSpreadsheet,
  FolderKanban,
  HelpCircle,
  History,
  Inbox,
  KeyRound,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Megaphone,
  Menu,
  Plug,
  Search,
  ShieldCheck,
  User,
  Users,
  UsersRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { meQuery, notificationsQuery, orgNameQuery, type Me } from "@/lib/queries";
import { UserAvatar } from "./bits";
import { GlobalSearch } from "./global-search";
import { AssignmentWaiting } from "./assignment-waiting";
import { needsAssignment } from "@/lib/access-rules";
import { OnboardingDialog } from "./onboarding";

type NavItem = { to: string; label: string; icon: ReactNode; show?: (me: Me) => boolean };

const MAIN_NAV: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: <LayoutDashboard /> },
  { to: "/account", label: "My Account", icon: <User /> },
  { to: "/teams", label: "My Teams", icon: <UsersRound /> },
  { to: "/tasks", label: "My Tasks", icon: <CheckSquare /> },
  { to: "/projects", label: "Team Projects", icon: <FolderKanban /> },
  { to: "/checklists", label: "Team Checklists", icon: <ListChecks /> },
  { to: "/resources", label: "Resources", icon: <BookOpen /> },
  { to: "/announcements", label: "Announcements", icon: <Megaphone /> },
  { to: "/calendar", label: "Calendar", icon: <CalendarDays /> },
  { to: "/member-data", label: "Member Data", icon: <Database />, show: (me) => !me.isAdmin && me.datasets.length > 0 },
  { to: "/help", label: "Help / Contact", icon: <HelpCircle /> },
];

const ADMIN_NAV: NavItem[] = [
  { to: "/admin", label: "Admin Overview", icon: <ShieldCheck /> },
  { to: "/admin/members", label: "Members", icon: <Users /> },
  { to: "/admin/submissions", label: "Submissions", icon: <Inbox /> },
  { to: "/admin/teams", label: "Manage Teams", icon: <ClipboardList /> },
  { to: "/admin/permissions", label: "Permissions", icon: <KeyRound /> },
  { to: "/admin/activity", label: "Activity Log", icon: <History /> },
  { to: "/admin/integrations", label: "Integrations", icon: <Plug /> },
  { to: "/admin/export", label: "Export Data", icon: <FileSpreadsheet /> },
];

export function Logo({ name, dark }: { name: string; dark?: boolean }) {
  return (
    <span className="flex items-center gap-2">
      <span className={cn("grid size-7 place-items-center rounded-sm border font-pixel text-[10px] shadow-pixel-sm", dark ? "border-sidebar-primary bg-sidebar-primary text-sidebar-primary-foreground" : "border-border-strong bg-highlight text-highlight-foreground")} aria-hidden>
        &gt;_
      </span>
      <span className="font-pixel text-sm tracking-wide">{name}</span>
    </span>
  );
}

function NavList({ items, me, onNavigate }: { items: NavItem[]; me: Me; onNavigate?: (() => void) | undefined }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <ul className="space-y-0.5">
      {items
        .filter((i) => !i.show || i.show(me))
        .map((i) => {
          const active = i.to === "/admin" ? pathname === "/admin" : pathname === i.to || pathname.startsWith(i.to + "/");
          return (
            <li key={i.to}>
              <Link
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                to={i.to as any}
                onClick={onNavigate}
                className={cn(
                  "flex items-center gap-2.5 rounded-sm px-2.5 py-1.5 text-sm transition-colors [&_svg]:size-4",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-[inset_2px_0_0_var(--sidebar-primary)]"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                )}
              >
                {i.icon}
                {i.label}
              </Link>
            </li>
          );
        })}
    </ul>
  );
}

function SidebarBody({ me, orgName, onNavigate }: { me: Me; orgName: string; onNavigate?: (() => void) | undefined }) {
  return (
    <div className="bg-grid-dark flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="border-b border-sidebar-border px-4 py-4">
        <Link to="/dashboard" onClick={onNavigate}>
          <Logo name={orgName} dark />
        </Link>
        <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-sidebar-muted">Volunteer Portal</div>
      </div>
      <nav className="flex-1 space-y-5 overflow-y-auto px-2 py-4" aria-label="Main">
        <NavList items={MAIN_NAV} me={me} onNavigate={onNavigate} />
        {me.isAdmin && (
          <div>
            <div className="eyebrow mb-1.5 px-2.5 text-sidebar-muted">Administration</div>
            <NavList items={ADMIN_NAV} me={me} onNavigate={onNavigate} />
          </div>
        )}
      </nav>
      <div className="border-t border-sidebar-border px-4 py-3 font-mono text-[10px] text-sidebar-muted">
        {me.isOwner ? "PRIMARY OWNER" : me.isAdmin ? "CO-ADMINISTRATOR" : me.isLead ? "TEAM LEAD" : "VOLUNTEER"}
        <span className="ml-1 animate-blink">▌</span>
      </div>
    </div>
  );
}

function NotificationBell() {
  const data = useQuery(notificationsQuery).data ?? [];
  const unread = data.filter((n) => !n.read_at).length;
  return (
    <Button asChild variant="ghost" size="icon" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} className="relative">
      <Link to="/notifications">
        <Bell />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 grid min-w-4 place-items-center rounded-sm border border-border-strong bg-highlight px-1 font-mono text-[10px] font-bold text-highlight-foreground">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </Link>
    </Button>
  );
}

export async function signOutEverywhere(qc: ReturnType<typeof useQueryClient>, navigate: ReturnType<typeof useNavigate>) {
  await qc.cancelQueries();
  qc.clear();
  await supabase.auth.signOut();
  navigate({ to: "/auth", replace: true });
}

function PendingScreen({ me }: { me: Me }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const deactivated = me.profile.status === "deactivated";
  return (
    <div className="bg-grid grid min-h-screen place-items-center bg-background px-4">
      <div className="window w-full max-w-md">
        <div className="titlebar px-3 py-1.5 font-mono text-xs font-semibold uppercase">{deactivated ? "Account deactivated" : "Awaiting approval"}</div>
        <div className="space-y-3 p-6">
          <h1 className="text-xl font-semibold">{deactivated ? "Your account is deactivated" : "Your account is waiting for approval"}</h1>
          <p className="text-sm text-muted-foreground">
            {deactivated
              ? "An administrator has turned off access for this account. Contact the organizers if you think this is a mistake."
              : "Thanks for signing up. An administrator needs to approve your account before you can use the volunteer portal. You'll be able to sign in as soon as that happens."}
          </p>
          <p className="font-mono text-xs text-muted-foreground">Signed in as {me.email}</p>
          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={() => qc.invalidateQueries({ queryKey: ["me"] })}>Check again</Button>
            <Button variant="ghost" onClick={() => signOutEverywhere(qc, navigate)}><LogOut /> Sign out</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { data: me, isLoading, error } = useQuery(meQuery);
  const orgName = useQuery(orgNameQuery).data ?? "Beyond GHC";
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const qc = useQueryClient();
  const navigate = useNavigate();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (isLoading) {
    return (
      <div className="bg-grid grid min-h-screen place-items-center bg-background">
        <div className="font-mono text-sm text-muted-foreground">Loading portal<span className="animate-blink">_</span></div>
      </div>
    );
  }
  if (error || !me) {
    return (
      <div className="grid min-h-screen place-items-center bg-background px-4 text-center">
        <div>
          <p className="text-sm text-muted-foreground">We couldn't load your account.</p>
          <Button className="mt-3" variant="outline" onClick={() => signOutEverywhere(qc, navigate)}>Sign in again</Button>
        </div>
      </div>
    );
  }
  if (needsAssignment(me)) return <AssignmentWaiting me={me} />;
  if (me.profile.status !== "active") return <PendingScreen me={me} />;

  return (
    <div className="min-h-screen bg-background lg:grid lg:grid-cols-[248px_1fr]">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-card focus:px-3 focus:py-2">Skip to content</a>
      <aside className="sticky top-0 hidden h-screen lg:block">
        <SidebarBody me={me} orgName={orgName} />
      </aside>
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-72 border-0 p-0">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <SidebarBody me={me} orgName={orgName} onNavigate={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>
      <div className="flex min-w-0 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-background/90 px-3 backdrop-blur sm:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation" onClick={() => setMobileOpen(true)}>
            <Menu />
          </Button>
          <button
            onClick={() => setSearchOpen(true)}
            className="flex h-9 flex-1 items-center gap-2 rounded-md border bg-card px-3 text-left text-sm text-muted-foreground transition-colors hover:border-border-strong sm:max-w-sm"
          >
            <Search className="size-4" />
            <span className="flex-1 truncate">Search tasks, projects, people…</span>
            <kbd className="hidden rounded-sm border bg-muted px-1.5 font-mono text-[10px] sm:inline">⌘K</kbd>
          </button>
          <div className="ml-auto flex items-center gap-1">
            <NotificationBell />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-md p-1 hover:bg-muted" aria-label="Account menu">
                  <UserAvatar name={me.profile.full_name} url={me.profile.avatar_url} />
                  <span className="hidden max-w-32 truncate text-sm font-medium md:inline">{me.profile.full_name}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="font-normal">
                  <div className="truncate text-sm font-medium">{me.profile.full_name}</div>
                  <div className="truncate text-xs text-muted-foreground">{me.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild><Link to="/account">My account</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link to="/notifications">Notifications</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link to="/help">Help</Link></DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => signOutEverywhere(qc, navigate)}>
                  <LogOut className="size-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main id="main" className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 lg:px-8">
          {children}
        </main>
      </div>
      <GlobalSearch open={searchOpen} onOpenChange={setSearchOpen} />
      {!me.profile.onboarded && <OnboardingDialog />}
    </div>
  );
}
