import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronRight, ExternalLink, Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import {
  dueState,
  fmtDate,
  initials,
  priorityMeta,
  projectStatusMeta,
  taskStatusMeta,
  teamColor,
  type Priority,
  type ProjectStatus,
  type TaskStatus,
} from "@/lib/format";
import type { Team } from "@/lib/queries";

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  crumbs,
}: {
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  crumbs?: { label: string; to?: string; params?: Record<string, string> }[];
}) {
  return (
    <div className="mb-6 animate-rise">
      {crumbs && crumbs.length > 0 && (
        <nav aria-label="Breadcrumb" className="mb-2 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
          {crumbs.map((c, i) => (
            <span key={i} className="flex items-center gap-1">
              {c.to ? (
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                <Link to={c.to as any} params={c.params as any} className="hover:text-foreground hover:underline">
                  {c.label}
                </Link>
              ) : (
                <span className="text-foreground">{c.label}</span>
              )}
              {i < crumbs.length - 1 && <ChevronRight className="size-3" />}
            </span>
          ))}
        </nav>
      )}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          {eyebrow && <div className="eyebrow mb-1 text-highlight">{eyebrow}</div>}
          <h1 className="text-2xl font-semibold text-foreground sm:text-3xl">{title}</h1>
          {description && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </div>
  );
}

export function Window({
  title,
  icon,
  actions,
  children,
  className,
  bodyClassName,
}: {
  title: ReactNode;
  icon?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <section className={cn("window overflow-hidden", className)}>
      <header className="titlebar flex items-center justify-between gap-2 px-3 py-1.5">
        <div className="flex min-w-0 items-center gap-2">
          <span className="flex gap-1" aria-hidden>
            <span className="size-2 border border-border-strong bg-highlight" />
            <span className="size-2 border border-border-strong bg-card" />
          </span>
          {icon && <span className="text-muted-foreground [&_svg]:size-3.5">{icon}</span>}
          <h2 className="truncate font-mono text-xs font-semibold uppercase tracking-wide text-foreground">{title}</h2>
        </div>
        {actions && <div className="flex items-center gap-1">{actions}</div>}
      </header>
      <div className={cn("p-4", bodyClassName)}>{children}</div>
    </section>
  );
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "dusty",
  to,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  tone?: "dusty" | "sage" | "amber" | "lavender" | "plum" | "slate" | "danger";
  to?: string;
}) {
  const tones: Record<string, string> = {
    dusty: "bg-dusty-soft text-dusty",
    sage: "bg-sage-soft text-sage",
    amber: "bg-amber-soft text-amber",
    lavender: "bg-lavender-soft text-lavender",
    plum: "bg-plum-soft text-plum",
    slate: "bg-slate-soft text-slate",
    danger: "bg-danger-soft text-destructive",
  };
  const inner = (
    <div className="panel flex h-full items-start gap-3 p-4 transition-shadow hover:shadow-pixel-sm">
      {icon && <div className={cn("grid size-9 shrink-0 place-items-center rounded-md [&_svg]:size-4", tones[tone])}>{icon}</div>}
      <div className="min-w-0">
        <div className="text-xs font-medium text-muted-foreground">{label}</div>
        <div className="mt-0.5 font-mono text-2xl font-semibold tabular-nums text-foreground">{value}</div>
        {hint && <div className="mt-0.5 text-xs text-muted-foreground">{hint}</div>}
      </div>
    </div>
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return to ? <Link to={to as any} className="block focus-visible:rounded-lg">{inner}</Link> : inner;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  compact,
}: {
  icon?: ReactNode;
  title: string;
  description?: ReactNode;
  action?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-grid text-center", compact ? "px-4 py-6" : "px-6 py-12")}>
      {icon && <div className="mb-3 grid size-10 place-items-center rounded-md border border-border-strong bg-card text-muted-foreground shadow-pixel-sm [&_svg]:size-5">{icon}</div>}
      <div className="text-sm font-semibold text-foreground">{title}</div>
      {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function TaskStatusBadge({ status, awaitingReview }: { status: TaskStatus; awaitingReview?: boolean }) {
  const m = taskStatusMeta(status);
  return (
    <span className="inline-flex flex-wrap gap-1">
      <Badge variant={m.variant}>{m.label}</Badge>
      {awaitingReview && status !== "completed" && <Badge variant="lavender">Awaiting review</Badge>}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  const m = priorityMeta(priority);
  return <Badge variant={m.variant}>{m.label}</Badge>;
}

export function ProjectStatusBadge({ status }: { status: ProjectStatus }) {
  const m = projectStatusMeta(status);
  return <Badge variant={m.variant}>{m.label}</Badge>;
}

export function DueLabel({ due, status, tz }: { due: string | null; status: TaskStatus; tz?: string }) {
  const s = dueState(due, status);
  if (s === "none") return <span className="text-xs text-muted-foreground">No deadline</span>;
  const label = fmtDate(due, tz);
  if (s === "overdue") return <span className="text-xs font-semibold text-destructive">Overdue · {label}</span>;
  if (s === "soon") return <span className="text-xs font-semibold text-amber">Due soon · {label}</span>;
  if (s === "done") return <span className="text-xs text-muted-foreground line-through">{label}</span>;
  return <span className="text-xs text-muted-foreground">Due {label}</span>;
}

export function TeamBadge({ team }: { team?: Team | null | undefined }) {
  if (!team) return <Badge variant="outline">Organization-wide</Badge>;
  const c = teamColor(team.color);
  return (
    <Badge variant={c.variant}>
      <span className={cn("size-1.5 rounded-full", c.dot)} />
      {team.name}
    </Badge>
  );
}

export function UserAvatar({ name, url, size = "md" }: { name?: string | null | undefined; url?: string | null | undefined; size?: "sm" | "md" | "lg" | undefined }) {
  const sz = size === "sm" ? "size-6 text-[10px]" : size === "lg" ? "size-16 text-lg" : "size-8 text-xs";
  return url ? (
    <img src={url} alt="" className={cn("shrink-0 rounded-md border border-border-strong object-cover", sz)} />
  ) : (
    <span className={cn("grid shrink-0 place-items-center rounded-md border border-border-strong bg-secondary font-mono font-semibold text-secondary-foreground", sz)} aria-hidden>
      {initials(name)}
    </span>
  );
}

export function ProgressBar({ value, className, label }: { value: number; className?: string; label?: string }) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className="relative h-2.5 flex-1 overflow-hidden rounded-sm border border-border-strong bg-muted"
        role="progressbar"
        aria-valuenow={v}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label ?? "Progress"}
      >
        <div className="progress-stripes h-full transition-all duration-500" style={{ width: `${v}%` }} />
      </div>
      <span className="w-9 text-right font-mono text-xs tabular-nums text-muted-foreground">{v}%</span>
    </div>
  );
}

export function ConfirmAction({
  trigger,
  title,
  description,
  confirmLabel = "Confirm",
  destructive,
  onConfirm,
}: {
  trigger: ReactNode;
  title: string;
  description?: ReactNode;
  confirmLabel?: string;
  destructive?: boolean;
  onConfirm: () => unknown;
}) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{trigger}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          {description && <AlertDialogDescription>{description}</AlertDialogDescription>}
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={() => void onConfirm()}
            className={destructive ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : undefined}
          >
            {confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function ExternalResourceLink({ url, title, requiresAccess }: { url: string; title?: string; requiresAccess?: boolean }) {
  let host = url;
  try {
    host = new URL(url).hostname.replace(/^www\./, "");
  } catch {
    /* keep raw */
  }
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="group inline-flex max-w-full items-center gap-1.5 text-sm text-primary hover:underline">
      <ExternalLink className="size-3.5 shrink-0" />
      <span className="truncate">{title ?? host}</span>
      <span className="shrink-0 text-xs text-muted-foreground">({host})</span>
      {requiresAccess && (
        <span title="You may need separate access permission to open this" className="inline-flex shrink-0 items-center gap-0.5 text-xs text-amber">
          <Lock className="size-3" /> access may be required
        </span>
      )}
    </a>
  );
}

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-2" aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-12 animate-pulse rounded-md bg-muted" />
      ))}
    </div>
  );
}

export function NoAccess({ message }: { message?: string }) {
  return (
    <EmptyState
      icon={<Lock />}
      title="You don't have access to this page"
      description={message ?? "Ask an administrator if you think you should be able to see this."}
    />
  );
}
