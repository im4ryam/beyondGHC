import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { errMsg } from "@/lib/format";
import type { Me } from "@/lib/queries";
import { signOutEverywhere } from "./shell";

export function AssignmentWaiting({ me }: { me: Me }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [name, setName] = useState(me.profile.full_name);
  const [phone, setPhone] = useState(me.phone ?? "");
  const [busy, setBusy] = useState(false);
  const request = useQuery({
    queryKey: ["assignment_request", me.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("assignment_requests").select("status").eq("user_id", me.id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const sent = request.data?.status === "pending";
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.rpc("request_team_assignment", { _full_name: name, _phone: phone });
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    await qc.invalidateQueries({ queryKey: ["assignment_request"] });
    toast.success("Request sent to the administrators");
  }
  return (
    <main className="bg-grid grid min-h-screen place-items-center bg-background px-4">
      <div className="w-full max-w-lg space-y-5">
        <div className="eyebrow">Beyond GHC · Welcome</div>
        <h1 className="text-2xl font-semibold">{sent ? "Your request has been sent" : "The admin hasn’t assigned you to a team yet. Send them a request now."}</h1>
        {sent ? <p className="text-sm text-muted-foreground">You’re waiting for team assignment. Your access will update here when an administrator approves it.</p> : (
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="rq-name">Full name</Label><Input id="rq-name" value={name} onChange={(e) => setName(e.target.value)} required maxLength={200} /></div>
            <div className="space-y-1.5"><Label htmlFor="rq-email">Email</Label><Input id="rq-email" value={me.email} disabled /></div>
            <div className="space-y-1.5"><Label htmlFor="rq-phone">Phone number</Label><Input id="rq-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} minLength={3} maxLength={50} required /></div>
            <Button type="submit" disabled={busy || request.isPending}>{busy ? "Sending…" : "Send assignment request"}</Button>
          </form>
        )}
        {request.error && <p role="alert" className="text-sm text-destructive">Couldn’t load your request. Please check again.</p>}
        <p className="text-xs text-muted-foreground">Signed in as {me.email}</p>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => qc.invalidateQueries()}>Check access again</Button>
          <Button variant="ghost" onClick={() => signOutEverywhere(qc, navigate)}>Sign out</Button>
        </div>
      </div>
    </main>
  );
}