import { useState } from "react";
import { toast } from "sonner";
import { Copy, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { errMsg } from "@/lib/format";

export function SignupLinkDialog() {
  const [open, setOpen] = useState(false);
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState(false);
  async function generate() {
    setBusy(true);
    const { data, error } = await supabase.rpc("create_signup_invitation");
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    setLink(`${window.location.origin}/join?token=${encodeURIComponent(data)}`);
  }
  async function copy() {
    try { await navigator.clipboard.writeText(link); toast.success("Invitation link copied"); }
    catch { toast.error("Select the link and copy it manually"); }
  }
  return <>
    <Button variant="outline" onClick={() => { setOpen(true); setLink(""); }}><Link2 /> Create invitation link</Button>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent><DialogHeader><DialogTitle>Share a signup invitation</DialogTitle><DialogDescription>One person can use this link within 7 days. They’ll confirm their email and request team assignment before getting access.</DialogDescription></DialogHeader>
      {link ? <div className="space-y-3"><Label htmlFor="signup-link">Invitation link</Label><div className="flex gap-2"><Input id="signup-link" value={link} readOnly /><Button variant="outline" size="icon" aria-label="Copy invitation link" onClick={copy}><Copy /></Button></div></div> : <Button onClick={generate} disabled={busy}>{busy ? "Creating…" : "Generate link"}</Button>}
    </DialogContent></Dialog>
  </>;
}