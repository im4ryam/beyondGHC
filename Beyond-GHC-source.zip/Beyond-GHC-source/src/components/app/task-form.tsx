import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { membersQuery, profilesQuery, projectsQuery, teamsQuery, useMe, canManageTeam, type Task } from "@/lib/queries";
import { PRIORITIES, TASK_STATUSES, dateInputValue, endOfDayInZone, errMsg, type Priority, type TaskStatus } from "@/lib/format";

import { canCreateTeamTask, taskAssignee } from "@/lib/access-rules";

type Link = { title: string; url: string };
const NONE = "__none";

export function TaskFormDialog({
  open,
  onOpenChange,
  task,
  defaultTeamId,
  defaultProjectId,
  defaultAssigneeId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  task?: Task | null | undefined;
  defaultTeamId?: string | undefined;
  defaultProjectId?: string | undefined;
  defaultAssigneeId?: string | undefined;
}) {
  const me = useMe();
  const qc = useQueryClient();
  const tz = me.profile.timezone;
  const teams = (useQuery(teamsQuery).data ?? []).filter((t) => !t.archived && (task ? canManageTeam(me, t.id) : canCreateTeamTask(me, t.id)));
  const projects = useQuery(projectsQuery).data ?? [];
  const members = useQuery(membersQuery).data ?? [];
  const profiles = useQuery(profilesQuery).data ?? [];

  const [teamId, setTeamId] = useState("");
  const [projectId, setProjectId] = useState(NONE);
  const [assigneeId, setAssigneeId] = useState(NONE);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [instructions, setInstructions] = useState("");
  const [due, setDue] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [status, setStatus] = useState<TaskStatus>("incomplete");
  const [links, setLinks] = useState<Link[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTeamId(task?.team_id ?? defaultTeamId ?? teams[0]?.id ?? "");
    setProjectId(task?.project_id ?? defaultProjectId ?? NONE);
    setAssigneeId(task?.assignee_id ?? defaultAssigneeId ?? (me.isAdmin || me.isLead ? NONE : me.id));
    setTitle(task?.title ?? "");
    setDescription(task?.description ?? "");
    setInstructions(task?.instructions ?? "");
    setDue(dateInputValue(task?.due_date, tz));
    setPriority(task?.priority ?? "medium");
    setStatus(task?.status ?? "incomplete");
    setLinks(Array.isArray(task?.resource_links) ? (task?.resource_links as Link[]) : []);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, task?.id]);

  const teamProjects = useMemo(
    () => projects.filter((p) => p.team_id === teamId && p.status !== "archived"),
    [projects, teamId],
  );
  const teamMembers = useMemo(() => {
    const ids = new Set(members.filter((m) => m.team_id === teamId).map((m) => m.user_id));
    return profiles.filter((p) => ids.has(p.id) && p.status === "active");
  }, [members, profiles, teamId]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) { toast.error("Give the task a title"); return; }
    if (!teamId) { toast.error("Choose a team"); return; }
    const cleanLinks = links.filter((l) => l.url.trim()).map((l) => ({ title: l.title.trim() || l.url.trim(), url: l.url.trim() }));
    for (const l of cleanLinks) {
      try {
        new URL(l.url);
      } catch {
        { toast.error(`"${l.url}" is not a valid link. Include https://`); return; }
      }
    }
    setSaving(true);
    const payload = {
      team_id: teamId,
      project_id: projectId === NONE ? null : projectId,
      assignee_id: taskAssignee(me, teamId, assigneeId === NONE ? null : assigneeId),
      title: title.trim(),
      description: description.trim() || null,
      instructions: instructions.trim() || null,
      due_date: due ? endOfDayInZone(due, tz) : null,
      priority,
      status,
      resource_links: cleanLinks,
    };
    const { error } = task
      ? await supabase.from("tasks").update(payload).eq("id", task.id)
      : await supabase.from("tasks").insert({ ...payload, created_by: me.id });
    setSaving(false);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(task ? "Task updated" : "Task created");
    qc.invalidateQueries({ queryKey: ["tasks"] });
    qc.invalidateQueries({ queryKey: ["activity"] });
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{task ? "Edit task" : "New task"}</DialogTitle>
          <DialogDescription>Deadlines are saved as end of day in your time zone ({tz}).</DialogDescription>
        </DialogHeader>
        {teams.length === 0 ? (
          <p className="text-sm text-muted-foreground">Join a team before creating tasks.</p>
        ) : (
          <form onSubmit={save} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="t-title">Title</Label>
              <Input id="t-title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} required />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Team</Label>
                <Select value={teamId} onValueChange={(v) => { setTeamId(v); setProjectId(NONE); setAssigneeId(taskAssignee(me, v, null) ?? NONE); }}>
                  <SelectTrigger><SelectValue placeholder="Choose team" /></SelectTrigger>
                  <SelectContent>{teams.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Project</Label>
                <Select value={projectId} onValueChange={setProjectId}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>No project (individual task)</SelectItem>
                    {teamProjects.map((p) => <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Assigned to</Label>
                <Select value={canManageTeam(me, teamId) ? assigneeId : me.id} onValueChange={setAssigneeId} disabled={!canManageTeam(me, teamId)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {canManageTeam(me, teamId) && <SelectItem value={NONE}>Unassigned</SelectItem>}
                    {teamMembers.map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="t-due">Due date</Label>
                <Input id="t-due" type="date" value={due} onChange={(e) => setDue(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PRIORITIES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={status} onValueChange={(v) => setStatus(v as TaskStatus)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TASK_STATUSES.filter((s) => canManageTeam(me, teamId) || s.value !== "completed").map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="t-desc">Description</Label>
              <Textarea id="t-desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="t-ins">Instructions</Label>
              <Textarea id="t-ins" rows={3} value={instructions} onChange={(e) => setInstructions(e.target.value)} placeholder="Steps, expectations, what 'done' looks like…" />
            </div>
            <div className="space-y-2">
              <Label>Related links</Label>
              {links.map((l, i) => (
                <div key={i} className="flex gap-2">
                  <Input placeholder="Label" value={l.title} onChange={(e) => setLinks(links.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)))} className="w-1/3" />
                  <Input placeholder="https://…" value={l.url} onChange={(e) => setLinks(links.map((x, j) => (j === i ? { ...x, url: e.target.value } : x)))} />
                  <Button type="button" variant="ghost" size="icon" aria-label="Remove link" onClick={() => setLinks(links.filter((_, j) => j !== i))}><X /></Button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={() => setLinks([...links, { title: "", url: "" }])}><Plus /> Add link</Button>
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving…" : task ? "Save changes" : "Create task"}</Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
