import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { BookOpen, CheckSquare, ListChecks, MessageCircle, RefreshCw, UsersRound } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useMe } from "@/lib/queries";

const STEPS = [
  { icon: <UsersRound />, title: "View your teams", body: "“My Teams” shows every team you belong to, its lead, members, objectives and progress." },
  { icon: <CheckSquare />, title: "Find your tasks", body: "“My Tasks” is your personal checklist. Overdue items are marked in red, items due soon in orange." },
  { icon: <RefreshCw />, title: "Update task statuses", body: "Open a task to move it to In Progress, add notes, and press “Submit for review” when it's ready. Your lead marks it Completed." },
  { icon: <ListChecks />, title: "Check team checklists", body: "“Team Checklists” shows every shared project and who is responsible for each item." },
  { icon: <BookOpen />, title: "Find resources", body: "Templates, guidelines, forms and shared folders live under “Resources”, organized by team." },
  { icon: <MessageCircle />, title: "Contact your team lead", body: "Each team page lists the lead's contact details. You can also comment on any task to ask a question." },
];

export function OnboardingDialog() {
  const me = useMe();
  const qc = useQueryClient();
  const [open, setOpen] = useState(true);
  const [step, setStep] = useState(0);

  async function finish() {
    setOpen(false);
    await supabase.from("profiles").update({ onboarded: true }).eq("id", me.id);
    qc.invalidateQueries({ queryKey: ["me"] });
  }

  const s = STEPS[step] ?? STEPS[0]!;
  return (
    <Dialog open={open} onOpenChange={(o) => !o && finish()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="eyebrow text-highlight">Welcome · step {step + 1} of {STEPS.length}</div>
          <DialogTitle className="flex items-center gap-2 pt-1 text-xl [&_svg]:size-5">{s.icon}{s.title}</DialogTitle>
          <DialogDescription className="pt-1 text-sm leading-relaxed">{s.body}</DialogDescription>
        </DialogHeader>
        <div className="flex gap-1" aria-hidden>
          {STEPS.map((_, i) => (
            <span key={i} className={`h-1.5 flex-1 rounded-sm border border-border-strong ${i <= step ? "bg-highlight" : "bg-muted"}`} />
          ))}
        </div>
        <div className="flex justify-between gap-2 pt-2">
          <Button variant="ghost" onClick={finish}>Skip tour</Button>
          <div className="flex gap-2">
            {step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)}>Back</Button>}
            {step < STEPS.length - 1 ? (
              <Button onClick={() => setStep(step + 1)}>Next</Button>
            ) : (
              <Button variant="highlight" onClick={finish}>Get started</Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
