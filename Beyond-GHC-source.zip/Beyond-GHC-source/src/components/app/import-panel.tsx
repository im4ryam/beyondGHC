import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { FileUp, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { isValidEmail, mapRecord, type SubmissionRow } from "@/lib/submission-mapping";
import { errMsg } from "@/lib/format";

type Parsed = { sheet: string; rows: SubmissionRow[]; invalid: number; dupInFile: number };

export function ImportPanel() {
  const qc = useQueryClient();
  const [book, setBook] = useState<Record<string, Record<string, unknown>[]> | null>(null);
  const [sheet, setSheet] = useState("");
  const [fileName, setFileName] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Record<string, number> | null>(null);

  async function onFile(file?: File) {
    if (!file) return;
    setResult(null);
    setFileName(file.name);
    const XLSX = await import("xlsx");
    const wb = XLSX.read(await file.arrayBuffer(), { cellDates: true });
    const out: Record<string, Record<string, unknown>[]> = {};
    for (const name of wb.SheetNames) {
      const ws = wb.Sheets[name];
      if (ws) out[name] = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });
    }
    setBook(out);
    // Prefer a sheet that has an email column
    const best = wb.SheetNames.find((n) => (out[n]?.[0] ? Object.keys(out[n][0]!).some((k) => /e-?mail/i.test(k)) : false)) ?? wb.SheetNames[0] ?? "";
    setSheet(best);
  }

  const parsed: Parsed | null = (() => {
    if (!book || !sheet || !book[sheet]) return null;
    const seen = new Set<string>();
    let invalid = 0;
    let dupInFile = 0;
    const rows: SubmissionRow[] = [];
    for (const rec of book[sheet]) {
      const r = mapRecord(rec);
      if (!isValidEmail(r.email)) { invalid++; continue; }
      if (seen.has(r.email!)) dupInFile++;
      seen.add(r.email!);
      rows.push(r);
    }
    return { sheet, rows, invalid, dupInFile };
  })();

  async function run() {
    if (!parsed?.rows.length) return;
    setBusy(true);
    const { data, error } = await supabase.rpc("import_submissions", { _rows: parsed.rows as never, _source: `import:${fileName}` });
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    setResult(data as Record<string, number>);
    toast.success("Import finished");
    qc.invalidateQueries({ queryKey: ["submissions"] });
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Upload a CSV or Excel export from Google Forms, Microsoft Forms, or your own spreadsheet. Columns are matched by their question text. People are matched by email: repeat submissions update the existing record instead of creating duplicates, and every original response is kept in its history.
      </p>
      <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed bg-muted/40 px-4 py-8 text-center hover:border-border-strong">
        <FileUp className="size-6 text-muted-foreground" />
        <span className="text-sm font-medium">{fileName || "Choose a .xlsx or .csv file"}</span>
        <input type="file" accept=".xlsx,.xls,.csv" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
      </label>
      {book && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span>Sheet:</span>
            <Select value={sheet} onValueChange={setSheet}>
              <SelectTrigger className="w-64"><SelectValue /></SelectTrigger>
              <SelectContent>{Object.keys(book).map((n) => <SelectItem key={n} value={n}>{n} ({book[n]?.length ?? 0} rows)</SelectItem>)}</SelectContent>
            </Select>
          </div>
          {parsed && (
            <div className="rounded-md border bg-card p-3 font-mono text-xs">
              <div>{parsed.rows.length} rows ready to import</div>
              <div className="text-muted-foreground">{parsed.invalid} skipped (no valid email) · {parsed.dupInFile} repeat emails within the file (will be merged)</div>
              <div className="text-muted-foreground">{parsed.rows.filter((r) => r.volunteer_interest).length} interested in volunteering · {parsed.rows.filter((r) => r.speaker_interest).length} interested in speaking</div>
            </div>
          )}
          <Button onClick={run} disabled={busy || !parsed?.rows.length}><Upload /> {busy ? "Importing…" : "Import rows"}</Button>
        </div>
      )}
      {result && (
        <div className="rounded-md border border-sage/40 bg-sage-soft p-3 text-sm">
          <strong>Import results:</strong> {result["inserted"] ?? 0} new · {result["updated"] ?? 0} updated (same email) · {result["duplicates"] ?? 0} already imported · {result["skipped"] ?? 0} skipped
        </div>
      )}
    </div>
  );
}
