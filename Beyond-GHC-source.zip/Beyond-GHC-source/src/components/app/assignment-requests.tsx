import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { teamsQuery, profilesQuery, useMe } from "@/lib/queries";
import { errMsg } from "@/lib/format";

export function AssignmentRequests() {
  const me = useMe();
  const qc = useQueryClient();
  const profiles = useQuery(profilesQuery).data ?? [];
  const teams = (useQuery(teamsQuery).data ?? []).filter((t) => !t.archived);
  const contacts = useQuery({ queryKey: ["admin_private"], queryFn: async () => {
    const { data, error } = await supabase.from("profile_private").select("user_id,email,phone");
    if (error) throw error;
    return data;
  } }).data ?? [];
  const requests = useQuery({ queryKey: ["assignment_requests"], refetchInterval: 15000, queryFn: async () => {
    const { data, error } = await supabase.from("assignment_requests").select("*").eq("status", "pending").order("requested_at");
    if (error) throw error;
    return data;
  } });
  const [target, setTarget] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [coadmin, setCoadmin] = useState(false);
  const [busy, setBusy] = useState(false);
  async function approve() {
    if (!target) return;
    setBusy(true);
    const { error } = await supabase.rpc("approve_assignment_request", { _target: target, _teams: selected, _coadmin: coadmin });
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Access approved");
    setTarget(null);
    qc.invalidateQueries();
  }
  if (requests.error) return <p role="alert" className="mb-4 text-sm text-destructive">Couldn’t load assignment requests.</p>;
  if (!requests.data?.length) return null;
  return (
    <section className="mb-6 border-y border-border py-4">
      <h2 className="mb-3 text-lg font-semibold">Team assignment requests ({requests.data.length})</h2>
      <ul className="divide-y">
        {requests.data.map((r) => {
          const profile = profiles.find((p) => p.id === r.user_id);
          const contact = contacts.find((p) => p.user_id === r.user_id);
          return <li key={r.user_id} className="flex flex-wrap items-center justify-between gap-3 py-3">
            <div className="min-w-0"><p className="font-medium">{profile?.full_name}</p><p className="break-all text-sm text-muted-foreground">{contact?.email}</p><p className="text-sm text-muted-foreground">{contact?.phone}</p></div>
            <Button variant="outline" onClick={() => { setTarget(r.user_id); setSelected([]); setCoadmin(false); }}>Assign access</Button>
          </li>;
        })}
      </ul>
      <Dialog open={target !== null} onOpenChange={(o) => !o && setTarget(null)}>
        <DialogContent><DialogHeader><DialogTitle>Assign access to {profiles.find((p) => p.id === target)?.full_name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {teams.map((t) => <label key={t.id} className="flex items-center gap-2 text-sm"><Checkbox checked={selected.includes(t.id)} onCheckedChange={(v) => setSelected(v ? [...selected, t.id] : selected.filter((id) => id !== t.id))} />{t.name}</label>)}
            {me.isOwner && <label className="flex items-center gap-2 border-t pt-3 text-sm"><Checkbox checked={coadmin} onCheckedChange={(v) => setCoadmin(v === true)} />Co-Administrator</label>}
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setTarget(null)}>Cancel</Button><Button onClick={approve} disabled={busy || (!selected.length && !coadmin)}>{busy ? "Approving…" : "Approve access"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}