import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { orgNameQuery } from "@/lib/queries";
import { Logo } from "./shell";

export function AuthFrame({ title, subtitle, children, footer }: { title: string; subtitle?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  const org = useQuery(orgNameQuery).data ?? "Beyond GHC";
  return (
    <div className="bg-grid flex min-h-screen flex-col bg-background">
      <header className="px-6 py-5">
        <Link to="/" className="inline-block"><Logo name={org} /></Link>
      </header>
      <main className="flex flex-1 items-start justify-center px-4 pb-16 pt-6 sm:items-center sm:pt-0">
        <div className="window w-full max-w-md animate-rise">
          <div className="titlebar flex items-center gap-2 px-3 py-1.5">
            <span className="flex gap-1" aria-hidden>
              <span className="size-2 border border-border-strong bg-highlight" />
              <span className="size-2 border border-border-strong bg-card" />
            </span>
            <span className="font-mono text-xs font-semibold uppercase tracking-wide">{title}</span>
          </div>
          <div className="p-6 sm:p-8">
            <h1 className="text-2xl font-semibold">{title}</h1>
            {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
            <div className="mt-6">{children}</div>
          </div>
          {footer && <div className="border-t bg-muted/50 px-6 py-3 text-sm text-muted-foreground sm:px-8">{footer}</div>}
        </div>
      </main>
    </div>
  );
}
