import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { AuthFrame } from "@/components/app/auth-frame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/join")({
  validateSearch: (search: Record<string, unknown>) => ({ token: typeof search["token"] === "string" ? search["token"] : "" }),
  head: () => ({ meta: [
    { title: "Accept invitation — Beyond GHC" }, { name: "description", content: "Create your invited Beyond GHC volunteer account." },
    { property: "og:title", content: "Accept invitation — Beyond GHC" }, { property: "og:description", content: "Join the Beyond GHC volunteer portal by invitation." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }, { name: "robots", content: "noindex" },
  ] }),
  component: JoinPage,
});

function JoinPage() {
  const { token } = Route.useSearch();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const valid = useQuery({ queryKey: ["invitation_valid", token], queryFn: async () => {
    if (!token) return false;
    const { data, error } = await supabase.rpc("valid_signup_invitation", { _token: token });
    if (error) throw error;
    return data;
  } });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const { data, error } = await supabase.auth.signUp({ email: form.email.trim(), password: form.password, options: {
      emailRedirectTo: window.location.origin,
      data: { full_name: form.name.trim(), phone: form.phone.trim(), invitation_token: token },
    } });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    if (data.session) navigate({ to: "/dashboard", replace: true });
    else setSent(true);
  }
  return <AuthFrame title={sent ? "Check your email" : "You’re invited"} subtitle={sent ? "Confirm your email, then sign in to request your team assignment." : "Create your Beyond GHC account."}>
    {sent ? <Button asChild className="w-full"><Link to="/auth">Go to sign in</Link></Button> : valid.isPending ? <p>Checking invitation…</p> : !valid.data ? <p role="alert">{valid.error ? "Couldn’t check this invitation. Please refresh." : "This invitation is invalid, expired, or already used. Ask an administrator for a new link."}</p> : (
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5"><Label htmlFor="join-name">Full name</Label><Input id="join-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoComplete="name" maxLength={200} required /></div>
        <div className="space-y-1.5"><Label htmlFor="join-email">Email</Label><Input id="join-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} autoComplete="email" required /></div>
        <div className="space-y-1.5"><Label htmlFor="join-phone">Phone number</Label><Input id="join-phone" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} autoComplete="tel" minLength={3} maxLength={50} required /></div>
        <div className="space-y-1.5"><Label htmlFor="join-password">Password</Label><Input id="join-password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete="new-password" minLength={8} required /></div>
        <Button type="submit" className="w-full" disabled={busy}>{busy ? "Creating…" : "Create account"}</Button>
        <p className="text-sm"><Link to="/auth" className="text-primary hover:underline">Already have an account? Sign in</Link></p>
      </form>
    )}
  </AuthFrame>;
}