import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { MailCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { AuthFrame } from "@/components/app/auth-frame";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Reset your password — Beyond GHC" },
      { name: "description", content: "Request a password reset link for your Beyond GHC volunteer account." },
      { property: "og:title", content: "Reset your password — Beyond GHC" },
      { property: "og:description", content: "Request a password reset link for your volunteer account." },
    ],
  }),
  component: ForgotPage,
});

function ForgotPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/reset-password` });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setSent(true);
  }
  return (
    <AuthFrame title="Forgot password" subtitle="We'll email you a secure link to choose a new password." footer={<Link to="/auth" className="text-primary hover:underline">Back to sign in</Link>}>
      {sent ? (
        <div className="flex gap-3 rounded-md border bg-sage-soft p-4 text-sm">
          <MailCheck className="size-5 shrink-0 text-sage" />
          <p>If an account exists for <strong>{email}</strong>, a reset link is on its way. Check your spam folder too.</p>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>{loading ? "Sending…" : "Send reset link"}</Button>
        </form>
      )}
    </AuthFrame>
  );
}
