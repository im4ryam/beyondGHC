import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { AuthFrame } from "@/components/app/auth-frame";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Sign in — Beyond GHC Volunteer Portal" },
      { name: "description", content: "Sign in to the Beyond GHC volunteer portal to see your teams, tasks and projects." },
      { property: "og:title", content: "Sign in — Beyond GHC Volunteer Portal" },
      { property: "og:description", content: "Sign in to the Beyond GHC volunteer portal." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const ownerExists = useQuery({
    queryKey: ["owner_exists"],
    queryFn: async () => (await supabase.rpc("owner_exists")).data ?? true,
  }).data;

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) {
      toast.error(error.message === "Invalid login credentials" ? "That email and password don't match an account." : error.message);
      return;
    }
    navigate({ to: "/dashboard", replace: true });
  }

  return (
    <AuthFrame
      title="Sign in"
      subtitle="Volunteer accounts are created by an administrator. Use the email your invitation was sent to."
      footer={
        ownerExists === false ? (
          <span>
            Setting up the platform for the first time?{" "}
            <Link to="/setup" className="font-medium text-primary hover:underline">Primary Owner setup</Link>
          </span>
        ) : (
          <span>
            Interested in volunteering? Fill out the community interest form — an administrator will reach out.
          </span>
        )
      }
    >
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Password</Label>
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</Link>
          </div>
          <Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <Button type="submit" className="w-full" disabled={loading}>{loading ? "Signing in…" : "Sign in"}</Button>
      </form>
    </AuthFrame>
  );
}
