import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { MailCheck, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { AuthFrame } from "@/components/app/auth-frame";

export const Route = createFileRoute("/setup")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Primary Owner setup — Beyond GHC" },
      { name: "description", content: "One-time secure setup for the founder's Primary Owner account." },
      { property: "og:title", content: "Primary Owner setup — Beyond GHC" },
      { property: "og:description", content: "One-time secure setup for the founder's Primary Owner account." },
    ],
  }),
  component: SetupPage,
});

function SetupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const ownerExists = useQuery({
    queryKey: ["owner_exists"],
    queryFn: async () => (await supabase.rpc("owner_exists")).data ?? true,
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) { toast.error("Use at least 8 characters for your password"); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
      options: { emailRedirectTo: `${window.location.origin}/dashboard`, data: { full_name: name.trim() } },
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setSent(true);
  }

  if (ownerExists.data) {
    return (
      <AuthFrame title="Setup complete" subtitle="The Primary Owner account has already been set up.">
        <Button asChild className="w-full"><Link to="/auth">Go to sign in</Link></Button>
      </AuthFrame>
    );
  }

  if (sent) {
    return (
      <AuthFrame title="Confirm your email" subtitle="One more step to secure the owner account.">
        <div className="flex gap-3 rounded-md border bg-sage-soft p-4 text-sm">
          <MailCheck className="size-5 shrink-0 text-sage" />
          <p>
            We sent a confirmation link to <strong>{email}</strong>. Owner access is granted only after you click it, which proves you control this inbox.
          </p>
        </div>
        <Button asChild variant="outline" className="mt-4 w-full"><Link to="/auth">Back to sign in</Link></Button>
      </AuthFrame>
    );
  }

  return (
    <AuthFrame
      title="Primary Owner setup"
      subtitle="This one-time setup creates the founder's account. Only the pre-registered founder email can receive owner access, and only after confirming it."
    >
      <div className="mb-4 flex gap-2 rounded-md border border-dusty/30 bg-dusty-soft p-3 text-xs text-dusty">
        <ShieldCheck className="size-4 shrink-0" />
        Anyone else who signs up here will get a regular account that stays locked until an administrator approves it.
      </div>
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="name">Full name</Label>
          <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="email">Founder email</Label>
          <Input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="password">Password</Label>
          <Input id="password" type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <Button type="submit" className="w-full" disabled={loading}>{loading ? "Creating…" : "Create owner account"}</Button>
      </form>
    </AuthFrame>
  );
}
