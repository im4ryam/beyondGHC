import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { AuthFrame } from "@/components/app/auth-frame";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Choose a new password — Beyond GHC" },
      { name: "description", content: "Set a new password for your Beyond GHC volunteer account." },
      { property: "og:title", content: "Choose a new password — Beyond GHC" },
      { property: "og:description", content: "Set a new password for your volunteer account." },
    ],
  }),
  component: ResetPage,
});

function ResetPage() {
  const navigate = useNavigate();
  const [ready, setReady] = useState<"checking" | "ok" | "invalid">("checking");
  const [isInvite, setIsInvite] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const hash = window.location.hash;
    const invite = hash.includes("type=invite");
    const recovery = hash.includes("type=recovery") || sessionStorage.getItem("password-recovery") === "true";
    setIsInvite(invite);
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if ((event === "PASSWORD_RECOVERY" || (event === "SIGNED_IN" && invite)) && session) setReady("ok");
    });
    supabase.auth.getSession().then(({ data: s }) => {
      if (s.session && (invite || recovery)) setReady("ok");
      else if (!hash.includes("access_token") && !window.location.search.includes("code=")) setReady("invalid");
    });
    const t = setTimeout(() => setReady((r) => (r === "checking" ? "invalid" : r)), 6000);
    return () => {
      data.subscription.unsubscribe();
      clearTimeout(t);
    };
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) { toast.error("Use at least 8 characters"); return; }
    if (password !== confirm) { toast.error("Passwords don't match"); return; }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    sessionStorage.removeItem("password-recovery");
    toast.success("Password saved");
    navigate({ to: "/dashboard", replace: true });
  }

  return (
    <AuthFrame
      title={isInvite ? "Welcome aboard" : "New password"}
      subtitle={isInvite ? "Choose a password to finish setting up your volunteer account." : "Choose a new password for your account."}
    >
      {ready === "checking" && <p className="font-mono text-sm text-muted-foreground">Verifying link<span className="animate-blink">_</span></p>}
      {ready === "invalid" && (
        <div className="space-y-3 text-sm">
          <p className="text-muted-foreground">This link is invalid or has expired. Request a new one.</p>
          <Button asChild className="w-full"><Link to="/forgot-password">Request a new link</Link></Button>
        </div>
      )}
      {ready === "ok" && (
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="pw">New password</Label>
            <Input id="pw" type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pw2">Confirm password</Label>
            <Input id="pw2" type="password" required autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>{loading ? "Saving…" : "Save password"}</Button>
        </form>
      )}
    </AuthFrame>
  );
}
