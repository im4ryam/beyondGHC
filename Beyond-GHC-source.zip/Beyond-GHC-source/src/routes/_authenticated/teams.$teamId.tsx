import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { BookOpen, CalendarClock, Crown, FolderKanban, Linkedin, Mail, Megaphone, Pencil, Phone, Plus, Target, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import {
  announcementsQuery,
  canManageTeam,
  membersQuery,
  projectsQuery,
  resourcesQuery,
  tasksQuery,
  useLookup,
  useMe,
} from "@/lib/queries";
import { dueState, errMsg, fmtDate, projectProgress } from "@/lib/format";
import { EmptyState, ExternalResourceLink, NoAccess, PageHeader, ProgressBar, ProjectStatusBadge, StatCard, UserAvatar, Window } from "@/components/app/bits";
import { TaskRow } from "@/components/app/task-row";
import { TaskFormDialog } from "@/components/app/task-form";
import { ProjectFormDialog } from "@/components/app/project-form";
import { ActivityList } from "@/components/app/activity-list";

export const Route = createFileRoute("/_authenticated/teams/$teamId")({
  head: () => ({ meta: [{ title: "Team — Beyond GHC" }, { name: "description", content: "Team page: members, objectives, projects and resources." }, { property: "og:title", content: "Team — Beyond GHC" }, { property: "og:description", content: "Team page: members, objectives, projects and resources." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: TeamPage,
});

function TeamPage() {
  const { teamId } = Route.useParams();
  const me = useMe();
  const qc = useQueryClient();
  const { teamById, profileById } = useLookup();
  const team = teamById.get(teamId);
  const members = (useQuery(membersQuery).data ?? []).filter((m) => m.team_id === teamId);
  const tasks = (useQuery(tasksQuery).data ?? []).filter((t) => t.team_id === teamId);
  const projects = (useQuery(projectsQuery).data ?? []).filter((p) => p.team_id === teamId);
  const resources = (useQuery(resourcesQuery).data ?? []).filter((r) => r.team_id === teamId);
  const announcements = (useQuery(announcementsQuery).data ?? []).filter((a) => a.team_id === teamId);
  const manager = canManageTeam(me, teamId);
  const contacts = useQuery({
    queryKey: ["contacts", teamId],
    queryFn: async () => {
      const { data } = await supabase.from("profile_private").select("user_id, email, phone").in("user_id", members.map((m) => m.user_id));
      return data ?? [];
    },
    enabled: members.length > 0,
  }).data ?? [];
  const [editObj, setEditObj] = useState(false);
  const [objectives, setObjectives] = useState("");
  const [taskOpen, setTaskOpen] = useState(false);
  const [projectOpen, setProjectOpen] = useState(false);
  const [assignFor, setAssignFor] = useState<string | undefined>();

  if (!team) return <NoAccess message="This team doesn't exist or you're not a member of it." />;
  if (!me.isAdmin && !me.teamIds.includes(teamId)) return <NoAccess message="You can only open teams you belong to." />;

  const done = tasks.filter((t) => t.status === "completed").length;
  const overdue = tasks.filter((t) => dueState(t.due_date, t.status) === "overdue").length;
  const upcoming = tasks.filter((t) => t.status !== "completed" && t.due_date).sort((a, b) => (a.due_date ?? "").localeCompare(b.due_date ?? "")).slice(0, 5);
  const sortedMembers = [...members].sort((a, b) => Number(b.is_lead) - Number(a.is_lead));

  async function saveObjectives() {
    const { error } = await supabase.from("teams").update({ objectives: objectives.trim() || null }).eq("id", teamId);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Objectives saved");
    setEditObj(false);
    qc.invalidateQueries({ queryKey: ["teams"] });
  }

  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Teams", to: "/teams" }, { label: team.name }]}
        eyebrow={team.archived ? "Archived team" : "Team"}
        title={team.name}
        description={team.description}
        actions={
          !team.archived && (
            <>
              {manager && <Button variant="outline" onClick={() => setProjectOpen(true)}><FolderKanban /> New project</Button>}
              <Button onClick={() => { setAssignFor(undefined); setTaskOpen(true); }}><Plus /> {manager ? "Assign task" : "New task"}</Button>
            </>
          )
        }
      />

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Members" value={members.length} icon={<Users />} tone="dusty" />
        <StatCard label="Active projects" value={projects.filter((p) => p.status === "active").length} icon={<FolderKanban />} tone="lavender" />
        <StatCard label="Task completion" value={`${tasks.length ? Math.round((done / tasks.length) * 100) : 0}%`} hint={`${done} of ${tasks.length} tasks`} icon={<Target />} tone="sage" />
        <StatCard label="Overdue" value={overdue} icon={<CalendarClock />} tone={overdue ? "danger" : "slate"} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Window title="Team objectives" icon={<Target />} actions={manager && !editObj && <Button size="sm" variant="ghost" onClick={() => { setObjectives(team.objectives ?? ""); setEditObj(true); }}><Pencil /> Edit</Button>}>
            {editObj ? (
              <div className="space-y-2">
                <Textarea rows={5} value={objectives} onChange={(e) => setObjectives(e.target.value)} placeholder="One objective per line" />
                <div className="flex justify-end gap-2"><Button variant="ghost" onClick={() => setEditObj(false)}>Cancel</Button><Button onClick={saveObjectives}>Save</Button></div>
              </div>
            ) : team.objectives ? (
              <ul className="space-y-1.5 text-sm">{team.objectives.split("\n").filter(Boolean).map((o, i) => <li key={i} className="flex gap-2"><span className="font-mono text-highlight">▸</span>{o}</li>)}</ul>
            ) : (
              <p className="text-sm text-muted-foreground">No objectives set yet.{manager && " Add a few so everyone knows what the team is working toward."}</p>
            )}
          </Window>

          <Window title="Projects" icon={<FolderKanban />} actions={<Link to="/checklists" className="text-xs text-primary hover:underline">Team checklist</Link>}>
            {projects.filter((p) => p.status !== "archived").length === 0 ? (
              <EmptyState compact icon={<FolderKanban />} title="No projects yet" />
            ) : (
              <ul className="divide-y">
                {projects.filter((p) => p.status !== "archived").map((p) => (
                  <li key={p.id} className="py-3 first:pt-0 last:pb-0">
                    <Link to="/projects/$projectId" params={{ projectId: p.id }} className="group block">
                      <div className="flex items-center justify-between gap-2"><span className="font-medium group-hover:underline">{p.title}</span><ProjectStatusBadge status={p.status} /></div>
                      <ProgressBar className="mt-2" value={projectProgress(tasks.filter((t) => t.project_id === p.id))} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Window>

          <Window title="Member tasks" icon={<Users />}>
            {members.length === 0 ? (
              <p className="text-sm text-muted-foreground">No members yet.</p>
            ) : (
              <div className="space-y-5">
                {sortedMembers.map((m) => {
                  const p = profileById.get(m.user_id);
                  const mt = tasks.filter((t) => t.assignee_id === m.user_id && t.status !== "completed");
                  return (
                    <div key={m.id}>
                      <div className="mb-2 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-sm font-medium"><UserAvatar name={p?.full_name} url={p?.avatar_url} size="sm" />{p?.full_name ?? "—"} <span className="font-mono text-xs text-muted-foreground">{mt.length} open</span></div>
                        {manager && <Button size="sm" variant="ghost" onClick={() => { setAssignFor(m.user_id); setTaskOpen(true); }}><Plus /> Assign</Button>}
                      </div>
                      {mt.length > 0 ? <div className="space-y-1.5">{mt.slice(0, 5).map((t) => <TaskRow key={t.id} task={t} showTeam={false} showAssignee={false} />)}</div> : <p className="pl-8 text-xs text-muted-foreground">No open tasks.</p>}
                    </div>
                  );
                })}
              </div>
            )}
          </Window>

          <Window title="Recent team activity">
            <ActivityList teamId={teamId} limit={15} />
          </Window>
        </div>

        <div className="space-y-6">
          <Window title="Members" icon={<Users />}>
            <ul className="space-y-3">
              {sortedMembers.map((m) => {
                const p = profileById.get(m.user_id);
                const c = contacts.find((x) => x.user_id === m.user_id);
                return (
                  <li key={m.id} className="flex gap-3">
                    <UserAvatar name={p?.full_name} url={p?.avatar_url} />
                    <div className="min-w-0 text-sm">
                      <div className="flex items-center gap-1.5 font-medium">{p?.full_name ?? "—"}{m.is_lead && <Badge variant="amber"><Crown className="size-3" /> Lead</Badge>}</div>
                      {p?.timezone && <div className="font-mono text-[11px] text-muted-foreground">{p.timezone}</div>}
                      <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5 text-xs">
                        {c?.email && <a href={`mailto:${c.email}`} className="inline-flex items-center gap-1 text-primary hover:underline"><Mail className="size-3" />{c.email}</a>}
                        {c?.phone && <span className="inline-flex items-center gap-1 text-muted-foreground"><Phone className="size-3" />{c.phone}</span>}
                        {p?.linkedin_url && <a href={p.linkedin_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline"><Linkedin className="size-3" />LinkedIn</a>}
                      </div>
                    </div>
                  </li>
                );
              })}
              {members.length === 0 && <p className="text-sm text-muted-foreground">No members yet.{me.isAdmin && " Add people from Manage Teams."}</p>}
            </ul>
            <p className="mt-3 border-t pt-2 text-[11px] text-muted-foreground">Contact details are shown only to team leads, administrators, and (for leads) to their team.</p>
          </Window>

          <Window title="Upcoming deadlines" icon={<CalendarClock />}>
            {upcoming.length ? (
              <ul className="space-y-2 text-sm">{upcoming.map((t) => (
                <li key={t.id}><Link to="/tasks/$taskId" params={{ taskId: t.id }} className="flex justify-between gap-2 hover:underline"><span className="truncate">{t.title}</span><span className={`shrink-0 font-mono text-xs ${dueState(t.due_date, t.status) === "overdue" ? "text-destructive" : "text-muted-foreground"}`}>{fmtDate(t.due_date, me.profile.timezone, { year: undefined })}</span></Link></li>
              ))}</ul>
            ) : <p className="text-sm text-muted-foreground">Nothing scheduled.</p>}
          </Window>

          <Window title="Resources" icon={<BookOpen />} actions={<Link to="/resources" className="text-xs text-primary hover:underline">All</Link>}>
            {resources.length ? <ul className="space-y-2">{resources.slice(0, 6).map((r) => <li key={r.id}><ExternalResourceLink url={r.url} title={r.title} requiresAccess={r.requires_access} /></li>)}</ul> : <p className="text-sm text-muted-foreground">No team resources yet.</p>}
          </Window>

          <Window title="Announcements" icon={<Megaphone />} actions={<Link to="/announcements" className="text-xs text-primary hover:underline">All</Link>}>
            {announcements.length ? (
              <ul className="space-y-3">{announcements.slice(0, 4).map((a) => <li key={a.id} className="text-sm"><div className="font-medium">{a.title}</div><div className="line-clamp-2 text-xs text-muted-foreground">{a.body}</div></li>)}</ul>
            ) : <p className="text-sm text-muted-foreground">No team announcements.</p>}
          </Window>
        </div>
      </div>

      <TaskFormDialog open={taskOpen} onOpenChange={setTaskOpen} defaultTeamId={teamId} defaultAssigneeId={assignFor} />
      <ProjectFormDialog open={projectOpen} onOpenChange={setProjectOpen} defaultTeamId={teamId} />
    </div>
  );
}
