import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Crown, MailPlus, Pencil, Search, ShieldCheck, UserCheck, UserX, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { membersQuery, profilesQuery, useLookup, useMe, type Profile } from "@/lib/queries";
import { errMsg, fmtDate, TIMEZONES } from "@/lib/format";
import { ConfirmAction, EmptyState, LoadingBlock, PageHeader, TeamBadge, UserAvatar } from "@/components/app/bits";
import { AssignmentRequests } from "@/components/app/assignment-requests";
import { SignupLinkDialog } from "@/components/app/signup-link-dialog";
import { InviteDialog } from "@/components/app/invite-dialog";

export const Route = createFileRoute("/_authenticated/admin/members")({
  head: () => ({ meta: [{ title: "Members — Admin — Beyond GHC" }, { name: "description", content: "Manage volunteer accounts." }, { property: "og:title", content: "Members — Admin — Beyond GHC" }, { property: "og:description", content: "Manage volunteer accounts." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: MembersPage,
});

const PAGE = 25;

function MembersPage() {
  const me = useMe();
  const qc = useQueryClient();
  const pq = useQuery(profilesQuery);
  const members = useQuery(membersQuery).data ?? [];
  const { teams, teamById } = useLookup();
  const priv = useQuery({ queryKey: ["admin_private"], queryFn: async () => (await supabase.from("profile_private").select("user_id, email, phone")).data ?? [] }).data ?? [];
  const roles = useQuery({ queryKey: ["admin_roles"], queryFn: async () => (await supabase.from("user_roles").select("user_id, role")).data ?? [] }).data ?? [];
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [team, setTeam] = useState("all");
  const [page, setPage] = useState(0);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [editing, setEditing] = useState<Profile | null>(null);

  const emailOf = (id: string) => priv.find((p) => p.user_id === id)?.email ?? "";
  const roleOf = (id: string) => (roles.some((r) => r.user_id === id && r.role === "owner") ? "owner" : roles.some((r) => r.user_id === id && r.role === "admin") ? "admin" : null);

  const list = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (pq.data ?? []).filter(
      (p) =>
        (status === "all" || p.status === status) &&
        (team === "all" || (team === "none" ? !members.some((m) => m.user_id === p.id) : members.some((m) => m.user_id === p.id && m.team_id === team))) &&
        (!term || p.full_name.toLowerCase().includes(term) || emailOf(p.id).includes(term)),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pq.data, search, status, team, members, priv]);
  useEffect(() => setPage(0), [search, status, team]);

  async function setAccount(p: Profile, s: "active" | "deactivated") {
    const { error } = await supabase.rpc("set_account_status", { _target: p.id, _status: s });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(s === "active" ? `${p.full_name} approved` : `${p.full_name} deactivated`);
    qc.invalidateQueries({ queryKey: ["profiles"] });
  }

  const pending = (pq.data ?? []).filter((p) => p.status === "pending");

  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Admin", to: "/admin" }, { label: "Members" }]}
        title="Members & volunteers"
        description="Invite volunteers, approve pending accounts, assign teams and deactivate access. Deactivated people can't see any portal data."
        actions={<div className="flex flex-wrap gap-2"><SignupLinkDialog /><Button onClick={() => setInviteOpen(true)}><MailPlus /> Invite volunteer</Button></div>}
      />

      <AssignmentRequests />

      {pending.length > 0 && (
        <div className="mb-5 rounded-md border border-amber/40 bg-amber-soft p-4">
          <div className="mb-2 text-sm font-semibold text-amber">{pending.length} account{pending.length === 1 ? "" : "s"} waiting for approval</div>
          <p className="mb-3 text-xs text-muted-foreground">These people signed up on their own. Approve only people you recognize.</p>
          <ul className="space-y-2">
            {pending.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded bg-card px-3 py-2 text-sm">
                <span>{p.full_name} <span className="text-muted-foreground">· {emailOf(p.id)}</span></span>
                <span className="flex gap-2">
                  <Button size="sm" variant="success" onClick={() => setAccount(p, "active")}><UserCheck /> Approve</Button>
                  <ConfirmAction trigger={<Button size="sm" variant="ghost"><UserX /> Reject</Button>} title={`Reject ${p.full_name}?`} description="Their account is deactivated and cannot access anything." confirmLabel="Reject" destructive onConfirm={() => setAccount(p, "deactivated")} />
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="panel mb-4 grid gap-2 p-3 sm:grid-cols-[1fr_180px_220px]">
        <div className="relative"><Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input className="pl-8" placeholder="Search name or email" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search members" /></div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger aria-label="Status"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">Any status</SelectItem><SelectItem value="active">Active</SelectItem><SelectItem value="pending">Pending</SelectItem><SelectItem value="deactivated">Deactivated</SelectItem></SelectContent>
        </Select>
        <Select value={team} onValueChange={setTeam}>
          <SelectTrigger aria-label="Team"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All teams</SelectItem><SelectItem value="none">No team</SelectItem>{teams.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      {pq.isLoading ? (
        <LoadingBlock rows={6} />
      ) : list.length === 0 ? (
        <EmptyState icon={<Users />} title="No members match" description="Invite volunteers from approved interest-form submissions or with the button above." />
      ) : (
        <div className="panel overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Name</TableHead><TableHead>Teams</TableHead><TableHead>Role</TableHead><TableHead>Status</TableHead><TableHead className="hidden md:table-cell">Hours/mo</TableHead><TableHead className="hidden md:table-cell">Joined</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {list.slice(page * PAGE, (page + 1) * PAGE).map((p) => {
                const ms = members.filter((m) => m.user_id === p.id);
                const role = roleOf(p.id);
                return (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="flex items-center gap-2"><UserAvatar name={p.full_name} url={p.avatar_url} size="sm" /><div className="min-w-0"><div className="font-medium">{p.full_name}</div><div className="text-xs text-muted-foreground">{emailOf(p.id)}</div></div></div>
                    </TableCell>
                    <TableCell><div className="flex max-w-xs flex-wrap gap-1">{ms.length ? ms.map((m) => <span key={m.id} className="inline-flex items-center gap-0.5"><TeamBadge team={teamById.get(m.team_id)} />{m.is_lead && <Crown className="size-3 text-highlight" aria-label="lead" />}</span>) : <span className="text-xs text-muted-foreground">—</span>}</div></TableCell>
                    <TableCell>{role === "owner" ? <Badge variant="amber"><Crown className="size-3" /> Owner</Badge> : role === "admin" ? <Badge variant="plum"><ShieldCheck className="size-3" /> Co-admin</Badge> : ms.some((m) => m.is_lead) ? <Badge variant="dusty">Team lead</Badge> : <Badge variant="slate">Volunteer</Badge>}</TableCell>
                    <TableCell><Badge variant={p.status === "active" ? "sage" : p.status === "pending" ? "amber" : "destructive"}>{p.status}</Badge></TableCell>
                    <TableCell className="hidden font-mono text-xs md:table-cell">{p.monthly_hours ?? "—"}</TableCell>
                    <TableCell className="hidden text-xs md:table-cell">{fmtDate(p.joined_at)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button size="sm" variant="ghost" onClick={() => setEditing(p)}><Pencil /> Edit</Button>
                        {role !== "owner" && (role !== "admin" || me.isOwner) && p.id !== me.id && (
                          p.status === "active" ? (
                            <ConfirmAction trigger={<Button size="sm" variant="ghost">Deactivate</Button>} title={`Deactivate ${p.full_name}?`} description="They'll immediately lose access to all portal data. Their tasks and history are kept, and you can reactivate them later." confirmLabel="Deactivate" destructive onConfirm={() => setAccount(p, "deactivated")} />
                          ) : (
                            <Button size="sm" variant="ghost" onClick={() => setAccount(p, "active")}>{p.status === "pending" ? "Approve" : "Reactivate"}</Button>
                          )
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <div className="flex items-center justify-between border-t px-3 py-2 text-xs text-muted-foreground">
            <span>{list.length} people · page {page + 1} of {Math.max(1, Math.ceil(list.length / PAGE))}</span>
            <span className="flex gap-1"><Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Button><Button size="sm" variant="outline" disabled={(page + 1) * PAGE >= list.length} onClick={() => setPage(page + 1)}>Next</Button></span>
          </div>
        </div>
      )}
      <InviteDialog open={inviteOpen} onOpenChange={setInviteOpen} />
      <EditMember profile={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function EditMember({ profile, onClose }: { profile: Profile | null; onClose: () => void }) {
  const qc = useQueryClient();
  const members = useQuery(membersQuery).data ?? [];
  const { teams } = useLookup();
  const [f, setF] = useState({ full_name: "", timezone: "", availability: "", monthly_hours: "" });
  const [sel, setSel] = useState<Record<string, "none" | "member" | "lead">>({});
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!profile) return;
    setF({ full_name: profile.full_name, timezone: profile.timezone, availability: profile.availability ?? "", monthly_hours: profile.monthly_hours?.toString() ?? "" });
    const s: Record<string, "none" | "member" | "lead"> = {};
    teams.forEach((t) => {
      const m = members.find((x) => x.team_id === t.id && x.user_id === profile.id);
      s[t.id] = m ? (m.is_lead ? "lead" : "member") : "none";
    });
    setSel(s);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  async function save() {
    if (!profile) return;
    setBusy(true);
    const { error } = await supabase.from("profiles").update({ full_name: f.full_name.trim(), timezone: f.timezone, availability: f.availability || null, monthly_hours: f.monthly_hours ? Number(f.monthly_hours) : null }).eq("id", profile.id);
    if (error) { setBusy(false); { toast.error(errMsg(error)); return; } }
    for (const t of teams) {
      const cur = members.find((x) => x.team_id === t.id && x.user_id === profile.id);
      const want = sel[t.id] ?? "none";
      const curState = cur ? (cur.is_lead ? "lead" : "member") : "none";
      if (want === curState) continue;
      const { error: e2 } = await supabase.rpc("set_team_membership", { _team: t.id, _user: profile.id, _member: want !== "none", _lead: want === "lead" });
      if (e2) { setBusy(false); { toast.error(errMsg(e2)); return; } }
    }
    setBusy(false);
    toast.success("Member updated");
    qc.invalidateQueries({ queryKey: ["profiles"] });
    qc.invalidateQueries({ queryKey: ["team_members"] });
    onClose();
  }

  return (
    <Dialog open={!!profile} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader><DialogTitle>Edit {profile?.full_name}</DialogTitle><DialogDescription>Team assignments and admin-managed details.</DialogDescription></DialogHeader>
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5"><Label htmlFor="em-n">Full name</Label><Input id="em-n" value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Time zone</Label><Select value={f.timezone} onValueChange={(v) => setF({ ...f, timezone: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TIMEZONES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-1.5"><Label htmlFor="em-a">Availability</Label><Input id="em-a" value={f.availability} onChange={(e) => setF({ ...f, availability: e.target.value })} /></div>
            <div className="space-y-1.5"><Label htmlFor="em-h">Hours per month</Label><Input id="em-h" type="number" value={f.monthly_hours} onChange={(e) => setF({ ...f, monthly_hours: e.target.value })} /></div>
          </div>
          <div className="space-y-2">
            <Label>Teams</Label>
            <div className="divide-y rounded-md border">
              {teams.filter((t) => !t.archived).map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                  <label className="flex items-center gap-2"><Checkbox checked={sel[t.id] !== "none"} onCheckedChange={(v) => setSel({ ...sel, [t.id]: v ? "member" : "none" })} />{t.name}</label>
                  <label className="flex items-center gap-1.5 text-xs text-muted-foreground"><Checkbox checked={sel[t.id] === "lead"} onCheckedChange={(v) => setSel({ ...sel, [t.id]: v ? "lead" : sel[t.id] === "none" ? "none" : "member" })} />Team lead</label>
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter><Button variant="ghost" onClick={onClose}>Cancel</Button><Button onClick={save} disabled={busy}>{busy ? "Saving…" : "Save"}</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
