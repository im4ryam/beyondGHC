import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Archive, CheckCircle2, ListChecks, Pencil, Plus, RotateCcw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { canManageTeam, membersQuery, projectsQuery, tasksQuery, useLookup, useMe, type Project } from "@/lib/queries";
import { endOfDayInZone, errMsg, fmtDate, fmtDateTime, projectProgress } from "@/lib/format";
import { ConfirmAction, EmptyState, LoadingBlock, PageHeader, PriorityBadge, ProgressBar, ProjectStatusBadge, TeamBadge, Window } from "@/components/app/bits";
import { TaskRow } from "@/components/app/task-row";
import { ProjectFormDialog } from "@/components/app/project-form";
import { TaskFormDialog } from "@/components/app/task-form";
import { ActivityList } from "@/components/app/activity-list";

export const Route = createFileRoute("/_authenticated/projects/$projectId")({
  head: () => ({ meta: [{ title: "Project — Beyond GHC" }, { name: "description", content: "Project checklist and progress." }, { property: "og:title", content: "Project — Beyond GHC" }, { property: "og:description", content: "Project checklist and progress." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ProjectPage,
});

function ProjectPage() {
  const { projectId } = Route.useParams();
  const q = useQuery(projectsQuery);
  const project = q.data?.find((p) => p.id === projectId);
  if (q.isLoading) return <LoadingBlock rows={4} />;
  if (!project) return <EmptyState title="Project not found" description="It may have been deleted, or it belongs to a team you're not on." action={<Button asChild variant="outline"><Link to="/projects">All projects</Link></Button>} />;
  return <ProjectDetail project={project} />;
}

const NONE = "__none";

function ProjectDetail({ project }: { project: Project }) {
  const me = useMe();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const tasks = useQuery(tasksQuery).data ?? [];
  const members = useQuery(membersQuery).data ?? [];
  const { teamById, profiles, profileById } = useLookup();
  const manager = canManageTeam(me, project.team_id);
  const items = tasks.filter((t) => t.project_id === project.id);
  const progress = projectProgress(items);
  const open = items.filter((t) => t.status !== "completed").length;
  const [editOpen, setEditOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [assignee, setAssignee] = useState(NONE);
  const [due, setDue] = useState("");
  const teamMembers = profiles.filter((p) => p.status === "active" && members.some((m) => m.team_id === project.team_id && m.user_id === p.id));

  async function setStatus(status: Project["status"], msg: string) {
    const patch: Partial<Project> = { status };
    if (status === "completed") Object.assign(patch, { completed_at: new Date().toISOString(), completed_by: me.id });
    if (status === "active") Object.assign(patch, { completed_at: null, completed_by: null });
    const { error } = await supabase.from("projects").update(patch).eq("id", project.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(msg);
    qc.invalidateQueries({ queryKey: ["projects"] });
    qc.invalidateQueries({ queryKey: ["activity"] });
  }

  async function addItem(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    const { error } = await supabase.from("tasks").insert({
      team_id: project.team_id,
      project_id: project.id,
      title: title.trim(),
      assignee_id: assignee === NONE ? null : assignee,
      due_date: due ? endOfDayInZone(due, me.profile.timezone) : null,
      created_by: me.id,
    });
    if (error) { toast.error(errMsg(error)); return; }
    setTitle("");
    setDue("");
    setAssignee(NONE);
    toast.success("Checklist item added");
    qc.invalidateQueries({ queryKey: ["tasks"] });
  }

  async function remove() {
    const { error } = await supabase.from("projects").delete().eq("id", project.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Project deleted");
    qc.invalidateQueries({ queryKey: ["projects"] });
    qc.invalidateQueries({ queryKey: ["tasks"] });
    navigate({ to: "/projects" });
  }

  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Team Projects", to: "/projects" }, { label: project.title }]}
        title={project.title}
        description={project.description}
        actions={
          manager && (
            <>
              <Button variant="outline" onClick={() => setEditOpen(true)}><Pencil /> Edit</Button>
              {project.status !== "completed" && project.status !== "archived" && (
                <ConfirmAction
                  trigger={<Button variant="success"><CheckCircle2 /> Confirm complete</Button>}
                  title="Mark the whole project as completed?"
                  description={open > 0 ? `${open} checklist item${open === 1 ? " is" : "s are"} still open. You can still complete the project; open items stay visible.` : "All checklist items are done. The project moves to the Completed section."}
                  confirmLabel="Mark completed"
                  onConfirm={() => setStatus("completed", "Project completed")}
                />
              )}
              {(project.status === "completed" || project.status === "archived") && (
                <Button variant="outline" onClick={() => setStatus("active", "Project reopened")}><RotateCcw /> Reopen</Button>
              )}
              {project.status !== "archived" && (
                <ConfirmAction trigger={<Button variant="ghost"><Archive /> Archive</Button>} title="Archive this project?" description="Archived projects stay visible in the Completed & archived section and can be reopened." confirmLabel="Archive" onConfirm={() => setStatus("archived", "Project archived")} />
              )}
              {me.isAdmin && (
                <ConfirmAction trigger={<Button variant="ghost" aria-label="Delete project"><Trash2 /></Button>} title="Delete this project permanently?" description="Its checklist items will be kept as individual tasks. Archiving is usually better." confirmLabel="Delete" destructive onConfirm={remove} />
              )}
            </>
          )
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Window title={`Checklist · ${items.length - open}/${items.length} done`} icon={<ListChecks />} actions={project.status !== "archived" && <Button size="sm" variant="ghost" onClick={() => setTaskOpen(true)}><Plus /> {manager ? "Detailed item" : "New task"}</Button>}>
            <ProgressBar value={progress} className="mb-4" label="Project progress" />
            {items.length === 0 ? (
              <EmptyState compact icon={<ListChecks />} title="No checklist items yet" description={manager ? "Add the steps needed to finish this project and assign each to a volunteer." : "Your team lead hasn't added checklist items yet."} />
            ) : (
              <div className="space-y-2">
                {[...items].sort((a, b) => Number(a.status === "completed") - Number(b.status === "completed") || (a.due_date ?? "9") .localeCompare(b.due_date ?? "9")).map((t) => <TaskRow key={t.id} task={t} showTeam={false} showProject={false} />)}
              </div>
            )}
            {manager && project.status !== "archived" && (
              <form onSubmit={addItem} className="mt-4 grid gap-2 border-t pt-4 sm:grid-cols-[1fr_180px_150px_auto]">
                <Input placeholder="Add a checklist item…" value={title} onChange={(e) => setTitle(e.target.value)} aria-label="New checklist item" />
                <Select value={assignee} onValueChange={setAssignee}>
                  <SelectTrigger aria-label="Assign to"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>Unassigned</SelectItem>
                    {teamMembers.map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Input type="date" value={due} onChange={(e) => setDue(e.target.value)} aria-label="Due date" />
                <Button type="submit" disabled={!title.trim()}><Plus /> Add</Button>
              </form>
            )}
          </Window>
          <Window title="Project history">
            <ActivityList entityType="project" entityId={project.id} />
          </Window>
        </div>
        <div className="space-y-6">
          <Window title="Overview">
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Team</dt><dd><Link to="/teams/$teamId" params={{ teamId: project.team_id }}><TeamBadge team={teamById.get(project.team_id)} /></Link></dd></div>
              <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Status</dt><dd><ProjectStatusBadge status={project.status} /></dd></div>
              <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Priority</dt><dd><PriorityBadge priority={project.priority} /></dd></div>
              <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Target date</dt><dd>{project.due_date ? fmtDate(project.due_date + "T12:00:00") : "—"}</dd></div>
              <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Created</dt><dd>{fmtDate(project.created_at)}</dd></div>
              {project.completed_at && (
                <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Completed</dt><dd className="text-right">{fmtDateTime(project.completed_at)}<span className="block text-xs text-muted-foreground">by {profileById.get(project.completed_by ?? "")?.full_name ?? "—"}</span></dd></div>
              )}
            </dl>
          </Window>
          <Window title="Who's responsible">
            {(() => {
              const by = new Map<string, number>();
              items.filter((t) => t.status !== "completed").forEach((t) => by.set(t.assignee_id ?? "none", (by.get(t.assignee_id ?? "none") ?? 0) + 1));
              if (!by.size) return <p className="text-sm text-muted-foreground">No open items.</p>;
              return (
                <ul className="space-y-1.5 text-sm">
                  {[...by.entries()].map(([id, n]) => (
                    <li key={id} className="flex justify-between"><span>{id === "none" ? "Unassigned" : profileById.get(id)?.full_name ?? "—"}</span><span className="font-mono text-muted-foreground">{n} open</span></li>
                  ))}
                </ul>
              );
            })()}
          </Window>
        </div>
      </div>
      <ProjectFormDialog open={editOpen} onOpenChange={setEditOpen} project={project} />
      <TaskFormDialog open={taskOpen} onOpenChange={setTaskOpen} defaultTeamId={project.team_id} defaultProjectId={project.id} />
    </div>
  );
}
