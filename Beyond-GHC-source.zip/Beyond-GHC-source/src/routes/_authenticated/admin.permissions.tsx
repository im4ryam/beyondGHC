import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Crown, KeyRound, ShieldCheck, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { profilesQuery, teamsQuery, useMe } from "@/lib/queries";
import { errMsg } from "@/lib/format";
import { ConfirmAction, PageHeader, UserAvatar, Window } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/admin/permissions")({
  head: () => ({ meta: [{ title: "Permissions — Admin — Beyond GHC" }, { name: "description", content: "Roles, data access and ownership." }, { property: "og:title", content: "Permissions — Admin — Beyond GHC" }, { property: "og:description", content: "Roles, data access and ownership." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: PermissionsPage,
});

const DATASETS = [
  { key: "member_contacts", label: "Member contact details", hint: "Full interest-form records incl. email (e.g. Community, Operations)" },
  { key: "speaker_pipeline", label: "Speaker pipeline", hint: "Speaker submissions, topics, contact & status (e.g. Programs & Speakers)" },
  { key: "volunteer_pipeline", label: "Volunteer pipeline", hint: "Volunteer applicants and their preferences" },
  { key: "public_member_info", label: "Approved public member info", hint: "Only admin-approved names, bios, topics — no contact info (e.g. Marketing)" },
] as const;

function PermissionsPage() {
  const me = useMe();
  const qc = useQueryClient();
  const profiles = useQuery(profilesQuery).data ?? [];
  const teams = (useQuery(teamsQuery).data ?? []).filter((t) => !t.archived);
  const roles = useQuery({ queryKey: ["admin_roles"], queryFn: async () => (await supabase.from("user_roles").select("user_id, role")).data ?? [] }).data ?? [];
  const access = useQuery({ queryKey: ["dataset_access"], queryFn: async () => (await supabase.from("team_dataset_access").select("*")).data ?? [] }).data ?? [];
  const [grantTo, setGrantTo] = useState("");
  const [transferOpen, setTransferOpen] = useState(false);

  const owner = profiles.find((p) => roles.some((r) => r.user_id === p.id && r.role === "owner"));
  const admins = profiles.filter((p) => roles.some((r) => r.user_id === p.id && r.role === "admin"));
  const candidates = profiles.filter((p) => p.status === "active" && !roles.some((r) => r.user_id === p.id));

  async function setAdmin(id: string, grant: boolean) {
    const { error } = await supabase.rpc("set_admin_role", { _target: id, _grant: grant });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(grant ? "Co-Administrator access granted" : "Co-Administrator access removed");
    setGrantTo("");
    qc.invalidateQueries({ queryKey: ["admin_roles"] });
  }

  async function toggleAccess(team: string, ds: string, on: boolean) {
    const existing = access.find((a) => a.team_id === team && a.dataset === ds);
    const { error } = on
      ? await supabase.from("team_dataset_access").insert({ team_id: team, dataset: ds as never, leads_only: true })
      : await supabase.from("team_dataset_access").delete().eq("id", existing!.id);
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["dataset_access"] });
  }
  async function setLeadsOnly(id: string, v: boolean) {
    const { error } = await supabase.from("team_dataset_access").update({ leads_only: v }).eq("id", id);
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["dataset_access"] });
  }

  return (
    <div className="space-y-6">
      <PageHeader crumbs={[{ label: "Admin", to: "/admin" }, { label: "Permissions" }]} title="Permissions" description="Who can administer the platform, and which teams can see which member information." />

      <div className="grid gap-6 lg:grid-cols-2">
        <Window title="Primary owner" icon={<Crown />}>
          {owner ? (
            <div className="flex items-center gap-3">
              <UserAvatar name={owner.full_name} url={owner.avatar_url} size="lg" />
              <div>
                <div className="font-semibold">{owner.full_name}</div>
                <div className="text-xs text-muted-foreground">Ultimate authority over the platform. This role can't be assigned through user management.</div>
              </div>
            </div>
          ) : <p className="text-sm text-muted-foreground">No owner set.</p>}
          {me.isOwner && (
            <div className="mt-4 border-t pt-4">
              <Button variant="outline" onClick={() => setTransferOpen(true)} disabled={!admins.length}><KeyRound /> Transfer ownership…</Button>
              {!admins.length && <p className="mt-1 text-xs text-muted-foreground">Ownership can only be transferred to an existing Co-Administrator.</p>}
            </div>
          )}
        </Window>

        <Window title="Co-administrators" icon={<ShieldCheck />}>
          <p className="mb-3 text-sm text-muted-foreground">Broad admin access for day-to-day operations. Only the Primary Owner can grant or revoke it.</p>
          <ul className="space-y-2">
            {admins.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-2 rounded-md border px-3 py-2">
                <span className="flex items-center gap-2 text-sm"><UserAvatar name={a.full_name} url={a.avatar_url} size="sm" />{a.full_name}</span>
                {me.isOwner && <ConfirmAction trigger={<Button size="sm" variant="ghost"><ShieldOff /> Revoke</Button>} title={`Remove ${a.full_name}'s admin access?`} description="They'll keep their volunteer account and team memberships." confirmLabel="Revoke" destructive onConfirm={() => setAdmin(a.id, false)} />}
              </li>
            ))}
            {admins.length === 0 && <li className="text-sm text-muted-foreground">No co-administrators yet.</li>}
          </ul>
          {me.isOwner && (
            <div className="mt-4 flex gap-2">
              <Select value={grantTo} onValueChange={setGrantTo}>
                <SelectTrigger aria-label="Choose member"><SelectValue placeholder={candidates.length ? "Choose an active member" : "Invite them as a volunteer first"} /></SelectTrigger>
                <SelectContent>{candidates.map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}</SelectContent>
              </Select>
              <ConfirmAction trigger={<Button disabled={!grantTo}>Grant</Button>} title="Grant Co-Administrator access?" description="They'll be able to manage volunteers, teams, projects, submissions and settings." confirmLabel="Grant access" onConfirm={() => setAdmin(grantTo, true)} />
            </div>
          )}
        </Window>
      </div>

      <Window title="Team access to member information">
        <p className="mb-4 text-sm text-muted-foreground">
          Volunteers never see the raw interest-form database. Grant a team access to a specific dataset only if it needs it. “Leads only” restricts it to that team's leads. Changes take effect immediately and are enforced on the server.
        </p>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Dataset</TableHead>{teams.map((t) => <TableHead key={t.id} className="min-w-40 text-center">{t.name}</TableHead>)}</TableRow></TableHeader>
            <TableBody>
              {DATASETS.map((d) => (
                <TableRow key={d.key}>
                  <TableCell><div className="font-medium">{d.label}</div><div className="text-xs text-muted-foreground">{d.hint}</div></TableCell>
                  {teams.map((t) => {
                    const a = access.find((x) => x.team_id === t.id && x.dataset === d.key);
                    return (
                      <TableCell key={t.id} className="text-center">
                        <div className="flex flex-col items-center gap-1.5">
                          <Switch checked={!!a} onCheckedChange={(v) => toggleAccess(t.id, d.key, v)} aria-label={`${d.label} for ${t.name}`} />
                          {a && <label className="flex items-center gap-1 text-[11px] text-muted-foreground"><input type="checkbox" checked={a.leads_only} onChange={(e) => setLeadsOnly(a.id, e.target.checked)} /> leads only</label>}
                        </div>
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Window>

      <TransferDialog open={transferOpen} onOpenChange={setTransferOpen} admins={admins.map((a) => ({ id: a.id, name: a.full_name }))} />
    </div>
  );
}

function TransferDialog({ open, onOpenChange, admins }: { open: boolean; onOpenChange: (o: boolean) => void; admins: { id: string; name: string }[] }) {
  const me = useMe();
  const qc = useQueryClient();
  const [target, setTarget] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  async function run() {
    setBusy(true);
    const { error: authErr } = await supabase.auth.signInWithPassword({ email: me.email, password });
    if (authErr) { setBusy(false); { toast.error("Password incorrect"); return; } }
    const { error } = await supabase.rpc("transfer_ownership", { _target: target });
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Ownership transferred. You are now a Co-Administrator.");
    onOpenChange(false);
    qc.invalidateQueries();
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Transfer Primary Ownership</DialogTitle>
          <DialogDescription>This is permanent unless the new owner transfers it back. You'll become a Co-Administrator.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5"><Label>New owner</Label><Select value={target} onValueChange={setTarget}><SelectTrigger><SelectValue placeholder="Choose a Co-Administrator" /></SelectTrigger><SelectContent>{admins.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}</SelectContent></Select></div>
          <div className="space-y-1.5"><Label htmlFor="tr-pw">Your password</Label><Input id="tr-pw" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <div className="space-y-1.5"><Label htmlFor="tr-c">Type TRANSFER to confirm</Label><Input id="tr-c" value={confirm} onChange={(e) => setConfirm(e.target.value)} /></div>
        </div>
        <DialogFooter><Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button><Button variant="destructive" disabled={busy || !target || !password || confirm !== "TRANSFER"} onClick={run}>{busy ? "Transferring…" : "Transfer ownership"}</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
