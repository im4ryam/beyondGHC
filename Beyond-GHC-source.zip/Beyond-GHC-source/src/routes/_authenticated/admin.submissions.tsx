import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Archive, Check, Download, ExternalLink, Inbox, MailPlus, Mic, Search, Upload, UserCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import type { Submission } from "@/lib/queries";
import { SPEAKER_STATUSES, SUBMISSION_STATUSES, errMsg, fmtDate, fmtDateTime, submissionStatusMeta, type SubmissionStatus } from "@/lib/format";
import { downloadCsv } from "@/lib/csv";
import { EmptyState, LoadingBlock, PageHeader } from "@/components/app/bits";
import { InviteDialog } from "@/components/app/invite-dialog";
import { ImportPanel } from "@/components/app/import-panel";

export const Route = createFileRoute("/_authenticated/admin/submissions")({
  head: () => ({ meta: [{ title: "Submissions — Admin — Beyond GHC" }, { name: "description", content: "Review interest form submissions." }, { property: "og:title", content: "Submissions — Admin — Beyond GHC" }, { property: "og:description", content: "Review interest form submissions." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: SubmissionsPage,
});

export const submissionsQueryKey = ["submissions", "all"] as const;
const PAGE = 30;

function SubmissionsPage() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: submissionsQueryKey,
    queryFn: async () => {
      const { data, error } = await supabase.from("interest_submissions").select("*").order("submitted_at", { ascending: false }).limit(5000);
      if (error) throw error;
      return data;
    },
  });
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("open");
  const [kind, setKind] = useState("all");
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Submission | null>(null);
  const [importOpen, setImportOpen] = useState(false);

  const list = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (q.data ?? []).filter(
      (s) =>
        (status === "all" || (status === "open" ? s.status === "new" || s.status === "reviewing" : s.status === status)) &&
        (kind === "all" || (kind === "volunteer" ? s.volunteer_interest : kind === "speaker" ? s.speaker_interest : !s.volunteer_interest && !s.speaker_interest)) &&
        (!term || [s.full_name, s.email, s.topics, s.proposed_topics, s.volunteer_areas, s.background].some((x) => x?.toLowerCase().includes(term))),
    );
  }, [q.data, search, status, kind]);
  useEffect(() => setPage(0), [search, status, kind]);
  useEffect(() => {
    if (selected) setSelected(q.data?.find((s) => s.id === selected.id) ?? null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q.data]);

  const all = q.data ?? [];
  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Admin", to: "/admin" }, { label: "Submissions" }]}
        title="Interest form submissions"
        description="Everyone who filled out the interest form. Submitting the form never creates a login — review people here and create accounts for the ones you approve."
        actions={
          <>
            <Button variant="outline" onClick={() => downloadCsv(`submissions-${new Date().toISOString().slice(0, 10)}.csv`, list.map(({ history: _h, ...r }) => r))}><Download /> Export view</Button>
            <Button onClick={() => setImportOpen(true)}><Upload /> Import spreadsheet</Button>
          </>
        }
      />
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Count label="People" value={all.length} />
        <Count label="To review" value={all.filter((s) => s.status === "new" || s.status === "reviewing").length} />
        <Count label="Potential volunteers" value={all.filter((s) => s.volunteer_interest).length} />
        <Count label="Potential speakers" value={all.filter((s) => s.speaker_interest).length} />
      </div>
      <div className="panel mb-4 grid gap-2 p-3 sm:grid-cols-[1fr_200px_200px]">
        <div className="relative"><Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input className="pl-8" placeholder="Search name, email, topics…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search submissions" /></div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger aria-label="Status"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="open">Needs review</SelectItem>
            <SelectItem value="all">Any status</SelectItem>
            {SUBMISSION_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={kind} onValueChange={setKind}>
          <SelectTrigger aria-label="Interest"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Everyone</SelectItem>
            <SelectItem value="volunteer">Potential volunteers</SelectItem>
            <SelectItem value="speaker">Potential speakers</SelectItem>
            <SelectItem value="member">Members only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {q.isLoading ? (
        <LoadingBlock rows={6} />
      ) : list.length === 0 ? (
        <EmptyState icon={<Inbox />} title="No submissions match" description="Try another filter, or import a spreadsheet of form responses." />
      ) : (
        <div className="panel overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Interest</TableHead><TableHead className="hidden lg:table-cell">Background</TableHead><TableHead className="hidden md:table-cell">Submitted</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
            <TableBody>
              {list.slice(page * PAGE, (page + 1) * PAGE).map((s) => {
                const m = submissionStatusMeta(s.status);
                return (
                  <TableRow key={s.id} className="cursor-pointer" onClick={() => setSelected(s)} tabIndex={0} onKeyDown={(e) => e.key === "Enter" && setSelected(s)}>
                    <TableCell><div className="font-medium">{s.full_name || "—"}</div><div className="text-xs text-muted-foreground">{s.email.endsWith("@invalid.local") ? <span className="text-destructive">Missing email</span> : s.email}</div></TableCell>
                    <TableCell><div className="flex flex-wrap gap-1">{s.volunteer_interest && <Badge variant="dusty">Volunteer</Badge>}{s.speaker_interest && <Badge variant="amber"><Mic className="size-3" /> Speaker</Badge>}{!s.volunteer_interest && !s.speaker_interest && <Badge variant="slate">Member</Badge>}{s.submission_count > 1 && <Badge variant="outline">{s.submission_count}×</Badge>}</div></TableCell>
                    <TableCell className="hidden max-w-56 truncate text-xs lg:table-cell">{s.background}</TableCell>
                    <TableCell className="hidden text-xs md:table-cell">{fmtDate(s.submitted_at)}</TableCell>
                    <TableCell><Badge variant={m.variant}>{m.label}</Badge></TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <div className="flex items-center justify-between border-t px-3 py-2 text-xs text-muted-foreground">
            <span>{list.length} submissions · page {page + 1} of {Math.max(1, Math.ceil(list.length / PAGE))}</span>
            <span className="flex gap-1"><Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Button><Button size="sm" variant="outline" disabled={(page + 1) * PAGE >= list.length} onClick={() => setPage(page + 1)}>Next</Button></span>
          </div>
        </div>
      )}
      <SubmissionSheet sub={selected} onClose={() => setSelected(null)} onChanged={() => qc.invalidateQueries({ queryKey: ["submissions"] })} />
      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="sm:max-w-lg"><DialogHeader><DialogTitle>Import form responses</DialogTitle></DialogHeader><ImportPanel /></DialogContent>
      </Dialog>
    </div>
  );
}

function Count({ label, value }: { label: string; value: number }) {
  return <div className="panel px-4 py-3"><div className="text-xs text-muted-foreground">{label}</div><div className="font-mono text-2xl font-semibold">{value}</div></div>;
}

const FIELDS: [keyof Submission, string][] = [
  ["background", "Which best describes you"],
  ["ghc_connection", "Connection to GHC"],
  ["timezone", "Time zone"],
  ["availability", "Availability"],
  ["participation", "How they'd like to participate"],
  ["topics", "Topics of interest"],
  ["formats", "Preferred session formats"],
  ["community_spaces", "Community spaces"],
  ["platform_pref", "Platform preference"],
  ["volunteer_areas", "Volunteer areas"],
  ["preferred_team", "Team preference"],
  ["volunteer_experience", "Skills / experience"],
  ["proposed_topics", "Proposed presentation topics"],
  ["comments", "Anything else"],
  ["phone", "Phone"],
];

function SubmissionSheet({ sub, onClose, onChanged }: { sub: Submission | null; onClose: () => void; onChanged: () => void }) {
  const [notes, setNotes] = useState("");
  const [bio, setBio] = useState("");
  const [email, setEmail] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  useEffect(() => {
    setNotes(sub?.admin_notes ?? "");
    setBio(sub?.public_bio ?? "");
    setEmail(sub?.email.endsWith("@invalid.local") ? "" : sub?.email ?? "");
  }, [sub?.id, sub?.admin_notes, sub?.public_bio, sub?.email]);

  async function patch(p: Partial<Submission>, msg: string) {
    if (!sub) return;
    const { error } = await supabase.from("interest_submissions").update(p).eq("id", sub.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(msg);
    onChanged();
  }

  const missingEmail = sub?.email.endsWith("@invalid.local");
  const history = Array.isArray(sub?.history) ? (sub!.history as { submitted_at?: string; source?: string }[]) : [];

  return (
    <Sheet open={!!sub} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
        {sub && (
          <>
            <SheetHeader>
              <SheetTitle className="text-xl">{sub.full_name || "Unnamed"}</SheetTitle>
              <SheetDescription asChild>
                <div className="space-y-1">
                  <div>{missingEmail ? <span className="text-destructive">No valid email on file</span> : sub.email}</div>
                  {sub.linkedin_url && <a href={sub.linkedin_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline"><ExternalLink className="size-3" /> LinkedIn</a>}
                </div>
              </SheetDescription>
            </SheetHeader>
            <div className="mt-4 space-y-5 px-4 pb-8">
              <div className="flex flex-wrap gap-1.5">
                <Badge variant={submissionStatusMeta(sub.status).variant}>{submissionStatusMeta(sub.status).label}</Badge>
                {sub.volunteer_interest && <Badge variant="dusty">Potential volunteer</Badge>}
                {sub.speaker_interest && <Badge variant="amber">Potential speaker</Badge>}
                <Badge variant="outline">Submitted {fmtDateTime(sub.submitted_at)}</Badge>
              </div>

              {missingEmail && (
                <div className="space-y-2 rounded-md border border-destructive/30 bg-danger-soft p-3">
                  <Label htmlFor="fix-email" className="text-destructive">Add their correct email</Label>
                  <div className="flex gap-2"><Input id="fix-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} /><Button onClick={() => patch({ email: email.trim().toLowerCase() }, "Email updated")} disabled={!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)}>Save</Button></div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                {sub.status !== "converted" && (
                  <Button variant="highlight" className="col-span-2" disabled={missingEmail} onClick={() => setInviteOpen(true)}><MailPlus /> Create volunteer account</Button>
                )}
                <Button variant="outline" onClick={() => patch({ status: "approved" }, "Approved for onboarding")} disabled={sub.status === "approved" || sub.status === "converted"}><Check /> Approve</Button>
                <Button variant="outline" onClick={() => patch({ status: "reviewing" }, "Marked as reviewing")} disabled={sub.status === "reviewing"}><UserCheck /> Reviewing</Button>
                <Button variant="ghost" onClick={() => patch({ status: "rejected" }, "Rejected")} disabled={sub.status === "rejected"}><X /> Reject</Button>
                <Button variant="ghost" onClick={() => patch({ status: "archived" }, "Archived")} disabled={sub.status === "archived"}><Archive /> Archive</Button>
              </div>
              <Select value={sub.status} onValueChange={(v) => patch({ status: v as SubmissionStatus }, "Status updated")}>
                <SelectTrigger aria-label="Status"><SelectValue /></SelectTrigger>
                <SelectContent>{SUBMISSION_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
              </Select>

              <dl className="divide-y rounded-md border">
                {FIELDS.filter(([k]) => sub[k]).map(([k, label]) => (
                  <div key={k} className="grid gap-1 px-3 py-2 sm:grid-cols-[150px_1fr]">
                    <dt className="text-xs text-muted-foreground">{label}</dt>
                    <dd className="whitespace-pre-wrap text-sm">{String(sub[k])}</dd>
                  </div>
                ))}
              </dl>

              {sub.speaker_interest && (
                <div className="space-y-2">
                  <Label>Speaker pipeline status</Label>
                  <Select value={sub.speaker_status} onValueChange={(v) => patch({ speaker_status: v }, "Speaker status updated")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{SPEAKER_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="notes">Internal notes</Label>
                <Textarea id="notes" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Interview notes, follow-ups…" />
                <Button size="sm" variant="outline" onClick={() => patch({ admin_notes: notes.trim() || null }, "Notes saved")}>Save notes</Button>
              </div>

              <div className="space-y-2 rounded-md border p-3">
                <div className="flex items-center justify-between gap-2">
                  <Label>Approved for public / marketing use</Label>
                  <Switch checked={sub.public_approved} onCheckedChange={(v) => patch({ public_approved: v }, v ? "Approved for public use" : "Public approval removed")} />
                </div>
                <p className="text-xs text-muted-foreground">Only name, LinkedIn, the bio below and (for speakers) topics are shared with teams granted “approved public member info”. Never email or phone.</p>
                <Textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Short public bio" />
                <Button size="sm" variant="outline" onClick={() => patch({ public_bio: bio.trim() || null }, "Bio saved")}>Save bio</Button>
              </div>

              <div>
                <div className="eyebrow mb-2 text-muted-foreground">Submission history ({history.length})</div>
                <ul className="space-y-1 font-mono text-xs text-muted-foreground">
                  {history.map((h, i) => <li key={i}>{h.submitted_at ? fmtDateTime(h.submitted_at) : "—"} · {h.source}</li>)}
                </ul>
              </div>
            </div>
            <InviteDialog open={inviteOpen} onOpenChange={setInviteOpen} initial={{ email: sub.email, full_name: sub.full_name, submission_id: sub.id, suggestedTeam: sub.preferred_team ?? sub.volunteer_areas }} />
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
