import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CheckSquare, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { tasksQuery, useLookup, useMe, membersQuery } from "@/lib/queries";
import { PRIORITIES, TASK_STATUSES, dueState, priorityMeta } from "@/lib/format";
import { EmptyState, LoadingBlock, PageHeader } from "@/components/app/bits";
import { TaskRow } from "@/components/app/task-row";
import { TaskFormDialog } from "@/components/app/task-form";

export const Route = createFileRoute("/_authenticated/tasks/")({
  head: () => ({ meta: [{ title: "My Tasks — Beyond GHC" }, { name: "description", content: "Your personal task checklist." }, { property: "og:title", content: "My Tasks — Beyond GHC" }, { property: "og:description", content: "Your personal task checklist." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: TasksPage,
});

const ALL = "all";
const STATUS_ORDER = { incomplete: 0, in_progress: 1, revised: 2, completed: 3 } as const;

function TasksPage() {
  const me = useMe();
  const q = useQuery(tasksQuery);
  const members = useQuery(membersQuery).data ?? [];
  const { teams, projects, profiles, teamById } = useLookup();
  const canSeeAll = me.isAdmin || me.isLead;
  const [scope, setScope] = useState<"mine" | "team">("mine");
  const [status, setStatus] = useState<string>("open");
  const [team, setTeam] = useState(ALL);
  const [project, setProject] = useState(ALL);
  const [priority, setPriority] = useState(ALL);
  const [due, setDue] = useState(ALL);
  const [assignee, setAssignee] = useState(ALL);
  const [sort, setSort] = useState("due");
  const [search, setSearch] = useState("");
  const [limit, setLimit] = useState(50);
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() => {
    let list = q.data ?? [];
    if (scope === "mine") list = list.filter((t) => t.assignee_id === me.id);
    if (status === "open") list = list.filter((t) => t.status !== "completed");
    else if (status === "review") list = list.filter((t) => t.awaiting_review && t.status !== "completed");
    else if (status !== ALL) list = list.filter((t) => t.status === status);
    if (team !== ALL) list = list.filter((t) => t.team_id === team);
    if (project !== ALL) list = list.filter((t) => (project === "none" ? !t.project_id : t.project_id === project));
    if (priority !== ALL) list = list.filter((t) => t.priority === priority);
    if (canSeeAll && assignee !== ALL) list = list.filter((t) => (assignee === "none" ? !t.assignee_id : t.assignee_id === assignee));
    if (due !== ALL) {
      list = list.filter((t) => {
        const s = dueState(t.due_date, t.status);
        if (due === "overdue") return s === "overdue";
        if (due === "soon") return s === "soon";
        if (due === "week") return !!t.due_date && t.status !== "completed" && new Date(t.due_date).getTime() - Date.now() < 7 * 86400000;
        if (due === "none") return !t.due_date;
        return true;
      });
    }
    const term = search.trim().toLowerCase();
    if (term) list = list.filter((t) => t.title.toLowerCase().includes(term) || t.description?.toLowerCase().includes(term));
    const sorted = [...list];
    sorted.sort((a, b) => {
      if (sort === "priority") return priorityMeta(b.priority).rank - priorityMeta(a.priority).rank;
      if (sort === "updated") return a.updated_at > b.updated_at ? -1 : 1;
      if (sort === "status") return STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
      if (!a.due_date) return 1;
      if (!b.due_date) return -1;
      return a.due_date < b.due_date ? -1 : 1;
    });
    return sorted;
  }, [q.data, scope, status, team, project, priority, assignee, due, sort, search, me.id, canSeeAll]);

  const visibleTeams = teams.filter((t) => me.isAdmin || me.teamIds.includes(t.id));
  const teamProjects = projects.filter((p) => team === ALL || p.team_id === team);
  const assignable = profiles.filter((p) => me.isAdmin || members.some((m) => m.user_id === p.id && me.teamIds.includes(m.team_id)));

  return (
    <div>
      <PageHeader
        eyebrow="Checklist"
        title={scope === "mine" ? "My tasks" : "Team tasks"}
        description="Overdue tasks have a red edge, tasks due within 3 days an orange edge. Open a task to update its status or add notes."
        actions={(me.isAdmin || me.teamIds.length > 0) && <Button onClick={() => setOpen(true)}><Plus /> New task</Button>}
      />

      <div className="panel mb-4 space-y-3 p-3">
        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          {(me.isAdmin || me.teamIds.length > 0) && (
            <Tabs value={scope} onValueChange={(v) => setScope(v as "mine" | "team")}>
              <TabsList>
                <TabsTrigger value="mine">Assigned to me</TabsTrigger>
                <TabsTrigger value="team">{me.isAdmin ? "All tasks" : "My teams' tasks"}</TabsTrigger>
              </TabsList>
            </Tabs>
          )}
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search tasks" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" aria-label="Search tasks" />
          </div>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="md:w-44" aria-label="Sort"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="due">Sort: Due date</SelectItem>
              <SelectItem value="priority">Sort: Priority</SelectItem>
              <SelectItem value="updated">Sort: Recently updated</SelectItem>
              <SelectItem value="status">Sort: Status</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-6">
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger aria-label="Status"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="open">Open (not completed)</SelectItem>
              <SelectItem value={ALL}>Any status</SelectItem>
              <SelectItem value="review">Awaiting review</SelectItem>
              {TASK_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={team} onValueChange={(v) => { setTeam(v); setProject(ALL); }}>
            <SelectTrigger aria-label="Team"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All teams</SelectItem>
              {visibleTeams.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={project} onValueChange={setProject}>
            <SelectTrigger aria-label="Project"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All projects</SelectItem>
              <SelectItem value="none">No project</SelectItem>
              {teamProjects.map((p) => <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={priority} onValueChange={setPriority}>
            <SelectTrigger aria-label="Priority"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Any priority</SelectItem>
              {PRIORITIES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={due} onValueChange={setDue}>
            <SelectTrigger aria-label="Due date"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Any due date</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
              <SelectItem value="soon">Due within 3 days</SelectItem>
              <SelectItem value="week">Due within 7 days</SelectItem>
              <SelectItem value="none">No deadline</SelectItem>
            </SelectContent>
          </Select>
          <Select value={assignee} onValueChange={setAssignee} disabled={scope === "mine" || !canSeeAll}>
            <SelectTrigger aria-label="Assigned person"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Anyone</SelectItem>
              <SelectItem value="none">Unassigned</SelectItem>
              {assignable.map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {q.isLoading ? (
        <LoadingBlock rows={5} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<CheckSquare />}
          title={scope === "mine" ? "No tasks match" : "No tasks found"}
          description={scope === "mine" ? "When a team lead assigns you a task it will show up here. Try changing the filters above." : "Try changing the filters, or create a new task."}
        />
      ) : (
        <>
          <div className="mb-2 font-mono text-xs text-muted-foreground">{filtered.length} task{filtered.length === 1 ? "" : "s"}{team !== ALL ? ` · ${teamById.get(team)?.name}` : ""}</div>
          <div className="space-y-2">{filtered.slice(0, limit).map((t) => <TaskRow key={t.id} task={t} showAssignee={scope !== "mine"} />)}</div>
          {filtered.length > limit && (
            <div className="mt-4 text-center"><Button variant="outline" onClick={() => setLimit(limit + 50)}>Show more</Button></div>
          )}
        </>
      )}
      <TaskFormDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
