import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Building2, Copy, FileSpreadsheet, KeyRound, Mail, Plug } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useMe } from "@/lib/queries";
import { rotateIntakeKey } from "@/lib/admin.functions";
import { errMsg, fmtDateTime } from "@/lib/format";
import { ConfirmAction, PageHeader, Window } from "@/components/app/bits";
import { ImportPanel } from "@/components/app/import-panel";

export const Route = createFileRoute("/_authenticated/admin/integrations")({
  head: () => ({ meta: [{ title: "Integrations — Admin — Beyond GHC" }, { name: "description", content: "Form intake, imports and organization settings." }, { property: "og:title", content: "Integrations — Admin — Beyond GHC" }, { property: "og:description", content: "Form intake, imports and organization settings." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: IntegrationsPage,
});

function IntegrationsPage() {
  const me = useMe();
  const qc = useQueryClient();
  const rotate = useServerFn(rotateIntakeKey);
  const settings = useQuery({ queryKey: ["integration_settings"], queryFn: async () => (await supabase.from("integration_settings").select("*")).data ?? [] }).data ?? [];
  const intake = (settings.find((s) => s.key === "form_intake")?.value as Record<string, unknown>) ?? {};
  const org = (settings.find((s) => s.key === "organization")?.value as Record<string, unknown>) ?? {};
  const [orgName, setOrgName] = useState("");
  const [newKey, setNewKey] = useState<string | null>(null);
  const [origin, setOrigin] = useState("");
  useEffect(() => setOrigin(window.location.origin), []);
  useEffect(() => setOrgName(String(org["name"] ?? "Beyond GHC")), [org["name"]]);
  const endpoint = `${origin}/api/public/form-intake`;

  async function saveOrg() {
    const { error } = await supabase.from("integration_settings").update({ value: { ...org, name: orgName.trim() }, updated_by: me.id }).eq("key", "organization");
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Organization name saved");
    qc.invalidateQueries({ queryKey: ["integration_settings"] });
    qc.invalidateQueries({ queryKey: ["org_name"] });
  }
  async function genKey() {
    try {
      const r = await rotate();
      setNewKey(r.key);
      qc.invalidateQueries({ queryKey: ["integration_settings"] });
    } catch (e) {
      toast.error(errMsg(e));
    }
  }
  async function setEnabled(v: boolean) {
    const { error } = await supabase.from("integration_settings").update({ value: { ...intake, enabled: v }, updated_by: me.id }).eq("key", "form_intake");
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["integration_settings"] });
  }
  const copy = (s: string) => { navigator.clipboard.writeText(s); toast.success("Copied"); };
  const keyText = newKey ?? "PASTE_YOUR_KEY_HERE";
  const appsScript = `// Google Forms → Beyond GHC portal
// In your Google Form: ⋮ → Script editor. Paste this, save,
// then Triggers → Add trigger → onFormSubmit → "From form" → "On form submit".
const ENDPOINT = "${endpoint}";
const KEY = "${keyText}";

function onFormSubmit(e) {
  const answers = { "Timestamp": new Date().toISOString() };
  e.response.getItemResponses().forEach(function (r) {
    const v = r.getResponse();
    answers[r.getItem().getTitle()] = Array.isArray(v) ? v.join(", ") : v;
  });
  const email = e.response.getRespondentEmail();
  if (email) answers["Email Address"] = email;
  UrlFetchApp.fetch(ENDPOINT, {
    method: "post",
    contentType: "application/json",
    headers: { "x-intake-key": KEY },
    payload: JSON.stringify(answers),
    muteHttpExceptions: true,
  });
}`;

  return (
    <div className="space-y-6">
      <PageHeader crumbs={[{ label: "Admin", to: "/admin" }, { label: "Integrations" }]} title="Integrations & settings" description="Connect your interest form, import spreadsheets and manage platform settings." />

      <Window title="Organization" icon={<Building2 />}>
        <div className="flex max-w-lg flex-col gap-2 sm:flex-row sm:items-end">
          <div className="flex-1 space-y-1.5"><Label htmlFor="org">Organization name</Label><Input id="org" value={orgName} onChange={(e) => setOrgName(e.target.value)} /></div>
          <Button onClick={saveOrg} disabled={!orgName.trim()}>Save</Button>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">Shown in the portal sidebar and sign-in pages. Update it once the name is final.</p>
      </Window>

      <Window title="Automatic interest-form intake" icon={<Plug />}>
        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-4 text-sm">
            <p className="text-muted-foreground">New form responses are sent to the portal automatically and land in <strong>Submissions</strong> for review. People are matched by email — repeat submissions update the same record. No login is ever created automatically.</p>
            <div className="space-y-1.5">
              <Label>Endpoint</Label>
              <div className="flex gap-2"><Input readOnly value={endpoint} className="font-mono text-xs" /><Button variant="outline" size="icon" aria-label="Copy endpoint" onClick={() => copy(endpoint)}><Copy /></Button></div>
            </div>
            <div className="space-y-1.5">
              <Label>Secret key</Label>
              {newKey ? (
                <div className="space-y-1">
                  <div className="flex gap-2"><Input readOnly value={newKey} className="font-mono text-xs" /><Button variant="outline" size="icon" aria-label="Copy key" onClick={() => copy(newKey)}><Copy /></Button></div>
                  <p className="text-xs text-amber">Copy it now — for security it won't be shown again.</p>
                </div>
              ) : intake["key_hash"] ? (
                <p className="font-mono text-xs text-muted-foreground">Key ending in …{String(intake["key_hint"] ?? "")} · created {fmtDateTime(String(intake["rotated_at"] ?? ""))}</p>
              ) : (
                <p className="text-xs text-muted-foreground">No key yet. Generate one to turn on the integration.</p>
              )}
              {intake["key_hash"] ? (
                <ConfirmAction trigger={<Button variant="outline" size="sm"><KeyRound /> Generate new key</Button>} title="Replace the current key?" description="Any form connected with the old key will stop sending until you update it." confirmLabel="Generate" onConfirm={genKey} />
              ) : (
                <Button size="sm" onClick={genKey}><KeyRound /> Generate key</Button>
              )}
            </div>
            {!!intake["key_hash"] && (
              <label className="flex items-center justify-between rounded-md border p-3">Accept new submissions<Switch checked={intake["enabled"] !== false} onCheckedChange={setEnabled} /></label>
            )}
            <div className="rounded-md bg-muted p-3 font-mono text-xs">
              Last received: {intake["last_received_at"] ? fmtDateTime(String(intake["last_received_at"])) : "never"}
              {intake["last_result"] ? <div className="text-muted-foreground">{JSON.stringify(intake["last_result"])}</div> : null}
            </div>
          </div>
          <Tabs defaultValue="google">
            <TabsList><TabsTrigger value="google">Google Forms</TabsTrigger><TabsTrigger value="microsoft">Microsoft Forms</TabsTrigger></TabsList>
            <TabsContent value="google" className="space-y-2">
              <p className="text-sm text-muted-foreground">Paste this into your form's Apps Script editor, then add an “On form submit” trigger. {!newKey && "Generate a key first so it's filled in for you."}</p>
              <div className="relative">
                <pre className="max-h-80 overflow-auto rounded-md border border-border-strong bg-sidebar p-3 font-mono text-[11px] leading-relaxed text-sidebar-foreground">{appsScript}</pre>
                <Button size="sm" variant="highlight" className="absolute right-2 top-2" onClick={() => copy(appsScript)}><Copy /> Copy</Button>
              </div>
            </TabsContent>
            <TabsContent value="microsoft" className="space-y-2 text-sm">
              <ol className="list-decimal space-y-1.5 pl-5 text-muted-foreground">
                <li>In Power Automate, create an automated flow with the trigger <em>“When a new response is submitted”</em> (Microsoft Forms).</li>
                <li>Add <em>“Get response details”</em> for the same form.</li>
                <li>Add an <em>HTTP</em> action: method <code>POST</code>, URI = the endpoint on the left, header <code>x-intake-key</code> = your secret key, header <code>Content-Type</code> = <code>application/json</code>.</li>
                <li>Body: a JSON object whose keys are your question titles (e.g. <code>"Full Name"</code>, <code>"Email Address"</code>) mapped to the dynamic answers.</li>
                <li>Save and submit a test response — it should appear under Submissions within seconds.</li>
              </ol>
              <p className="text-xs text-muted-foreground">The HTTP action requires a Power Automate premium license. If that's not available, export responses to Excel and use the import below.</p>
            </TabsContent>
          </Tabs>
        </div>
      </Window>

      <Window title="Import from spreadsheet" icon={<FileSpreadsheet />}>
        <div className="max-w-2xl"><ImportPanel /></div>
      </Window>

      <Window title="Email notifications" icon={<Mail />}>
        <p className="text-sm text-muted-foreground">
          Account emails (invitations, password resets, email confirmation) are sent automatically. Activity notifications (new tasks, comments, announcements) currently appear in each person's in-app notification center. Sending those by email requires connecting a sender email domain the organization owns — ask to set this up when you have one.
        </p>
      </Window>
    </div>
  );
}
