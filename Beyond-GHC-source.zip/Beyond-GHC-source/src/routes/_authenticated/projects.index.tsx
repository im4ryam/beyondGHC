import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Archive, FolderKanban, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { projectsQuery, tasksQuery, useLookup, useMe, type Project } from "@/lib/queries";
import { fmtDate, projectProgress } from "@/lib/format";
import { EmptyState, LoadingBlock, PageHeader, PriorityBadge, ProgressBar, ProjectStatusBadge, TeamBadge } from "@/components/app/bits";
import { ProjectFormDialog } from "@/components/app/project-form";

export const Route = createFileRoute("/_authenticated/projects/")({
  head: () => ({ meta: [{ title: "Team Projects — Beyond GHC" }, { name: "description", content: "Projects across your teams." }, { property: "og:title", content: "Team Projects — Beyond GHC" }, { property: "og:description", content: "Projects across your teams." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const me = useMe();
  const q = useQuery(projectsQuery);
  const tasks = useQuery(tasksQuery).data ?? [];
  const { teams, teamById } = useLookup();
  const [team, setTeam] = useState("all");
  const [open, setOpen] = useState(false);
  const list = useMemo(() => (q.data ?? []).filter((p) => team === "all" || p.team_id === team), [q.data, team]);
  const current = list.filter((p) => p.status !== "completed" && p.status !== "archived");
  const finished = list.filter((p) => p.status === "completed" || p.status === "archived");
  const canCreate = me.isAdmin || me.isLead;

  const card = (p: Project) => {
    const items = tasks.filter((t) => t.project_id === p.id);
    const done = items.filter((t) => t.status === "completed").length;
    return (
      <Link key={p.id} to="/projects/$projectId" params={{ projectId: p.id }} className="panel group flex flex-col p-4 transition-all hover:-translate-y-0.5 hover:border-border-strong hover:shadow-pixel">
        <div className="flex flex-wrap items-center gap-1.5">
          <TeamBadge team={teamById.get(p.team_id)} />
          <ProjectStatusBadge status={p.status} />
          <PriorityBadge priority={p.priority} />
        </div>
        <h3 className="mt-3 font-semibold group-hover:underline">{p.title}</h3>
        {p.description && <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{p.description}</p>}
        <div className="mt-auto pt-4">
          <ProgressBar value={projectProgress(items)} label={`${p.title} progress`} />
          <div className="mt-1 flex justify-between font-mono text-[11px] text-muted-foreground">
            <span>{done}/{items.length} items done</span>
            <span>{p.due_date ? `Target ${fmtDate(p.due_date + "T12:00:00")}` : "No target date"}</span>
          </div>
        </div>
      </Link>
    );
  };

  return (
    <div>
      <PageHeader
        eyebrow="Projects"
        title="Team projects"
        description="Each project has a shared checklist. Progress updates as checklist items are completed; a lead confirms when the whole project is done."
        actions={
          <>
            <Select value={team} onValueChange={setTeam}>
              <SelectTrigger className="w-56" aria-label="Filter by team"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All my teams</SelectItem>
                {teams.filter((t) => me.isAdmin || me.teamIds.includes(t.id)).map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
            {canCreate && <Button onClick={() => setOpen(true)}><Plus /> New project</Button>}
          </>
        }
      />
      {q.isLoading ? (
        <LoadingBlock rows={4} />
      ) : current.length === 0 ? (
        <EmptyState icon={<FolderKanban />} title="No active projects" description={canCreate ? "Create a project to give your team a shared checklist." : "Your team leads haven't created any projects yet."} action={canCreate && <Button onClick={() => setOpen(true)}><Plus /> New project</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{current.map(card)}</div>
      )}
      {finished.length > 0 && (
        <section className="mt-10">
          <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold"><Archive className="size-4" /> Completed & archived</h2>
          <div className="grid gap-4 opacity-90 sm:grid-cols-2 xl:grid-cols-3">{finished.map(card)}</div>
        </section>
      )}
      <ProjectFormDialog open={open} onOpenChange={setOpen} defaultTeamId={team !== "all" ? team : undefined} />
    </div>
  );
}
