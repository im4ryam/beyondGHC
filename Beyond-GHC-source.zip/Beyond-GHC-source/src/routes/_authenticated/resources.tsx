import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { BookOpen, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { canManageTeam, resourcesQuery, useLookup, useMe, type Resource } from "@/lib/queries";
import { RESOURCE_CATEGORIES, errMsg, fmtDate } from "@/lib/format";
import { ConfirmAction, EmptyState, ExternalResourceLink, LoadingBlock, PageHeader, TeamBadge } from "@/components/app/bits";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/resources")({
  head: () => ({ meta: [{ title: "Resources — Beyond GHC" }, { name: "description", content: "Shared templates, guidelines, forms and links." }, { property: "og:title", content: "Resources — Beyond GHC" }, { property: "og:description", content: "Shared templates, guidelines, forms and links." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ResourcesPage,
});

const ORG = "__org";

function ResourcesPage() {
  const me = useMe();
  const qc = useQueryClient();
  const q = useQuery(resourcesQuery);
  const { teams, teamById, profileById } = useLookup();
  const [search, setSearch] = useState("");
  const [team, setTeam] = useState("all");
  const [cat, setCat] = useState("all");
  const [editing, setEditing] = useState<Resource | null | "new">(null);
  const canAdd = me.isAdmin || me.isLead;

  const list = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (q.data ?? []).filter(
      (r) =>
        (team === "all" || (team === ORG ? !r.team_id : r.team_id === team)) &&
        (cat === "all" || r.category === cat) &&
        (!term || r.title.toLowerCase().includes(term) || r.description?.toLowerCase().includes(term) || r.url.toLowerCase().includes(term)),
    );
  }, [q.data, search, team, cat]);

  async function del(r: Resource) {
    const { error } = await supabase.from("resources").delete().eq("id", r.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Resource removed");
    qc.invalidateQueries({ queryKey: ["resources"] });
  }

  const grouped = RESOURCE_CATEGORIES.map((c) => ({ ...c, items: list.filter((r) => r.category === c.value) })).filter((g) => g.items.length);

  return (
    <div>
      <PageHeader
        eyebrow="Library"
        title="Resources"
        description="Shared documents and links for your teams. Some links (Google Drive, Canva, etc.) may require separate access from the file owner."
        actions={canAdd && <Button onClick={() => setEditing("new")}><Plus /> Add resource</Button>}
      />
      <div className="panel mb-5 grid gap-2 p-3 sm:grid-cols-[1fr_220px_200px]">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-8" placeholder="Search resources" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search resources" />
        </div>
        <Select value={team} onValueChange={setTeam}>
          <SelectTrigger aria-label="Team"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All teams</SelectItem>
            <SelectItem value={ORG}>Organization-wide</SelectItem>
            {teams.filter((t) => me.isAdmin || me.teamIds.includes(t.id)).map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={cat} onValueChange={setCat}>
          <SelectTrigger aria-label="Category"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {RESOURCE_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {q.isLoading ? (
        <LoadingBlock />
      ) : grouped.length === 0 ? (
        <EmptyState icon={<BookOpen />} title="No resources found" description={canAdd ? "Add templates, guidelines and shared folders your team uses often." : "Your team leads haven't shared any resources yet."} action={canAdd && <Button onClick={() => setEditing("new")}><Plus /> Add resource</Button>} />
      ) : (
        <div className="space-y-8">
          {grouped.map((g) => (
            <section key={g.value}>
              <h2 className="eyebrow mb-3 text-muted-foreground">{g.label} · {g.items.length}</h2>
              <div className="grid gap-3 md:grid-cols-2">
                {g.items.map((r) => (
                  <article key={r.id} className="panel flex flex-col gap-2 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold">{r.title}</h3>
                      <TeamBadge team={r.team_id ? teamById.get(r.team_id) : null} />
                    </div>
                    {r.description && <p className="text-sm text-muted-foreground">{r.description}</p>}
                    <ExternalResourceLink url={r.url} requiresAccess={r.requires_access} />
                    <div className="mt-auto flex items-center justify-between pt-2 text-xs text-muted-foreground">
                      <span>Added {fmtDate(r.created_at)} by {profileById.get(r.created_by ?? "")?.full_name ?? "—"}</span>
                      {(r.team_id ? canManageTeam(me, r.team_id) : me.isAdmin) && (
                        <span className="flex gap-1">
                          <Button size="icon" variant="ghost" className="size-7" aria-label="Edit" onClick={() => setEditing(r)}><Pencil /></Button>
                          <ConfirmAction trigger={<Button size="icon" variant="ghost" className="size-7" aria-label="Delete"><Trash2 /></Button>} title={`Remove "${r.title}"?`} confirmLabel="Remove" destructive onConfirm={() => del(r)} />
                        </span>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
      <ResourceDialog editing={editing} onClose={() => setEditing(null)} />
      <div className="mt-8 text-xs text-muted-foreground"><Badge variant="outline">Tip</Badge> Paste links to Google Drive, Docs, Sheets, Canva, PDFs or forms. Files themselves stay where they are.</div>
    </div>
  );
}

function ResourceDialog({ editing, onClose }: { editing: Resource | null | "new"; onClose: () => void }) {
  const me = useMe();
  const qc = useQueryClient();
  const { teams } = useLookup();
  const manageable = teams.filter((t) => !t.archived && canManageTeam(me, t.id));
  const r = editing && editing !== "new" ? editing : null;
  const [f, setF] = useState({ title: "", description: "", url: "", category: "links", team: ORG, requires_access: false });
  useEffect(() => {
    if (!editing) return;
    setF({
      title: r?.title ?? "",
      description: r?.description ?? "",
      url: r?.url ?? "",
      category: r?.category ?? "links",
      team: r ? r.team_id ?? ORG : me.isAdmin ? ORG : manageable[0]?.id ?? ORG,
      requires_access: r?.requires_access ?? false,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    try {
      new URL(f.url);
    } catch {
      { toast.error("Enter a full link starting with https://"); return; }
    }
    const payload = {
      title: f.title.trim(),
      description: f.description.trim() || null,
      url: f.url.trim(),
      category: f.category as Resource["category"],
      team_id: f.team === ORG ? null : f.team,
      requires_access: f.requires_access,
    };
    const { error } = r ? await supabase.from("resources").update(payload).eq("id", r.id) : await supabase.from("resources").insert({ ...payload, created_by: me.id });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(r ? "Resource updated" : "Resource added");
    qc.invalidateQueries({ queryKey: ["resources"] });
    onClose();
  }

  return (
    <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>{r ? "Edit resource" : "Add resource"}</DialogTitle></DialogHeader>
        <form onSubmit={save} className="space-y-4">
          <div className="space-y-1.5"><Label htmlFor="r-t">Title</Label><Input id="r-t" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="r-u">Link</Label><Input id="r-u" type="url" required placeholder="https://" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Team</Label>
              <Select value={f.team} onValueChange={(v) => setF({ ...f, team: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {me.isAdmin && <SelectItem value={ORG}>Organization-wide</SelectItem>}
                  {manageable.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={f.category} onValueChange={(v) => setF({ ...f, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{RESOURCE_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5"><Label htmlFor="r-d">Description</Label><Textarea id="r-d" rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <label className="flex items-center justify-between gap-3 rounded-md border p-3 text-sm">
            <span>Access may require separate permission<span className="block text-xs text-muted-foreground">Shows a notice that people may need to request access.</span></span>
            <Switch checked={f.requires_access} onCheckedChange={(v) => setF({ ...f, requires_access: v })} />
          </label>
          <DialogFooter><Button type="button" variant="ghost" onClick={onClose}>Cancel</Button><Button type="submit">Save</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
