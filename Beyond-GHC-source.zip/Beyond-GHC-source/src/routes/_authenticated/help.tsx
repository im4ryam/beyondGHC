import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { HelpCircle, Mail } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { supabase } from "@/integrations/supabase/client";
import { membersQuery, useLookup, useMe } from "@/lib/queries";
import { PageHeader, TeamBadge, UserAvatar, Window } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/help")({
  head: () => ({ meta: [{ title: "Help & Contact — Beyond GHC" }, { name: "description", content: "How to use the volunteer portal and who to contact." }, { property: "og:title", content: "Help & Contact — Beyond GHC" }, { property: "og:description", content: "How to use the volunteer portal and who to contact." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: HelpPage,
});

const FAQ = [
  { q: "How do I update a task?", a: "Open the task from My Tasks. Use the status menu to move it to In Progress, post a progress update in the comments, and press “Submit for review” when you're done. Your team lead marks it Completed." },
  { q: "What do the statuses mean?", a: "Incomplete: not started yet. In Progress: you're working on it. Revised: your lead asked for changes, or you've updated it after feedback. Completed: finished and accepted by a lead." },
  { q: "Why can't I mark my task Completed?", a: "Completion is confirmed by a team lead or administrator, so submit it for review instead." },
  { q: "How does project progress work?", a: "A project's progress bar is the share of its checklist items that are completed. The project itself is only marked complete when a lead confirms it." },
  { q: "I can't open a Google Drive or Canva link.", a: "Shared documents keep their own permissions. Use the “Request access” option on the document, or ask your team lead." },
  { q: "How do I change notifications?", a: "Go to My Account → Notifications to turn optional notifications on or off." },
  { q: "Who can see my phone number and email?", a: "Only administrators and the leads of teams you're on. Other volunteers can't see your contact details." },
];

function HelpPage() {
  const me = useMe();
  const members = useQuery(membersQuery).data ?? [];
  const { profileById, teamById } = useLookup();
  const leads = members.filter((m) => m.is_lead && me.teamIds.includes(m.team_id) && m.user_id !== me.id);
  const contacts = useQuery({
    queryKey: ["lead_contacts", leads.map((l) => l.user_id).join(",")],
    queryFn: async () => (await supabase.from("profile_private").select("user_id, email").in("user_id", leads.map((l) => l.user_id))).data ?? [],
    enabled: leads.length > 0,
  }).data ?? [];

  return (
    <div>
      <PageHeader eyebrow="Support" title="Help & contact" description="Quick answers, and the people to reach out to." />
      <div className="grid gap-6 lg:grid-cols-3">
        <Window title="Frequently asked" icon={<HelpCircle />} className="lg:col-span-2">
          <Accordion type="single" collapsible>
            {FAQ.map((f, i) => (
              <AccordionItem key={i} value={`q${i}`}>
                <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Window>
        <Window title="Your team leads" icon={<Mail />}>
          {leads.length === 0 ? (
            <p className="text-sm text-muted-foreground">{me.teamIds.length ? "Your teams don't have a lead assigned yet." : "Once you're on a team, its lead appears here."} You can always contact an administrator.</p>
          ) : (
            <ul className="space-y-3">
              {leads.map((l) => {
                const p = profileById.get(l.user_id);
                const email = contacts.find((c) => c.user_id === l.user_id)?.email;
                return (
                  <li key={l.id} className="flex gap-3">
                    <UserAvatar name={p?.full_name} url={p?.avatar_url} />
                    <div className="min-w-0 text-sm">
                      <div className="font-medium">{p?.full_name}</div>
                      <TeamBadge team={teamById.get(l.team_id)} />
                      {email && <a href={`mailto:${email}`} className="mt-1 block truncate text-xs text-primary hover:underline">{email}</a>}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
          <p className="mt-4 border-t pt-3 text-xs text-muted-foreground">Want to restart the welcome tour? Ask an admin to reset it, or reread the tips here. <Link to="/tasks" className="text-primary hover:underline">Go to my tasks →</Link></p>
        </Window>
      </div>
    </div>
  );
}
