import { useEffect, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Camera, KeyRound, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useMe } from "@/lib/queries";
import { TIMEZONES, errMsg, fmtDate } from "@/lib/format";
import { PageHeader, TeamBadge, UserAvatar, Window } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({ meta: [{ title: "My Account — Beyond GHC" }, { name: "description", content: "Edit your volunteer profile and preferences." }, { property: "og:title", content: "My Account — Beyond GHC" }, { property: "og:description", content: "Edit your volunteer profile and preferences." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: AccountPage,
});

async function resizeToDataUrl(file: File, size = 192): Promise<string> {
  const img = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not resize this image");
  const s = Math.min(img.width, img.height);
  ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
  return canvas.toDataURL("image/jpeg", 0.85);
}

const PREFS = [
  { key: "announcements", label: "New announcements" },
  { key: "comments", label: "Comments on my tasks" },
  { key: "project_updates", label: "Project status changes" },
  { key: "status_changes", label: "Status changes on my tasks" },
];

function AccountPage() {
  const me = useMe();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [f, setF] = useState({
    full_name: me.profile.full_name,
    linkedin_url: me.profile.linkedin_url ?? "",
    timezone: me.profile.timezone,
    availability: me.profile.availability ?? "",
    monthly_hours: me.profile.monthly_hours?.toString() ?? "",
    bio: me.profile.bio ?? "",
    phone: me.phone ?? "",
  });
  const [prefs, setPrefs] = useState<Record<string, boolean>>(me.notificationPrefs);
  const [email, setEmail] = useState("");
  const [emailBusy, setEmailBusy] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [saving, setSaving] = useState(false);
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  useEffect(() => setPrefs(me.notificationPrefs), [me.notificationPrefs]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!f.full_name.trim()) { toast.error("Name is required"); return; }
    if (f.linkedin_url && !/^https?:\/\//.test(f.linkedin_url)) { toast.error("LinkedIn URL should start with https://"); return; }
    setSaving(true);
    const [a, b] = await Promise.all([
      supabase.from("profiles").update({
        full_name: f.full_name.trim(),
        linkedin_url: f.linkedin_url.trim() || null,
        timezone: f.timezone,
        availability: f.availability.trim() || null,
        monthly_hours: f.monthly_hours ? Number(f.monthly_hours) : null,
        bio: f.bio.trim() || null,
      }).eq("id", me.id),
      supabase.from("profile_private").update({ phone: f.phone.trim() || null }).eq("user_id", me.id),
    ]);
    setSaving(false);
    if (a.error || b.error) { toast.error(errMsg(a.error ?? b.error)); return; }
    toast.success("Profile saved");
    qc.invalidateQueries({ queryKey: ["me"] });
    qc.invalidateQueries({ queryKey: ["profiles"] });
  }

  async function savePrefs(next: Record<string, boolean>) {
    setPrefs(next);
    const { error } = await supabase.from("profile_private").update({ notification_prefs: next }).eq("user_id", me.id);
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["me"] });
  }

  async function onAvatar(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Choose an image file"); return; }
    try {
      const url = await resizeToDataUrl(file);
      const { error } = await supabase.from("profiles").update({ avatar_url: url }).eq("id", me.id);
      if (error) throw error;
      toast.success("Photo updated");
      qc.invalidateQueries({ queryKey: ["me"] });
      qc.invalidateQueries({ queryKey: ["profiles"] });
    } catch (e) {
      toast.error(errMsg(e));
    }
  }
  async function removeAvatar() {
    await supabase.from("profiles").update({ avatar_url: null }).eq("id", me.id);
    qc.invalidateQueries({ queryKey: ["me"] });
    qc.invalidateQueries({ queryKey: ["profiles"] });
  }

  async function changeEmail(e: React.FormEvent) {
    e.preventDefault();
    if (email.trim().toLowerCase() === me.email.toLowerCase()) { toast.error("Enter a different email address"); return; }
    setEmailBusy(true);
    const { error } = await supabase.auth.updateUser({ email: email.trim() }, { emailRedirectTo: window.location.origin });
    setEmailBusy(false);
    if (error) { toast.error(error.message); return; }
    setEmailSent(true);
    toast.success("Check your email to confirm the change");
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pw.next.length < 8) { toast.error("Use at least 8 characters"); return; }
    if (pw.next !== pw.confirm) { toast.error("New passwords don't match"); return; }
    const { error } = await supabase.auth.updateUser({ password: pw.next, current_password: pw.current } as Parameters<typeof supabase.auth.updateUser>[0]);
    if (error) { toast.error(error.message); return; }
    toast.success("Password changed");
    setPw({ current: "", next: "", confirm: "" });
  }

  return (
    <div>
      <PageHeader eyebrow="Account" title="My account" description="Update your personal details. Team assignments, role and account status are managed by administrators." />
      <div className="grid gap-6 lg:grid-cols-3">
        <form onSubmit={save} className="space-y-6 lg:col-span-2">
          <Window title="Profile">
            <div className="mb-5 flex items-center gap-4">
              <UserAvatar name={f.full_name} url={me.profile.avatar_url} size="lg" />
              <div className="flex flex-wrap gap-2">
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => onAvatar(e.target.files?.[0])} />
                <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()}><Camera /> Upload photo</Button>
                {me.profile.avatar_url && <Button type="button" variant="ghost" size="sm" onClick={removeAvatar}><Trash2 /> Remove</Button>}
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Full name" id="name"><Input id="name" value={f.full_name} onChange={set("full_name")} required /></Field>
              <Field label="Email" id="email" hint="Use the Email section to request a sign-in email change."><Input id="email" value={me.email} disabled /></Field>
              <Field label="Phone (optional)" id="phone" hint="Visible only to admins and your team leads."><Input id="phone" type="tel" value={f.phone} onChange={set("phone")} /></Field>
              <Field label="LinkedIn (optional)" id="li"><Input id="li" type="url" placeholder="https://linkedin.com/in/…" value={f.linkedin_url} onChange={set("linkedin_url")} /></Field>
              <Field label="Time zone" id="tz" hint="Deadlines are shown in this time zone.">
                <Select value={f.timezone} onValueChange={(v) => setF({ ...f, timezone: v })}>
                  <SelectTrigger id="tz"><SelectValue /></SelectTrigger>
                  <SelectContent>{TIMEZONES.map((t) => <SelectItem key={t} value={t}>{t.replace("_", " ")}</SelectItem>)}</SelectContent>
                </Select>
              </Field>
              <Field label="Expected hours per month" id="hrs"><Input id="hrs" type="number" min={0} max={200} value={f.monthly_hours} onChange={set("monthly_hours")} /></Field>
              <div className="sm:col-span-2"><Field label="Availability" id="av"><Input id="av" placeholder="e.g. Weekday evenings ET, some weekends" value={f.availability} onChange={set("availability")} /></Field></div>
              <div className="sm:col-span-2"><Field label="Short bio" id="bio"><Textarea id="bio" rows={3} value={f.bio} onChange={set("bio")} /></Field></div>
            </div>
            <div className="mt-5 flex justify-end"><Button type="submit" disabled={saving}><Save /> {saving ? "Saving…" : "Save profile"}</Button></div>
          </Window>
        </form>

        <div className="space-y-6">
          <Window title="Membership">
            <dl className="space-y-3 text-sm">
              <div><dt className="text-xs text-muted-foreground">Role</dt><dd className="font-medium">{me.isOwner ? "Primary Owner" : me.isAdmin ? "Co-Administrator" : me.isLead ? "Team Lead" : "Volunteer"}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Teams</dt><dd className="mt-1 flex flex-wrap gap-1">{me.memberships.length ? me.memberships.map((m) => <TeamBadge key={m.team_id} team={m.team} />) : "None yet"}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Status</dt><dd className="capitalize">{me.profile.status}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Joined</dt><dd>{fmtDate(me.profile.joined_at)}</dd></div>
            </dl>
          </Window>
          <Window title="Notifications">
            <div className="space-y-3">
              {PREFS.map((p) => (
                <label key={p.key} className="flex items-center justify-between gap-3 text-sm">
                  {p.label}
                  <Switch checked={prefs[p.key] !== false} onCheckedChange={(v) => savePrefs({ ...prefs, [p.key]: v })} />
                </label>
              ))}
              <p className="text-xs text-muted-foreground">Task assignments, review requests and feedback are always delivered.</p>
            </div>
          </Window>
          <Window title="Email">
            <form onSubmit={changeEmail} className="space-y-3">
              <Field label="New email address" id="account-new-email"><Input id="account-new-email" type="email" autoComplete="email" value={email} onChange={(e) => { setEmail(e.target.value); setEmailSent(false); }} required /></Field>
              <Button type="submit" variant="outline" className="w-full" disabled={emailBusy}>{emailBusy ? "Sending…" : "Send confirmation"}</Button>
              {emailSent && <p role="status" className="text-sm text-muted-foreground">Check your new email for confirmation. If asked, confirm from your current email too. Your sign-in email changes only after confirmation.</p>}
            </form>
          </Window>
          <Window title="Password" icon={<KeyRound />}>
            <form onSubmit={changePassword} className="space-y-3">
              <Field label="Current password" id="cur"><Input id="cur" type="password" autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} required /></Field>
              <Field label="New password" id="new"><Input id="new" type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} required /></Field>
              <Field label="Confirm new password" id="conf"><Input id="conf" type="password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} required /></Field>
              <Button type="submit" variant="outline" className="w-full">Change password</Button>
              <Button asChild variant="ghost" className="w-full"><Link to="/forgot-password">Reset password by email</Link></Button>
            </form>
          </Window>
        </div>
      </div>
    </div>
  );
}

function Field({ label, id, hint, children }: { label: string; id: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
