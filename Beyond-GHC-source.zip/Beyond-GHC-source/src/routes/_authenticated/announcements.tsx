import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Megaphone, Pencil, Pin, PinOff, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { announcementsQuery, canManageTeam, useLookup, useMe, type Announcement } from "@/lib/queries";
import { errMsg, fmtDateTime } from "@/lib/format";
import { ConfirmAction, EmptyState, ExternalResourceLink, LoadingBlock, PageHeader, TeamBadge, UserAvatar } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/announcements")({
  head: () => ({ meta: [{ title: "Announcements — Beyond GHC" }, { name: "description", content: "Organization and team announcements." }, { property: "og:title", content: "Announcements — Beyond GHC" }, { property: "og:description", content: "Organization and team announcements." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: AnnouncementsPage,
});

const ORG = "__org";

function AnnouncementsPage() {
  const me = useMe();
  const qc = useQueryClient();
  const q = useQuery(announcementsQuery);
  const { teamById, profileById, teams } = useLookup();
  const [filter, setFilter] = useState("all");
  const [editing, setEditing] = useState<Announcement | "new" | null>(null);
  const canPost = me.isAdmin || me.isLead;
  const list = (q.data ?? []).filter((a) => filter === "all" || (filter === ORG ? !a.team_id : a.team_id === filter));
  const canEdit = (a: Announcement) => (a.team_id ? canManageTeam(me, a.team_id) : me.isAdmin);

  async function patch(a: Announcement, p: Partial<Announcement>, msg: string) {
    const { error } = await supabase.from("announcements").update(p).eq("id", a.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(msg);
    qc.invalidateQueries({ queryKey: ["announcements"] });
  }
  async function del(a: Announcement) {
    const { error } = await supabase.from("announcements").delete().eq("id", a.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Announcement deleted");
    qc.invalidateQueries({ queryKey: ["announcements"] });
  }

  return (
    <div>
      <PageHeader
        eyebrow="Bulletin board"
        title="Announcements"
        description="Updates for the whole organization and for your teams. Pinned posts stay on top."
        actions={
          <>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-52" aria-label="Audience"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All announcements</SelectItem>
                <SelectItem value={ORG}>Organization-wide</SelectItem>
                {teams.filter((t) => me.isAdmin || me.teamIds.includes(t.id)).map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
            {canPost && <Button onClick={() => setEditing("new")}><Plus /> New announcement</Button>}
          </>
        }
      />
      {q.isLoading ? (
        <LoadingBlock />
      ) : list.length === 0 ? (
        <EmptyState icon={<Megaphone />} title="No announcements yet" description={canPost ? "Post an update for everyone or for one of your teams." : "Updates from organizers and team leads will appear here."} />
      ) : (
        <div className="space-y-4">
          {list.map((a) => {
            const author = profileById.get(a.author_id ?? "");
            return (
              <article key={a.id} className={a.pinned ? "window p-5" : "panel p-5"}>
                <div className="flex flex-wrap items-center gap-2">
                  {a.pinned && <Badge variant="amber"><Pin className="size-3" /> Pinned</Badge>}
                  <TeamBadge team={a.team_id ? teamById.get(a.team_id) : null} />
                  <span className="font-mono text-[11px] text-muted-foreground">{fmtDateTime(a.created_at, me.profile.timezone)}</span>
                </div>
                <h2 className="mt-2 text-lg font-semibold">{a.title}</h2>
                <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed">{a.body}</p>
                {a.link && <div className="mt-3"><ExternalResourceLink url={a.link} title="Attached link" /></div>}
                <div className="mt-4 flex items-center justify-between gap-2 border-t pt-3">
                  <span className="flex items-center gap-2 text-xs text-muted-foreground"><UserAvatar name={author?.full_name} url={author?.avatar_url} size="sm" />{author?.full_name ?? "Organizer"}</span>
                  {canEdit(a) && (
                    <span className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => patch(a, { pinned: !a.pinned }, a.pinned ? "Unpinned" : "Pinned")}>{a.pinned ? <PinOff /> : <Pin />}{a.pinned ? "Unpin" : "Pin"}</Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditing(a)}><Pencil /> Edit</Button>
                      <ConfirmAction trigger={<Button size="sm" variant="ghost" aria-label="Delete"><Trash2 /></Button>} title="Delete this announcement?" confirmLabel="Delete" destructive onConfirm={() => del(a)} />
                    </span>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
      <AnnouncementDialog editing={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function AnnouncementDialog({ editing, onClose }: { editing: Announcement | "new" | null; onClose: () => void }) {
  const me = useMe();
  const qc = useQueryClient();
  const { teams } = useLookup();
  const manageable = teams.filter((t) => !t.archived && canManageTeam(me, t.id));
  const a = editing && editing !== "new" ? editing : null;
  const [f, setF] = useState({ title: "", body: "", link: "", team: ORG, pinned: false });
  useEffect(() => {
    if (!editing) return;
    setF({ title: a?.title ?? "", body: a?.body ?? "", link: a?.link ?? "", team: a ? a.team_id ?? ORG : me.isAdmin ? ORG : manageable[0]?.id ?? ORG, pinned: a?.pinned ?? false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!f.title.trim() || !f.body.trim()) { toast.error("Title and message are required"); return; }
    if (f.link) {
      try {
        new URL(f.link);
      } catch {
        { toast.error("The link should start with https://"); return; }
      }
    }
    const payload = { title: f.title.trim(), body: f.body.trim(), link: f.link.trim() || null, team_id: f.team === ORG ? null : f.team, pinned: f.pinned };
    const { error } = a ? await supabase.from("announcements").update(payload).eq("id", a.id) : await supabase.from("announcements").insert({ ...payload, author_id: me.id });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(a ? "Announcement updated" : "Announcement posted");
    qc.invalidateQueries({ queryKey: ["announcements"] });
    qc.invalidateQueries({ queryKey: ["notifications"] });
    onClose();
  }

  return (
    <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>{a ? "Edit announcement" : "New announcement"}</DialogTitle></DialogHeader>
        <form onSubmit={save} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Audience</Label>
            <Select value={f.team} onValueChange={(v) => setF({ ...f, team: v })} disabled={!!a}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {me.isAdmin && <SelectItem value={ORG}>Everyone (organization-wide)</SelectItem>}
                {manageable.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5"><Label htmlFor="a-t">Title</Label><Input id="a-t" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} required maxLength={200} /></div>
          <div className="space-y-1.5"><Label htmlFor="a-b">Message</Label><Textarea id="a-b" rows={6} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} required /></div>
          <div className="space-y-1.5"><Label htmlFor="a-l">Link or attachment (optional)</Label><Input id="a-l" type="url" placeholder="https://" value={f.link} onChange={(e) => setF({ ...f, link: e.target.value })} /></div>
          <label className="flex items-center justify-between rounded-md border p-3 text-sm">Pin to the top<Switch checked={f.pinned} onCheckedChange={(v) => setF({ ...f, pinned: v })} /></label>
          <DialogFooter><Button type="button" variant="ghost" onClick={onClose}>Cancel</Button><Button type="submit">{a ? "Save" : "Post"}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
