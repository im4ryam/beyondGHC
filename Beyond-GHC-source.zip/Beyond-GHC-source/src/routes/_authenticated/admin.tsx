import { createFileRoute, Outlet } from "@tanstack/react-router";
import { useMe } from "@/lib/queries";
import { NoAccess } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminLayout,
});

function AdminLayout() {
  const me = useMe();
  if (!me.isAdmin) return <NoAccess message="The admin area is only for the Primary Owner and Co-Administrators." />;
  return <Outlet />;
}
