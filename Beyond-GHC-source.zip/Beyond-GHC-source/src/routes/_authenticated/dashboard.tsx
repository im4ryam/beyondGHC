import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle2,
  CircleDashed,
  Clock,
  Eye,
  FolderKanban,
  Inbox,
  ListChecks,
  Megaphone,
  Plus,
  ShieldCheck,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  announcementsQuery,
  membersQuery,
  projectsQuery,
  tasksQuery,
  useLookup,
  useMe,
} from "@/lib/queries";
import { dueState, fmtDate, fmtRelative, projectProgress } from "@/lib/format";
import { EmptyState, LoadingBlock, PageHeader, ProgressBar, ProjectStatusBadge, StatCard, TeamBadge, UserAvatar, Window } from "@/components/app/bits";
import { TaskRow } from "@/components/app/task-row";
import { TaskFormDialog } from "@/components/app/task-form";
import { ProjectFormDialog } from "@/components/app/project-form";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Beyond GHC" }, { name: "description", content: "Your personal volunteer dashboard." }, { property: "og:title", content: "Dashboard — Beyond GHC" }, { property: "og:description", content: "Your personal volunteer dashboard." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Dashboard,
});

function Dashboard() {
  const me = useMe();
  const tasksQ = useQuery(tasksQuery);
  const tasks = tasksQ.data ?? [];
  const projects = useQuery(projectsQuery).data ?? [];
  const announcements = useQuery(announcementsQuery).data ?? [];
  const members = useQuery(membersQuery).data ?? [];
  const { teamById, profileById } = useLookup();
  const [taskOpen, setTaskOpen] = useState(false);
  const [projectOpen, setProjectOpen] = useState(false);

  const mine = tasks.filter((t) => t.assignee_id === me.id);
  const counts = {
    incomplete: mine.filter((t) => t.status === "incomplete").length,
    inProgress: mine.filter((t) => t.status === "in_progress" || t.status === "revised").length,
    review: mine.filter((t) => t.awaiting_review && t.status !== "completed").length,
    done: mine.filter((t) => t.status === "completed").length,
    overdue: mine.filter((t) => dueState(t.due_date, t.status) === "overdue").length,
  };
  const upcoming = mine
    .filter((t) => t.status !== "completed" && t.due_date)
    .sort((a, b) => (a.due_date ?? "").localeCompare(b.due_date ?? ""))
    .slice(0, 6);
  const myProjects = projects.filter((p) => me.teamIds.includes(p.team_id) && p.status !== "archived").slice(0, 5);
  const recentAnn = announcements.filter((a) => !a.team_id || me.teamIds.includes(a.team_id)).slice(0, 4);
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={me.isOwner ? "Primary owner" : me.isAdmin ? "Co-administrator" : me.isLead ? "Team lead" : "Volunteer"}
        title={`${greet}, ${me.profile.full_name.split(" ")[0]}`}
        description={me.teamIds.length ? "Here's what's happening across your teams." : "You're not on a team yet. An administrator will add you soon."}
        actions={
          (me.isAdmin || me.teamIds.length > 0) && (
            <>
              {(me.isAdmin || me.isLead) && <Button variant="outline" onClick={() => setProjectOpen(true)}><FolderKanban /> New project</Button>}
              <Button onClick={() => setTaskOpen(true)}><Plus /> {me.isAdmin || me.isLead ? "Assign task" : "New task"}</Button>
            </>
          )
        }
      />

      {me.isAdmin && <AdminStrip />}

      <section aria-label="My task summary" className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard label="Incomplete" value={counts.incomplete} icon={<CircleDashed />} tone="slate" to="/tasks" />
        <StatCard label="In progress" value={counts.inProgress} icon={<Clock />} tone="dusty" to="/tasks" />
        <StatCard label="Awaiting review" value={counts.review} icon={<Eye />} tone="lavender" to="/tasks" />
        <StatCard label="Completed" value={counts.done} icon={<CheckCircle2 />} tone="sage" to="/tasks" />
        <StatCard label="Overdue" value={counts.overdue} icon={<AlertTriangle />} tone={counts.overdue ? "danger" : "slate"} to="/tasks" />
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Window title="Upcoming deadlines" icon={<Clock />} actions={<Link to="/tasks" className="text-xs text-primary hover:underline">All my tasks</Link>}>
            {tasksQ.isLoading ? (
              <LoadingBlock />
            ) : upcoming.length ? (
              <div className="space-y-2">{upcoming.map((t) => <TaskRow key={t.id} task={t} showAssignee={false} />)}</div>
            ) : (
              <EmptyState compact icon={<CheckCircle2 />} title="Nothing due" description="Tasks assigned to you with a deadline will appear here." />
            )}
          </Window>

          {me.leadTeamIds.map((teamId) => {
            const team = teamById.get(teamId);
            if (!team) return null;
            const tt = tasks.filter((t) => t.team_id === teamId);
            const done = tt.filter((t) => t.status === "completed").length;
            const overdue = tt.filter((t) => dueState(t.due_date, t.status) === "overdue");
            const review = tt.filter((t) => t.awaiting_review && t.status !== "completed");
            const activeProjects = projects.filter((p) => p.team_id === teamId && (p.status === "active" || p.status === "planning"));
            const memberCount = members.filter((m) => m.team_id === teamId).length;
            const recent = [...tt].sort((a, b) => (a.updated_at > b.updated_at ? -1 : 1)).slice(0, 4);
            return (
              <Window key={teamId} title={`Team lead · ${team.name}`} icon={<Users />} actions={<Link to="/teams/$teamId" params={{ teamId }} className="text-xs text-primary hover:underline">Open team</Link>}>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <Mini label="Members" value={memberCount} />
                  <Mini label="Active projects" value={activeProjects.length} />
                  <Mini label="Overdue" value={overdue.length} danger={overdue.length > 0} />
                  <Mini label="Awaiting review" value={review.length} />
                </div>
                <div className="mt-4">
                  <div className="mb-1 text-xs text-muted-foreground">Team task completion</div>
                  <ProgressBar value={tt.length ? Math.round((done / tt.length) * 100) : 0} />
                </div>
                {review.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <div className="eyebrow text-lavender">Needs your review</div>
                    {review.slice(0, 4).map((t) => <TaskRow key={t.id} task={t} showTeam={false} />)}
                  </div>
                )}
                {overdue.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <div className="eyebrow text-destructive">Overdue</div>
                    {overdue.slice(0, 4).map((t) => <TaskRow key={t.id} task={t} showTeam={false} />)}
                  </div>
                )}
                {recent.length > 0 && (
                  <div className="mt-4 space-y-1">
                    <div className="eyebrow text-muted-foreground">Recently updated</div>
                    {recent.map((t) => (
                      <Link key={t.id} to="/tasks/$taskId" params={{ taskId: t.id }} className="flex items-center justify-between gap-2 rounded px-1 py-1 text-sm hover:bg-muted">
                        <span className="truncate">{t.title}</span>
                        <span className="shrink-0 text-xs text-muted-foreground">{fmtRelative(t.updated_at)}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </Window>
            );
          })}

          <Window title="Recently updated projects" icon={<FolderKanban />} actions={<Link to="/projects" className="text-xs text-primary hover:underline">All projects</Link>}>
            {myProjects.length ? (
              <ul className="divide-y">
                {myProjects.map((p) => {
                  const items = tasks.filter((t) => t.project_id === p.id);
                  return (
                    <li key={p.id} className="py-3 first:pt-0 last:pb-0">
                      <Link to="/projects/$projectId" params={{ projectId: p.id }} className="group block">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-medium group-hover:underline">{p.title}</span>
                          <span className="flex items-center gap-2">
                            <TeamBadge team={teamById.get(p.team_id)} />
                            <ProjectStatusBadge status={p.status} />
                          </span>
                        </div>
                        <ProgressBar className="mt-2" value={projectProgress(items)} />
                        <div className="mt-1 text-xs text-muted-foreground">{items.length} checklist items · updated {fmtRelative(p.updated_at)}</div>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <EmptyState compact icon={<FolderKanban />} title="No projects yet" description="Projects your teams are working on will appear here." />
            )}
          </Window>
        </div>

        <div className="space-y-6">
          <Window title="Profile" icon={<Users />}>
            <div className="flex items-center gap-3">
              <UserAvatar name={me.profile.full_name} url={me.profile.avatar_url} size="lg" />
              <div className="min-w-0">
                <div className="truncate font-semibold">{me.profile.full_name}</div>
                <div className="truncate text-xs text-muted-foreground">{me.email}</div>
                <div className="mt-1 font-mono text-[11px] text-muted-foreground">{me.profile.timezone}</div>
              </div>
            </div>
            <div className="mt-4 space-y-1.5">
              <div className="eyebrow text-muted-foreground">My teams</div>
              {me.memberships.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {me.memberships.map((m) => (
                    <Link key={m.team_id} to="/teams/$teamId" params={{ teamId: m.team_id }}>
                      <TeamBadge team={m.team} />
                      {m.is_lead && <span className="sr-only"> (lead)</span>}
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Not assigned to a team yet.</p>
              )}
            </div>
            <Button asChild variant="outline" size="sm" className="mt-4 w-full"><Link to="/account">Edit profile</Link></Button>
          </Window>

          <Window title="Announcements" icon={<Megaphone />} actions={<Link to="/announcements" className="text-xs text-primary hover:underline">All</Link>}>
            {recentAnn.length ? (
              <ul className="space-y-3">
                {recentAnn.map((a) => (
                  <li key={a.id}>
                    <Link to="/announcements" className="group block">
                      <div className="flex items-center gap-2">
                        {a.pinned && <Badge variant="amber">Pinned</Badge>}
                        <span className="truncate text-sm font-medium group-hover:underline">{a.title}</span>
                      </div>
                      <div className="mt-0.5 text-xs text-muted-foreground">
                        {a.team_id ? teamById.get(a.team_id)?.name : "Everyone"} · {profileById.get(a.author_id ?? "")?.full_name ?? "Admin"} · {fmtDate(a.created_at)}
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState compact icon={<Megaphone />} title="No announcements" />
            )}
          </Window>

          <Window title="Quick links" icon={<ListChecks />}>
            <div className="grid gap-2">
              <Button asChild variant="outline" className="justify-start"><Link to="/tasks"><ListChecks /> My individual checklist</Link></Button>
              <Button asChild variant="outline" className="justify-start"><Link to="/checklists"><FolderKanban /> Team checklists</Link></Button>
              <Button asChild variant="outline" className="justify-start"><Link to="/calendar"><Clock /> Calendar</Link></Button>
            </div>
          </Window>
        </div>
      </div>

      <TaskFormDialog open={taskOpen} onOpenChange={setTaskOpen} />
      <ProjectFormDialog open={projectOpen} onOpenChange={setProjectOpen} />
    </div>
  );
}

function Mini({ label, value, danger }: { label: string; value: number; danger?: boolean }) {
  return (
    <div className="rounded-md border bg-muted/50 px-3 py-2">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className={`font-mono text-xl font-semibold ${danger ? "text-destructive" : ""}`}>{value}</div>
    </div>
  );
}

function AdminStrip() {
  const tasks = useQuery(tasksQuery).data ?? [];
  const projects = useQuery(projectsQuery).data ?? [];
  const pending = useQuery({
    queryKey: ["admin_pending_counts"],
    queryFn: async () => {
      const [subs, accounts, active] = await Promise.all([
        supabase.from("interest_submissions").select("id", { count: "exact", head: true }).in("status", ["new", "reviewing"]),
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("status", "active"),
      ]);
      return { subs: subs.count ?? 0, accounts: accounts.count ?? 0, active: active.count ?? 0 };
    },
  }).data;
  const done = tasks.filter((t) => t.status === "completed").length;
  return (
    <section aria-label="Organization overview" className="rounded-lg border border-border-strong bg-sidebar p-4 text-sidebar-foreground shadow-pixel">
      <div className="mb-3 flex items-center justify-between">
        <div className="eyebrow flex items-center gap-2 text-sidebar-primary"><ShieldCheck className="size-3.5" /> Organization</div>
        <Link to="/admin" className="text-xs text-sidebar-primary hover:underline">Admin overview →</Link>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <AdminNum label="Active volunteers" value={pending?.active ?? "–"} to="/admin/members" />
        <AdminNum label="New submissions" value={pending?.subs ?? "–"} to="/admin/submissions" />
        <AdminNum label="Pending accounts" value={pending?.accounts ?? "–"} to="/admin/members" />
        <AdminNum label="Active projects" value={projects.filter((p) => p.status === "active").length} to="/projects" />
        <AdminNum label="Overall completion" value={tasks.length ? `${Math.round((done / tasks.length) * 100)}%` : "–"} to="/admin" />
        <AdminNum label="Overdue tasks" value={tasks.filter((t) => dueState(t.due_date, t.status) === "overdue").length} to="/admin" />
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button asChild size="sm" variant="highlight"><Link to="/admin/submissions"><Inbox /> Review submissions</Link></Button>
        <Button asChild size="sm" variant="outline" className="border-sidebar-border bg-sidebar-accent text-sidebar-foreground hover:bg-sidebar-accent/70 hover:text-sidebar-foreground"><Link to="/admin/members"><Users /> Manage members</Link></Button>
      </div>
    </section>
  );
}

function AdminNum({ label, value, to }: { label: string; value: number | string; to: string }) {
  return (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    <Link to={to as any} className="rounded-sm px-1 hover:bg-sidebar-accent">
      <div className="font-mono text-2xl font-semibold">{value}</div>
      <div className="text-[11px] text-sidebar-muted">{label}</div>
    </Link>
  );
}
