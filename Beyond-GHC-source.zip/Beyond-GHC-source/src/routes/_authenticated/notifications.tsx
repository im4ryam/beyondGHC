import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AlarmClock, Bell, CheckCheck, Settings, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { notificationsQuery, tasksQuery, useMe } from "@/lib/queries";
import { dueState, fmtDate, fmtRelative } from "@/lib/format";
import { EmptyState, LoadingBlock, PageHeader, Window } from "@/components/app/bits";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications — Beyond GHC" }, { name: "description", content: "Your notification center." }, { property: "og:title", content: "Notifications — Beyond GHC" }, { property: "og:description", content: "Your notification center." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const me = useMe();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const q = useQuery(notificationsQuery);
  const tasks = useQuery(tasksQuery).data ?? [];
  const reminders = tasks.filter((t) => t.assignee_id === me.id && ["overdue", "soon"].includes(dueState(t.due_date, t.status)));
  const list = q.data ?? [];
  const unread = list.filter((n) => !n.read_at).length;

  async function markAll() {
    const { error } = await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("user_id", me.id).is("read_at", null);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }
  async function open(id: string, link: string | null, read: boolean) {
    if (!read) await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications"] });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if (link) navigate({ to: link as any });
  }
  async function clearRead() {
    const { error } = await supabase.from("notifications").delete().eq("user_id", me.id).not("read_at", "is", null);
    if (error) { toast.error(error.message); return; }
    toast.success("Cleared read notifications");
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }

  return (
    <div>
      <PageHeader
        eyebrow="Inbox"
        title="Notifications"
        description={`${unread} unread`}
        actions={
          <>
            <Button variant="outline" onClick={markAll} disabled={!unread}><CheckCheck /> Mark all read</Button>
            <Button variant="ghost" onClick={clearRead}><Trash2 /> Clear read</Button>
            <Button asChild variant="ghost"><Link to="/account"><Settings /> Preferences</Link></Button>
          </>
        }
      />
      {reminders.length > 0 && (
        <Window title="Deadline reminders" icon={<AlarmClock />} className="mb-6">
          <ul className="space-y-2 text-sm">
            {reminders.map((t) => (
              <li key={t.id}>
                <Link to="/tasks/$taskId" params={{ taskId: t.id }} className="flex justify-between gap-2 hover:underline">
                  <span>{t.title}</span>
                  <span className={cn("font-mono text-xs", dueState(t.due_date, t.status) === "overdue" ? "text-destructive" : "text-amber")}>
                    {dueState(t.due_date, t.status) === "overdue" ? "Overdue" : "Due"} {fmtDate(t.due_date, me.profile.timezone)}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </Window>
      )}
      {q.isLoading ? (
        <LoadingBlock />
      ) : list.length === 0 ? (
        <EmptyState icon={<Bell />} title="You're all caught up" description="New assignments, comments, feedback and announcements will show up here." />
      ) : (
        <ul className="panel divide-y overflow-hidden">
          {list.map((n) => (
            <li key={n.id}>
              <button onClick={() => open(n.id, n.link, !!n.read_at)} className={cn("flex w-full items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-muted", !n.read_at && "bg-dusty-soft/50")}>
                <span className={cn("mt-1.5 size-2 shrink-0 rounded-sm border border-border-strong", n.read_at ? "bg-card" : "bg-highlight")} aria-hidden />
                <span className="min-w-0 flex-1">
                  <span className={cn("block text-sm", !n.read_at && "font-semibold")}>{n.title}</span>
                  {n.body && <span className="block truncate text-sm text-muted-foreground">{n.body}</span>}
                </span>
                <span className="shrink-0 font-mono text-[11px] text-muted-foreground">{fmtRelative(n.created_at)}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
