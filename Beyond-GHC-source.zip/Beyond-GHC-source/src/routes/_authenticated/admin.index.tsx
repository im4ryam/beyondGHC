import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, AlertTriangle, CalendarDays, CheckCircle2, FolderKanban, Inbox, Mic, UserCheck, UserPlus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { eventsQuery, membersQuery, profilesQuery, projectsQuery, tasksQuery, useLookup } from "@/lib/queries";
import { TASK_STATUSES, dueState, fmtDateTime } from "@/lib/format";
import { PageHeader, StatCard, Window } from "@/components/app/bits";
import { ActivityList } from "@/components/app/activity-list";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({ meta: [{ title: "Admin Overview — Beyond GHC" }, { name: "description", content: "Organization-wide analytics and quick actions." }, { property: "og:title", content: "Admin Overview — Beyond GHC" }, { property: "og:description", content: "Organization-wide analytics and quick actions." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: AdminOverview,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const STATUS_COLORS: Record<string, string> = { incomplete: "var(--slate)", in_progress: "var(--dusty)", revised: "var(--highlight)", completed: "var(--sage)" };

function AdminOverview() {
  const profiles = useQuery(profilesQuery).data ?? [];
  const members = useQuery(membersQuery).data ?? [];
  const tasks = useQuery(tasksQuery).data ?? [];
  const projects = useQuery(projectsQuery).data ?? [];
  const events = useQuery(eventsQuery).data ?? [];
  const { teams } = useLookup();
  const subs = useQuery({
    queryKey: ["submissions", "summary"],
    queryFn: async () => (await supabase.from("interest_submissions").select("id, status, volunteer_interest, speaker_interest, created_at")).data ?? [],
  }).data ?? [];

  const active = profiles.filter((p) => p.status === "active");
  const pendingAccounts = profiles.filter((p) => p.status === "pending");
  const newSubs = subs.filter((s) => s.status === "new" || s.status === "reviewing");
  const done = tasks.filter((t) => t.status === "completed").length;
  const overdue = tasks.filter((t) => dueState(t.due_date, t.status) === "overdue");
  const review = tasks.filter((t) => t.awaiting_review && t.status !== "completed");

  const byTeam = teams.filter((t) => !t.archived).map((t) => ({
    name: t.name.split(" ")[0] ?? t.name,
    full: t.name,
    members: members.filter((m) => m.team_id === t.id).length,
    open: tasks.filter((x) => x.team_id === t.id && x.status !== "completed").length,
    done: tasks.filter((x) => x.team_id === t.id && x.status === "completed").length,
  }));
  const statusData = TASK_STATUSES.map((s) => ({ name: s.label, key: s.value, value: tasks.filter((t) => t.status === s.value).length })).filter((d) => d.value);
  const pipeline = [
    { name: "New", value: subs.filter((s) => s.status === "new").length },
    { name: "Reviewing", value: subs.filter((s) => s.status === "reviewing").length },
    { name: "Approved", value: subs.filter((s) => s.status === "approved").length },
    { name: "Account created", value: subs.filter((s) => s.status === "converted").length },
    { name: "Rejected/archived", value: subs.filter((s) => s.status === "rejected" || s.status === "archived").length },
  ];
  const upcomingEvents = events.filter((e) => new Date(e.starts_at) > new Date()).slice(0, 5);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Administration"
        title="Admin overview"
        description="Organization-wide health at a glance."
        actions={
          <>
            <Button asChild variant="outline"><Link to="/admin/members"><UserPlus /> Invite volunteer</Link></Button>
            <Button asChild><Link to="/admin/submissions"><Inbox /> Review submissions</Link></Button>
          </>
        }
      />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Active volunteers" value={active.length} icon={<Users />} tone="dusty" to="/admin/members" />
        <StatCard label="Submissions to review" value={newSubs.length} hint={`${subs.length} people in the database`} icon={<Inbox />} tone="lavender" to="/admin/submissions" />
        <StatCard label="Pending accounts" value={pendingAccounts.length} icon={<UserCheck />} tone="amber" to="/admin/members" />
        <StatCard label="Active projects" value={projects.filter((p) => p.status === "active").length} icon={<FolderKanban />} tone="plum" to="/projects" />
        <StatCard label="Overall completion" value={`${tasks.length ? Math.round((done / tasks.length) * 100) : 0}%`} hint={`${done}/${tasks.length} tasks`} icon={<CheckCircle2 />} tone="sage" />
        <StatCard label="Overdue tasks" value={overdue.length} icon={<AlertTriangle />} tone={overdue.length ? "danger" : "slate"} to="/tasks" />
        <StatCard label="Awaiting review" value={review.length} icon={<Activity />} tone="lavender" to="/tasks" />
        <StatCard label="Potential speakers" value={subs.filter((s) => s.speaker_interest).length} hint={`${subs.filter((s) => s.volunteer_interest).length} potential volunteers`} icon={<Mic />} tone="amber" to="/admin/submissions" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Window title="Volunteers & tasks by team">
          {byTeam.length ? (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={byTeam}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip labelFormatter={(_, p) => (p?.[0]?.payload as { full?: string })?.full ?? ""} />
                  <Bar dataKey="members" name="Members" fill="var(--chart-1)" />
                  <Bar dataKey="open" name="Open tasks" fill="var(--chart-3)" />
                  <Bar dataKey="done" name="Completed tasks" fill="var(--chart-2)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <p className="text-sm text-muted-foreground">No teams yet.</p>}
        </Window>
        <Window title="Task status distribution">
          {statusData.length ? (
            <div className="flex h-64 items-center gap-4">
              <ResponsiveContainer width="60%" height="100%">
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} stroke="var(--card)">
                    {statusData.map((d) => <Cell key={d.key} fill={STATUS_COLORS[d.key] ?? "var(--chart-1)"} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <ul className="space-y-1 text-sm">{statusData.map((d) => <li key={d.key} className="flex items-center gap-2"><span className="size-2.5 rounded-sm" style={{ background: STATUS_COLORS[d.key] }} />{d.name}: <span className="font-mono">{d.value}</span></li>)}</ul>
            </div>
          ) : <p className="text-sm text-muted-foreground">No tasks yet. Create a project or assign a task to get started.</p>}
        </Window>
        <Window title="Interest form pipeline">
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pipeline} layout="vertical" margin={{ left: 30 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={110} />
                <Tooltip />
                <Bar dataKey="value" name="People">{pipeline.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Window>
        <Window title="Upcoming events" icon={<CalendarDays />} actions={<Link to="/calendar" className="text-xs text-primary hover:underline">Calendar</Link>}>
          {upcomingEvents.length ? (
            <ul className="space-y-2 text-sm">{upcomingEvents.map((e) => <li key={e.id} className="flex justify-between gap-2"><span className="truncate">{e.title}</span><span className="shrink-0 font-mono text-xs text-muted-foreground">{fmtDateTime(e.starts_at)}</span></li>)}</ul>
          ) : <p className="text-sm text-muted-foreground">No upcoming events. Add one from the calendar.</p>}
        </Window>
      </div>
      <Window title="Recent platform activity" actions={<Link to="/admin/activity" className="text-xs text-primary hover:underline">Full log</Link>}>
        <ActivityList limit={12} />
      </Window>
    </div>
  );
}
