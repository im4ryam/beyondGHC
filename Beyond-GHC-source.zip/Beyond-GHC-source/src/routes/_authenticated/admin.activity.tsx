import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useLookup, useMe } from "@/lib/queries";
import { fmtDateTime } from "@/lib/format";
import { downloadCsv } from "@/lib/csv";
import { LoadingBlock, PageHeader } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/admin/activity")({
  head: () => ({ meta: [{ title: "Activity Log — Admin — Beyond GHC" }, { name: "description", content: "Audit log of platform changes." }, { property: "og:title", content: "Activity Log — Admin — Beyond GHC" }, { property: "og:description", content: "Audit log of platform changes." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ActivityPage,
});

function ActivityPage() {
  const me = useMe();
  const { profileById, teamById } = useLookup();
  const [type, setType] = useState("all");
  const [search, setSearch] = useState("");
  const [limit, setLimit] = useState(100);
  const q = useQuery({
    queryKey: ["activity", "admin", type, limit],
    queryFn: async () => {
      let qq = supabase.from("activity_log").select("*").order("created_at", { ascending: false }).limit(limit);
      if (type !== "all") qq = qq.eq("entity_type", type);
      const { data, error } = await qq;
      if (error) throw error;
      return data;
    },
  });
  const term = search.trim().toLowerCase();
  const rows = (q.data ?? []).filter((a) => !term || a.summary.toLowerCase().includes(term) || profileById.get(a.actor_id ?? "")?.full_name.toLowerCase().includes(term));

  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Admin", to: "/admin" }, { label: "Activity Log" }]}
        title="Activity log"
        description="Who changed what, and when. Includes account approvals, role changes, task updates and imports."
        actions={<Button variant="outline" onClick={() => downloadCsv("activity-log.csv", rows.map((a) => ({ when: a.created_at, who: profileById.get(a.actor_id ?? "")?.full_name ?? "System", type: a.entity_type, action: a.action, summary: a.summary, team: a.team_id ? teamById.get(a.team_id)?.name : "" })))}><Download /> Export</Button>}
      />
      <div className="panel mb-4 grid gap-2 p-3 sm:grid-cols-[1fr_200px]">
        <Input placeholder="Search activity" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search activity" />
        <Select value={type} onValueChange={setType}>
          <SelectTrigger aria-label="Type"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            {["task", "project", "team", "user", "announcement", "submission", "integration"].map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {q.isLoading ? <LoadingBlock rows={8} /> : (
        <div className="panel overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>When</TableHead><TableHead>Who</TableHead><TableHead>What</TableHead><TableHead className="hidden md:table-cell">Team</TableHead></TableRow></TableHeader>
            <TableBody>
              {rows.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="whitespace-nowrap font-mono text-xs">{fmtDateTime(a.created_at, me.profile.timezone)}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{profileById.get(a.actor_id ?? "")?.full_name ?? "System"}</TableCell>
                  <TableCell className="text-sm"><span className="mr-2 rounded-sm bg-muted px-1.5 py-0.5 font-mono text-[10px] uppercase">{a.entity_type}</span>{a.summary}</TableCell>
                  <TableCell className="hidden text-xs md:table-cell">{a.team_id ? teamById.get(a.team_id)?.name : "—"}</TableCell>
                </TableRow>
              ))}
              {rows.length === 0 && <TableRow><TableCell colSpan={4} className="py-8 text-center text-sm text-muted-foreground">No activity found.</TableCell></TableRow>}
            </TableBody>
          </Table>
          {(q.data?.length ?? 0) >= limit && <div className="border-t p-2 text-center"><Button variant="outline" size="sm" onClick={() => setLimit(limit + 200)}>Load more</Button></div>}
        </div>
      )}
    </div>
  );
}
