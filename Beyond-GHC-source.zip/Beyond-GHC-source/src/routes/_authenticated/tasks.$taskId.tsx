import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CheckCircle2, CornerDownRight, MessageSquare, Pencil, RotateCcw, Send, Trash2, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { canManageTeam, tasksQuery, useLookup, useMe, type Task } from "@/lib/queries";
import { TASK_STATUSES, errMsg, fmtDateTime, fmtRelative, type TaskStatus } from "@/lib/format";
import {
  ConfirmAction,
  DueLabel,
  EmptyState,
  ExternalResourceLink,
  LoadingBlock,
  PageHeader,
  PriorityBadge,
  TaskStatusBadge,
  TeamBadge,
  UserAvatar,
  Window,
} from "@/components/app/bits";
import { TaskFormDialog } from "@/components/app/task-form";
import { ActivityList } from "@/components/app/activity-list";

export const Route = createFileRoute("/_authenticated/tasks/$taskId")({
  head: () => ({ meta: [{ title: "Task — Beyond GHC" }, { name: "description", content: "Task details, comments and history." }, { property: "og:title", content: "Task — Beyond GHC" }, { property: "og:description", content: "Task details, comments and history." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: TaskPage,
});

function TaskPage() {
  const { taskId } = Route.useParams();
  const q = useQuery(tasksQuery);
  const task = q.data?.find((t) => t.id === taskId);
  if (q.isLoading) return <LoadingBlock rows={4} />;
  if (!task)
    return <EmptyState title="Task not found" description="It may have been deleted, or it belongs to a team you're not on." action={<Button asChild variant="outline"><Link to="/tasks">Back to my tasks</Link></Button>} />;
  return <TaskDetail task={task} />;
}

function TaskDetail({ task }: { task: Task }) {
  const me = useMe();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { teamById, projectById, profileById } = useLookup();
  const manager = canManageTeam(me, task.team_id);
  const isAssignee = task.assignee_id === me.id;
  const [editOpen, setEditOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [busy, setBusy] = useState(false);
  const tz = me.profile.timezone;
  const links = Array.isArray(task.resource_links) ? (task.resource_links as { title: string; url: string }[]) : [];
  const assignee = task.assignee_id ? profileById.get(task.assignee_id) : null;
  const project = task.project_id ? projectById.get(task.project_id) : null;

  async function update(patch: Partial<Task>, msg: string) {
    setBusy(true);
    const { error } = await supabase.from("tasks").update(patch).eq("id", task.id);
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(msg);
    qc.invalidateQueries({ queryKey: ["tasks"] });
    qc.invalidateQueries({ queryKey: ["activity"] });
  }

  async function remove() {
    const { error } = await supabase.from("tasks").delete().eq("id", task.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Task deleted");
    qc.invalidateQueries({ queryKey: ["tasks"] });
    navigate({ to: "/tasks" });
  }

  const statusOptions = manager ? TASK_STATUSES : TASK_STATUSES.filter((s) => s.value !== "completed");

  return (
    <div>
      <PageHeader
        crumbs={[
          { label: "My Tasks", to: "/tasks" },
          ...(project ? [{ label: project.title, to: "/projects/$projectId", params: { projectId: project.id } }] : []),
          { label: task.title },
        ]}
        title={task.title}
        actions={
          manager && (
            <>
              <Button variant="outline" onClick={() => setEditOpen(true)}><Pencil /> Edit</Button>
              <ConfirmAction
                trigger={<Button variant="ghost" aria-label="Delete task"><Trash2 /></Button>}
                title="Delete this task?"
                description="The task, its comments and its history will be removed permanently. Consider marking it completed instead."
                confirmLabel="Delete task"
                destructive
                onConfirm={remove}
              />
            </>
          )
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {task.awaiting_review && task.status !== "completed" && (
            <div className="flex flex-col gap-3 rounded-md border border-lavender/40 bg-lavender-soft p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-sm text-lavender"><strong>Submitted for review.</strong> {manager ? "Approve it or request changes." : "Your team lead will review it."}</div>
              {manager && (
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => { setFeedback(task.feedback ?? ""); setFeedbackOpen(true); }}><RotateCcw /> Request changes</Button>
                  <Button size="sm" variant="success" disabled={busy} onClick={() => update({ status: "completed" }, "Task approved and completed")}><CheckCircle2 /> Approve</Button>
                </div>
              )}
            </div>
          )}

          {task.feedback && (
            <div className="rounded-md border border-amber/40 bg-amber-soft p-4">
              <div className="eyebrow text-amber">Feedback from team lead</div>
              <p className="mt-1 whitespace-pre-wrap text-sm text-foreground">{task.feedback}</p>
            </div>
          )}

          <Window title="Details">
            <div className="space-y-5">
              <div>
                <div className="eyebrow mb-1 text-muted-foreground">Description</div>
                <p className="whitespace-pre-wrap text-sm">{task.description || <span className="text-muted-foreground">No description.</span>}</p>
              </div>
              <div>
                <div className="eyebrow mb-1 text-muted-foreground">Instructions</div>
                <p className="whitespace-pre-wrap text-sm">{task.instructions || <span className="text-muted-foreground">No instructions.</span>}</p>
              </div>
              <div>
                <div className="eyebrow mb-1 text-muted-foreground">Related resources</div>
                {links.length ? (
                  <ul className="space-y-1">{links.map((l, i) => <li key={i}><ExternalResourceLink url={l.url} title={l.title} /></li>)}</ul>
                ) : (
                  <p className="text-sm text-muted-foreground">None linked.</p>
                )}
                {links.length > 0 && <p className="mt-1 text-xs text-muted-foreground">Shared documents may need separate access from their owner.</p>}
              </div>
            </div>
          </Window>

          <Comments task={task} />

          <Window title="Task history">
            <ActivityList entityType="task" entityId={task.id} />
          </Window>
        </div>

        <div className="space-y-6">
          <Window title="Status">
            <div className="space-y-3">
              <TaskStatusBadge status={task.status} awaitingReview={task.awaiting_review} />
              {(isAssignee || manager) ? (
                <>
                  <Select value={task.status} onValueChange={(v) => update({ status: v as TaskStatus, ...(v === "completed" ? {} : {}) }, "Status updated")} disabled={busy}>
                    <SelectTrigger aria-label="Change status"><SelectValue /></SelectTrigger>
                    <SelectContent>{statusOptions.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
                  </Select>
                  {isAssignee && task.status !== "completed" && !task.awaiting_review && (
                    <Button className="w-full" variant="highlight" disabled={busy} onClick={() => update({ awaiting_review: true, status: task.status === "incomplete" ? "in_progress" : task.status }, "Submitted for review")}>
                      <Send /> Submit for review
                    </Button>
                  )}
                  {isAssignee && task.awaiting_review && task.status !== "completed" && (
                    <Button className="w-full" variant="outline" disabled={busy} onClick={() => update({ awaiting_review: false }, "Review request withdrawn")}>
                      <Undo2 /> Withdraw from review
                    </Button>
                  )}
                  {manager && task.status !== "completed" && !task.awaiting_review && (
                    <Button className="w-full" variant="success" disabled={busy} onClick={() => update({ status: "completed" }, "Marked completed")}>
                      <CheckCircle2 /> Mark completed
                    </Button>
                  )}
                  {manager && (
                    <Button className="w-full" variant="outline" onClick={() => { setFeedback(task.feedback ?? ""); setFeedbackOpen(true); }}>
                      <MessageSquare /> {task.feedback ? "Edit feedback" : "Give feedback"}
                    </Button>
                  )}
                  {!manager && <p className="text-xs text-muted-foreground">Only a team lead or administrator can mark a task Completed.</p>}
                </>
              ) : (
                <p className="text-xs text-muted-foreground">Only the assigned volunteer or a team lead can change this task.</p>
              )}
            </div>
          </Window>

          <Window title="Info">
            <dl className="space-y-3 text-sm">
              <Row label="Assigned to">
                {assignee ? (
                  <span className="flex items-center gap-2"><UserAvatar name={assignee.full_name} url={assignee.avatar_url} size="sm" />{assignee.id === me.id ? "You" : assignee.full_name}</span>
                ) : "Unassigned"}
              </Row>
              <Row label="Team"><Link to="/teams/$teamId" params={{ teamId: task.team_id }}><TeamBadge team={teamById.get(task.team_id)} /></Link></Row>
              <Row label="Project">{project ? <Link to="/projects/$projectId" params={{ projectId: project.id }} className="text-primary hover:underline">{project.title}</Link> : "Individual task"}</Row>
              <Row label="Due"><DueLabel due={task.due_date} status={task.status} tz={tz} /></Row>
              <Row label="Priority"><PriorityBadge priority={task.priority} /></Row>
              <Row label="Created">{fmtDateTime(task.created_at, tz)}{task.created_by && <span className="block text-xs text-muted-foreground">by {profileById.get(task.created_by)?.full_name ?? "—"}</span>}</Row>
              <Row label="Last updated">{fmtRelative(task.updated_at)}</Row>
              {task.completed_at && <Row label="Completed">{fmtDateTime(task.completed_at, tz)}</Row>}
            </dl>
          </Window>
        </div>
      </div>

      <TaskFormDialog open={editOpen} onOpenChange={setEditOpen} task={task} />
      <Dialog open={feedbackOpen} onOpenChange={setFeedbackOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Feedback for the volunteer</DialogTitle>
            <DialogDescription>Requesting changes moves the task to “Revised” and notifies the assignee.</DialogDescription>
          </DialogHeader>
          <Textarea rows={5} value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder="What should be changed or improved?" />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setFeedbackOpen(false)}>Cancel</Button>
            <Button variant="outline" onClick={async () => { await update({ feedback: feedback.trim() || null }, "Feedback saved"); setFeedbackOpen(false); }}>Save feedback only</Button>
            <Button onClick={async () => { if (!feedback.trim()) { toast.error("Write some feedback first"); return; } await update({ feedback: feedback.trim(), status: "revised", awaiting_review: false }, "Changes requested"); setFeedbackOpen(false); }}>
              Request changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[100px_1fr] items-start gap-2">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="min-w-0">{children}</dd>
    </div>
  );
}

const KIND_LABEL: Record<string, { label: string; variant: "slate" | "dusty" | "amber" | "lavender" }> = {
  comment: { label: "Comment", variant: "slate" },
  update: { label: "Progress update", variant: "dusty" },
  question: { label: "Question", variant: "amber" },
  feedback: { label: "Feedback", variant: "lavender" },
};

function Comments({ task }: { task: Task }) {
  const me = useMe();
  const qc = useQueryClient();
  const { profileById } = useLookup();
  const [body, setBody] = useState("");
  const [kind, setKind] = useState("update");
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyBody, setReplyBody] = useState("");
  const { data = [], isLoading } = useQuery({
    queryKey: ["comments", task.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("task_comments").select("*").eq("task_id", task.id).order("created_at");
      if (error) throw error;
      return data;
    },
  });

  async function post(text: string, k: string, parent: string | null) {
    if (!text.trim()) return;
    const { error } = await supabase.from("task_comments").insert({ task_id: task.id, author_id: me.id, body: text.trim(), kind: k, parent_id: parent });
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["comments", task.id] });
    qc.invalidateQueries({ queryKey: ["activity"] });
    return true;
  }
  async function del(id: string) {
    const { error } = await supabase.from("task_comments").delete().eq("id", id);
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["comments", task.id] });
  }

  const top = data.filter((c) => !c.parent_id);
  const replies = (id: string) => data.filter((c) => c.parent_id === id);

  return (
    <Window title={`Comments & updates (${data.length})`} icon={<MessageSquare />}>
      {isLoading ? (
        <LoadingBlock rows={2} />
      ) : top.length === 0 ? (
        <p className="mb-4 text-sm text-muted-foreground">No comments yet. Post a progress update or ask a question.</p>
      ) : (
        <ul className="mb-5 space-y-4">
          {top.map((c) => {
            const author = profileById.get(c.author_id);
            const k = KIND_LABEL[c.kind] ?? { label: "Comment", variant: "slate" as const };
            return (
              <li key={c.id}>
                <div className="flex gap-3">
                  <UserAvatar name={author?.full_name} url={author?.avatar_url} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-sm">
                      <span className="font-medium">{author?.full_name ?? "Former member"}</span>
                      <Badge variant={k.variant}>{k.label}</Badge>
                      <span className="font-mono text-[11px] text-muted-foreground">{fmtDateTime(c.created_at, me.profile.timezone)}</span>
                    </div>
                    <p className="mt-1 whitespace-pre-wrap text-sm">{c.body}</p>
                    <div className="mt-1 flex gap-3 text-xs">
                      <button className="text-primary hover:underline" onClick={() => { setReplyTo(replyTo === c.id ? null : c.id); setReplyBody(""); }}>Reply</button>
                      {(c.author_id === me.id || me.isAdmin) && <button className="text-muted-foreground hover:text-destructive" onClick={() => del(c.id)}>Delete</button>}
                    </div>
                    {replies(c.id).map((r) => {
                      const ra = profileById.get(r.author_id);
                      return (
                        <div key={r.id} className="mt-3 flex gap-2 border-l-2 pl-3">
                          <CornerDownRight className="mt-1 size-3.5 shrink-0 text-muted-foreground" />
                          <div className="min-w-0">
                            <div className="text-sm"><span className="font-medium">{ra?.full_name ?? "Former member"}</span> <span className="font-mono text-[11px] text-muted-foreground">{fmtRelative(r.created_at)}</span></div>
                            <p className="whitespace-pre-wrap text-sm">{r.body}</p>
                            {(r.author_id === me.id || me.isAdmin) && <button className="text-xs text-muted-foreground hover:text-destructive" onClick={() => del(r.id)}>Delete</button>}
                          </div>
                        </div>
                      );
                    })}
                    {replyTo === c.id && (
                      <form className="mt-2 flex gap-2" onSubmit={async (e) => { e.preventDefault(); if (await post(replyBody, "comment", c.id)) { setReplyTo(null); setReplyBody(""); } }}>
                        <Textarea rows={2} value={replyBody} onChange={(e) => setReplyBody(e.target.value)} placeholder="Write a reply…" aria-label="Reply" />
                        <Button type="submit" size="sm">Reply</Button>
                      </form>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <form className="space-y-2 border-t pt-4" onSubmit={async (e) => { e.preventDefault(); if (await post(body, kind, null)) setBody(""); }}>
        <Textarea rows={3} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Share progress, a note, or a question…" aria-label="New comment" maxLength={5000} />
        <div className="flex items-center justify-between gap-2">
          <Select value={kind} onValueChange={setKind}>
            <SelectTrigger className="w-44" aria-label="Comment type"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="update">Progress update</SelectItem>
              <SelectItem value="comment">Comment</SelectItem>
              <SelectItem value="question">Question</SelectItem>
            </SelectContent>
          </Select>
          <Button type="submit" disabled={!body.trim()}><Send /> Post</Button>
        </div>
      </form>
    </Window>
  );
}
