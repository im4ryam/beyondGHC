import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Database, Download, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useMe } from "@/lib/queries";
import { SPEAKER_STATUSES, errMsg } from "@/lib/format";
import { downloadCsv } from "@/lib/csv";
import { EmptyState, LoadingBlock, NoAccess, PageHeader } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/member-data")({
  head: () => ({ meta: [{ title: "Member Data — Beyond GHC" }, { name: "description", content: "Member information your team has been granted." }, { property: "og:title", content: "Member Data — Beyond GHC" }, { property: "og:description", content: "Member information your team has been granted." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: MemberDataPage,
});

const LABELS: Record<string, string> = {
  speaker_pipeline: "Speaker pipeline",
  volunteer_pipeline: "Volunteer pipeline",
  member_contacts: "Member contacts",
  public_member_info: "Approved public info",
};

function MemberDataPage() {
  const me = useMe();
  const qc = useQueryClient();
  const granted = Array.from(new Set(me.datasets.map((d) => d.dataset)));
  if (me.isAdmin) granted.push(...Object.keys(LABELS).filter((k) => !granted.includes(k)));
  const [tab, setTab] = useState(granted[0] ?? "");
  const [search, setSearch] = useState("");

  const subs = useQuery({
    queryKey: ["submissions", "granted"],
    queryFn: async () => (await supabase.from("interest_submissions").select("id, full_name, email, linkedin_url, timezone, availability, background, topics, volunteer_interest, volunteer_areas, preferred_team, speaker_interest, proposed_topics, speaker_status, community_spaces, status")).data ?? [],
    enabled: granted.some((g) => g !== "public_member_info"),
  });
  const pub = useQuery({
    queryKey: ["public_member_info"],
    queryFn: async () => (await supabase.rpc("public_member_info")).data ?? [],
    enabled: granted.includes("public_member_info"),
  });

  const rows = useMemo(() => {
    const term = search.trim().toLowerCase();
    const base = tab === "public_member_info"
      ? (pub.data ?? []).map((r) => ({ ...r, email: undefined as string | undefined }))
      : (subs.data ?? []).filter((s) => (tab === "speaker_pipeline" ? s.speaker_interest : tab === "volunteer_pipeline" ? s.volunteer_interest : true));
    return base.filter((r) => !term || JSON.stringify(r).toLowerCase().includes(term));
  }, [tab, subs.data, pub.data, search]);

  if (!granted.length) return <NoAccess message="Your team hasn't been granted access to any member data." />;

  async function setSpeaker(id: string, v: string) {
    const { error } = await supabase.from("interest_submissions").update({ speaker_status: v }).eq("id", id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Speaker status updated");
    qc.invalidateQueries({ queryKey: ["submissions"] });
  }

  return (
    <div>
      <PageHeader eyebrow="Restricted" title="Member data" description="Information your team has been given access to for its responsibilities. Please don't share it outside the team." actions={<Button variant="outline" onClick={() => downloadCsv(`${tab}.csv`, rows as Record<string, unknown>[])}><Download /> Export</Button>} />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <Tabs value={tab} onValueChange={setTab}><TabsList className="h-auto flex-wrap">{granted.map((g) => <TabsTrigger key={g} value={g}>{LABELS[g] ?? g}</TabsTrigger>)}</TabsList></Tabs>
        <div className="relative flex-1"><Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input className="pl-8" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search" aria-label="Search" /></div>
      </div>
      {subs.isLoading || pub.isLoading ? <LoadingBlock /> : rows.length === 0 ? (
        <EmptyState icon={<Database />} title="No records" description={tab === "public_member_info" ? "Admins haven't approved any member profiles for public use yet." : "Nothing matches."} />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((r) => {
            const s = r as Record<string, unknown>;
            return (
              <article key={String(s["id"])} className="panel space-y-1.5 p-4 text-sm">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-semibold">{String(s["full_name"] ?? "")}</div>
                  <div className="flex gap-1">{Boolean(s["speaker_interest"]) && <Badge variant="amber">Speaker</Badge>}{Boolean(s["volunteer_interest"]) && <Badge variant="dusty">Volunteer</Badge>}</div>
                </div>
                {s["email"] ? <a href={`mailto:${String(s["email"])}`} className="block text-xs text-primary hover:underline">{String(s["email"])}</a> : null}
                {s["linkedin_url"] ? <a href={String(s["linkedin_url"])} target="_blank" rel="noopener noreferrer" className="block text-xs text-primary hover:underline">LinkedIn</a> : null}
                {(["public_bio", "background", "timezone", "availability", "topics", "proposed_topics", "volunteer_areas", "preferred_team", "community_spaces"] as const).map((k) => s[k] ? <p key={k} className="text-xs"><span className="text-muted-foreground">{k.replace(/_/g, " ")}: </span>{String(s[k])}</p> : null)}
                {tab === "speaker_pipeline" && (
                  <Select value={String(s["speaker_status"] ?? "not_contacted")} onValueChange={(v) => setSpeaker(String(s["id"]), v)}>
                    <SelectTrigger className="mt-2 h-8 text-xs" aria-label="Speaker status"><SelectValue /></SelectTrigger>
                    <SelectContent>{SPEAKER_STATUSES.map((x) => <SelectItem key={x.value} value={x.value}>{x.label}</SelectItem>)}</SelectContent>
                  </Select>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
