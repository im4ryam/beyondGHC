import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Download, FileSpreadsheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { downloadCsv } from "@/lib/csv";
import { errMsg } from "@/lib/format";
import { PageHeader } from "@/components/app/bits";

export const Route = createFileRoute("/_authenticated/admin/export")({
  head: () => ({ meta: [{ title: "Export Data — Admin — Beyond GHC" }, { name: "description", content: "Download CSV exports." }, { property: "og:title", content: "Export Data — Admin — Beyond GHC" }, { property: "og:description", content: "Download CSV exports." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ExportPage,
});

async function all<T>(p: PromiseLike<{ data: T[] | null; error: unknown }>) {
  const { data, error } = await p;
  if (error) throw error;
  return data ?? [];
}

async function base() {
  const [profiles, priv, teams, members] = await Promise.all([
    all(supabase.from("profiles").select("*")),
    all(supabase.from("profile_private").select("user_id, email, phone")),
    all(supabase.from("teams").select("*")),
    all(supabase.from("team_members").select("*")),
  ]);
  const name = (id: string | null) => profiles.find((p) => p.id === id)?.full_name ?? "";
  const team = (id: string | null) => teams.find((t) => t.id === id)?.name ?? "";
  return { profiles, priv, teams, members, name, team };
}

const EXPORTS: { key: string; title: string; desc: string; run: () => Promise<[string, Record<string, unknown>[]]> }[] = [
  {
    key: "directory",
    title: "Volunteer directory",
    desc: "Everyone with an account: contact info, time zone, availability, status.",
    run: async () => {
      const b = await base();
      return ["volunteer-directory", b.profiles.map((p) => {
        const pv = b.priv.find((x) => x.user_id === p.id);
        return { name: p.full_name, email: pv?.email, phone: pv?.phone, linkedin: p.linkedin_url, timezone: p.timezone, availability: p.availability, hours_per_month: p.monthly_hours, status: p.status, joined: p.joined_at, teams: b.members.filter((m) => m.user_id === p.id).map((m) => b.team(m.team_id) + (m.is_lead ? " (lead)" : "")).join("; ") };
      })];
    },
  },
  {
    key: "membership",
    title: "Team membership",
    desc: "One row per person per team, with lead flag.",
    run: async () => {
      const b = await base();
      return ["team-membership", b.members.map((m) => ({ team: b.team(m.team_id), member: b.name(m.user_id), is_lead: m.is_lead, since: m.created_at }))];
    },
  },
  {
    key: "tasks",
    title: "Task assignments",
    desc: "Every task with assignee, team, project, status, priority and dates.",
    run: async () => {
      const b = await base();
      const [tasks, projects] = await Promise.all([all(supabase.from("tasks").select("*")), all(supabase.from("projects").select("id, title"))]);
      return ["task-assignments", tasks.map((t) => ({ title: t.title, team: b.team(t.team_id), project: projects.find((p) => p.id === t.project_id)?.title ?? "", assignee: b.name(t.assignee_id), status: t.status, awaiting_review: t.awaiting_review, priority: t.priority, due: t.due_date, created: t.created_at, updated: t.updated_at, completed: t.completed_at }))];
    },
  },
  {
    key: "projects",
    title: "Project progress",
    desc: "Each project with item counts and completion percentage.",
    run: async () => {
      const b = await base();
      const [projects, tasks] = await Promise.all([all(supabase.from("projects").select("*")), all(supabase.from("tasks").select("project_id, status"))]);
      return ["project-progress", projects.map((p) => {
        const items = tasks.filter((t) => t.project_id === p.id);
        const done = items.filter((t) => t.status === "completed").length;
        return { project: p.title, team: b.team(p.team_id), status: p.status, priority: p.priority, target: p.due_date, items: items.length, completed_items: done, percent: items.length ? Math.round((done / items.length) * 100) : 0, completed_at: p.completed_at };
      })];
    },
  },
  {
    key: "submissions",
    title: "Interest form submissions",
    desc: "The full member database from the interest form.",
    run: async () => {
      const rows = await all(supabase.from("interest_submissions").select("*"));
      return ["interest-submissions", rows.map(({ history: _h, ...r }) => r)];
    },
  },
  {
    key: "speakers",
    title: "Speaker pipeline",
    desc: "Potential speakers, proposed topics and pipeline status.",
    run: async () => {
      const rows = await all(supabase.from("interest_submissions").select("full_name, email, linkedin_url, background, proposed_topics, topics, speaker_status, admin_notes, submitted_at").eq("speaker_interest", true));
      return ["speaker-pipeline", rows];
    },
  },
  {
    key: "participation",
    title: "Participation & volunteer pipeline",
    desc: "Volunteer candidates, preferred areas, availability and review status.",
    run: async () => {
      const rows = await all(supabase.from("interest_submissions").select("full_name, email, timezone, participation, volunteer_areas, preferred_team, volunteer_experience, availability, status, submitted_at").eq("volunteer_interest", true));
      return ["volunteer-pipeline", rows];
    },
  },
];

function ExportPage() {
  const [busy, setBusy] = useState<string | null>(null);
  async function go(e: (typeof EXPORTS)[number]) {
    setBusy(e.key);
    try {
      const [name, rows] = await e.run();
      if (!rows.length) toast.info("Nothing to export yet");
      else downloadCsv(`${name}-${new Date().toISOString().slice(0, 10)}.csv`, rows);
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(null);
    }
  }
  return (
    <div>
      <PageHeader crumbs={[{ label: "Admin", to: "/admin" }, { label: "Export Data" }]} title="Export data" description="CSV files open in Excel and Google Sheets. Exports include personal information — store them carefully." />
      <div className="grid gap-4 md:grid-cols-2">
        {EXPORTS.map((e) => (
          <div key={e.key} className="panel flex items-start gap-3 p-4">
            <div className="grid size-9 shrink-0 place-items-center rounded-sm border border-border-strong bg-secondary text-secondary-foreground"><FileSpreadsheet className="size-4" /></div>
            <div className="min-w-0 flex-1">
              <h2 className="font-semibold">{e.title}</h2>
              <p className="text-sm text-muted-foreground">{e.desc}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => go(e)} disabled={busy === e.key}><Download /> {busy === e.key ? "…" : "CSV"}</Button>
          </div>
        ))}
      </div>
    </div>
  );
}
