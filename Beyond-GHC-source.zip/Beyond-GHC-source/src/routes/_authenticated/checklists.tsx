import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Circle, CircleDot, ListChecks, RotateCcw } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { projectsQuery, tasksQuery, useLookup, useMe } from "@/lib/queries";
import { dueState, fmtDate, projectProgress, type TaskStatus } from "@/lib/format";
import { EmptyState, LoadingBlock, PageHeader, ProgressBar, ProjectStatusBadge, TeamBadge } from "@/components/app/bits";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/checklists")({
  head: () => ({ meta: [{ title: "Team Checklists — Beyond GHC" }, { name: "description", content: "Shared team checklists and who is responsible." }, { property: "og:title", content: "Team Checklists — Beyond GHC" }, { property: "og:description", content: "Shared team checklists and who is responsible." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ChecklistsPage,
});

const ICON: Record<TaskStatus, React.ReactNode> = {
  incomplete: <Circle className="size-4 text-slate" />,
  in_progress: <CircleDot className="size-4 text-dusty" />,
  revised: <RotateCcw className="size-4 text-amber" />,
  completed: <CheckCircle2 className="size-4 text-sage" />,
};

function ChecklistsPage() {
  const me = useMe();
  const pq = useQuery(projectsQuery);
  const tasks = useQuery(tasksQuery).data ?? [];
  const { teams, profileById } = useLookup();
  const myTeams = teams.filter((t) => !t.archived && (me.isAdmin || me.teamIds.includes(t.id)));
  const [teamId, setTeamId] = useState<string>("");
  const active = teamId || myTeams[0]?.id || "";
  const projects = (pq.data ?? []).filter((p) => p.team_id === active && p.status !== "archived");

  return (
    <div>
      <PageHeader eyebrow="Shared" title="Team checklists" description="Every project's checklist at a glance — who's responsible and where each item stands. Click an item to update it." />
      {myTeams.length === 0 ? (
        <EmptyState icon={<ListChecks />} title="You're not on a team yet" description="Once an administrator adds you to a team, its checklists show up here." />
      ) : (
        <>
          <Tabs value={active} onValueChange={setTeamId} className="mb-5">
            <TabsList className="h-auto flex-wrap">
              {myTeams.map((t) => <TabsTrigger key={t.id} value={t.id}>{t.name}</TabsTrigger>)}
            </TabsList>
          </Tabs>
          {pq.isLoading ? (
            <LoadingBlock />
          ) : projects.length === 0 ? (
            <EmptyState icon={<ListChecks />} title="No checklists for this team" description="Team leads create projects to build a shared checklist." />
          ) : (
            <div className="grid gap-5 lg:grid-cols-2">
              {projects.map((p) => {
                const items = tasks.filter((t) => t.project_id === p.id);
                return (
                  <section key={p.id} className="window overflow-hidden">
                    <header className="titlebar flex items-center justify-between gap-2 px-3 py-2">
                      <Link to="/projects/$projectId" params={{ projectId: p.id }} className="truncate font-mono text-xs font-semibold uppercase hover:underline">{p.title}</Link>
                      <ProjectStatusBadge status={p.status} />
                    </header>
                    <div className="p-4">
                      <ProgressBar value={projectProgress(items)} />
                      {items.length === 0 ? (
                        <p className="mt-3 text-sm text-muted-foreground">No items yet.</p>
                      ) : (
                        <ul className="mt-3 divide-y">
                          {items.map((t) => {
                            const ds = dueState(t.due_date, t.status);
                            const owner = t.assignee_id ? profileById.get(t.assignee_id) : null;
                            return (
                              <li key={t.id}>
                                <Link to="/tasks/$taskId" params={{ taskId: t.id }} className={cn("flex items-center gap-2 py-2 text-sm hover:bg-muted/60", t.assignee_id === me.id && "font-medium")}>
                                  {ICON[t.status]}
                                  <span className={cn("flex-1 truncate", t.status === "completed" && "text-muted-foreground line-through")}>{t.title}</span>
                                  <span className="hidden shrink-0 text-xs text-muted-foreground sm:inline">{owner ? (owner.id === me.id ? "You" : owner.full_name) : "Unassigned"}</span>
                                  {t.due_date && <span className={cn("shrink-0 font-mono text-[11px]", ds === "overdue" ? "text-destructive" : ds === "soon" ? "text-amber" : "text-muted-foreground")}>{fmtDate(t.due_date, me.profile.timezone, { year: undefined })}</span>}
                                </Link>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    </div>
                  </section>
                );
              })}
            </div>
          )}
          <div className="mt-6 flex flex-wrap gap-3 text-xs text-muted-foreground">
            {(["incomplete", "in_progress", "revised", "completed"] as TaskStatus[]).map((s) => <span key={s} className="flex items-center gap-1">{ICON[s]} {s.replace("_", " ")}</span>)}
            <span className="ml-auto">{myTeams.find((t) => t.id === active) && <TeamBadge team={myTeams.find((t) => t.id === active)} />}</span>
          </div>
        </>
      )}
    </div>
  );
}
