import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  addDays,
  addMonths,
  addWeeks,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { CalendarDays, ChevronLeft, ChevronRight, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { canManageTeam, eventsQuery, projectsQuery, tasksQuery, useLookup, useMe, type CalEvent } from "@/lib/queries";
import { errMsg, fmtDateTime } from "@/lib/format";
import { ConfirmAction, EmptyState, PageHeader } from "@/components/app/bits";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/calendar")({
  head: () => ({ meta: [{ title: "Calendar — Beyond GHC" }, { name: "description", content: "Deadlines, meetings and events." }, { property: "og:title", content: "Calendar — Beyond GHC" }, { property: "og:description", content: "Deadlines, meetings and events." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: CalendarPage,
});

type Item = { id: string; date: Date; title: string; kind: "my_task" | "team_task" | "project" | "event" | "meeting" | "milestone" | "deadline"; onClick: () => void; event?: CalEvent };
const KIND_STYLE: Record<Item["kind"], string> = {
  my_task: "bg-highlight/20 text-amber border-highlight/40",
  team_task: "bg-slate-soft text-slate border-slate/20",
  project: "bg-lavender-soft text-lavender border-lavender/30",
  event: "bg-dusty-soft text-dusty border-dusty/30",
  meeting: "bg-sage-soft text-sage border-sage/30",
  milestone: "bg-plum-soft text-plum border-plum/30",
  deadline: "bg-danger-soft text-destructive border-destructive/30",
};
const KIND_LABEL: Record<Item["kind"], string> = { my_task: "My task", team_task: "Team task", project: "Project target", event: "Event", meeting: "Meeting", milestone: "Milestone", deadline: "Deadline" };

function CalendarPage() {
  const me = useMe();
  const navigate = useNavigate();
  const tasks = useQuery(tasksQuery).data ?? [];
  const projects = useQuery(projectsQuery).data ?? [];
  const events = useQuery(eventsQuery).data ?? [];
  const [view, setView] = useState<"month" | "week" | "agenda">("month");
  const [cursor, setCursor] = useState(new Date());
  const [showTeam, setShowTeam] = useState(false);
  const [editing, setEditing] = useState<CalEvent | "new" | null>(null);
  const [newDate, setNewDate] = useState<Date | null>(null);
  const canCreate = me.isAdmin || me.isLead;

  const items = useMemo<Item[]>(() => {
    const out: Item[] = [];
    tasks.forEach((t) => {
      if (!t.due_date || t.status === "completed") return;
      const mine = t.assignee_id === me.id;
      if (!mine && !showTeam) return;
      out.push({ id: "t" + t.id, date: new Date(t.due_date), title: t.title, kind: mine ? "my_task" : "team_task", onClick: () => navigate({ to: "/tasks/$taskId", params: { taskId: t.id } }) });
    });
    projects.forEach((p) => {
      if (!p.due_date || p.status === "completed" || p.status === "archived") return;
      out.push({ id: "p" + p.id, date: new Date(p.due_date + "T12:00:00"), title: p.title, kind: "project", onClick: () => navigate({ to: "/projects/$projectId", params: { projectId: p.id } }) });
    });
    events.forEach((e) => out.push({ id: "e" + e.id, date: new Date(e.starts_at), title: e.title, kind: e.kind, event: e, onClick: () => setEditing(e) }));
    return out.sort((a, b) => a.date.getTime() - b.date.getTime());
  }, [tasks, projects, events, showTeam, me.id, navigate]);

  const step = (dir: number) => setCursor(view === "month" ? addMonths(cursor, dir) : view === "week" ? addWeeks(cursor, dir) : addMonths(cursor, dir));
  const range =
    view === "month"
      ? { start: startOfWeek(startOfMonth(cursor)), end: endOfWeek(endOfMonth(cursor)) }
      : view === "week"
        ? { start: startOfWeek(cursor), end: endOfWeek(cursor) }
        : { start: startOfMonth(cursor), end: endOfMonth(addMonths(cursor, 2)) };
  const days: Date[] = [];
  for (let d = range.start; d <= range.end; d = addDays(d, 1)) days.push(d);
  const on = (d: Date) => items.filter((i) => isSameDay(i.date, d));

  return (
    <div>
      <PageHeader
        eyebrow="Schedule"
        title="Calendar"
        description={`Shown in your time zone (${me.profile.timezone}).`}
        actions={canCreate && <Button onClick={() => { setNewDate(new Date()); setEditing("new"); }}><Plus /> New event</Button>}
      />
      <div className="panel mb-4 flex flex-wrap items-center gap-3 p-3">
        <div className="flex items-center gap-1">
          <Button variant="outline" size="icon" onClick={() => step(-1)} aria-label="Previous"><ChevronLeft /></Button>
          <Button variant="outline" onClick={() => setCursor(new Date())}>Today</Button>
          <Button variant="outline" size="icon" onClick={() => step(1)} aria-label="Next"><ChevronRight /></Button>
        </div>
        <div className="font-mono text-sm font-semibold">
          {view === "week" ? `${format(range.start, "MMM d")} – ${format(range.end, "MMM d, yyyy")}` : view === "agenda" ? `${format(range.start, "MMM yyyy")} – ${format(range.end, "MMM yyyy")}` : format(cursor, "MMMM yyyy")}
        </div>
        <label className="ml-auto flex items-center gap-2 text-sm">
          <Switch checked={showTeam} onCheckedChange={setShowTeam} /> Show my teams' task deadlines
        </label>
        <Tabs value={view} onValueChange={(v) => setView(v as typeof view)}>
          <TabsList><TabsTrigger value="month">Month</TabsTrigger><TabsTrigger value="week">Week</TabsTrigger><TabsTrigger value="agenda">Agenda</TabsTrigger></TabsList>
        </Tabs>
      </div>

      {view === "agenda" ? (
        (() => {
          const list = items.filter((i) => i.date >= range.start && i.date <= range.end);
          if (!list.length) return <EmptyState icon={<CalendarDays />} title="Nothing scheduled" description="Deadlines and events in the next three months will appear here." />;
          const byDay = new Map<string, Item[]>();
          list.forEach((i) => { const k = format(i.date, "yyyy-MM-dd"); byDay.set(k, [...(byDay.get(k) ?? []), i]); });
          return (
            <div className="panel divide-y">
              {[...byDay.entries()].map(([k, its]) => (
                <div key={k} className="grid gap-2 p-3 sm:grid-cols-[140px_1fr]">
                  <div className="font-mono text-sm font-semibold">{format(new Date(k + "T12:00:00"), "EEE, MMM d")}</div>
                  <div className="space-y-1.5">{its.map((i) => <Chip key={i.id} item={i} full />)}</div>
                </div>
              ))}
            </div>
          );
        })()
      ) : (
        <div className="window overflow-hidden">
          <div className="titlebar grid grid-cols-7 text-center font-mono text-[11px] font-semibold uppercase">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => <div key={d} className="py-1.5">{d}</div>)}
          </div>
          <div className="grid grid-cols-7">
            {days.map((d) => {
              const its = on(d);
              const today = isSameDay(d, new Date());
              return (
                <div
                  key={d.toISOString()}
                  className={cn("group border-b border-r p-1.5", view === "week" ? "min-h-64" : "min-h-24 sm:min-h-28", !isSameMonth(d, cursor) && view === "month" && "bg-muted/40 text-muted-foreground")}
                  onDoubleClick={() => { if (canCreate) { setNewDate(d); setEditing("new"); } }}
                >
                  <div className="mb-1 flex items-center justify-between">
                    <span className={cn("grid size-6 place-items-center rounded-sm font-mono text-xs", today && "border border-border-strong bg-highlight font-bold text-highlight-foreground")}>{format(d, "d")}</span>
                    {canCreate && <button className="hidden text-muted-foreground hover:text-foreground group-hover:block" aria-label={`Add event on ${format(d, "MMM d")}`} onClick={() => { setNewDate(d); setEditing("new"); }}><Plus className="size-3.5" /></button>}
                  </div>
                  <div className="space-y-1">
                    {its.slice(0, view === "week" ? 12 : 3).map((i) => <Chip key={i.id} item={i} />)}
                    {its.length > (view === "week" ? 12 : 3) && <button className="text-[10px] text-muted-foreground hover:underline" onClick={() => { setCursor(d); setView("agenda"); }}>+{its.length - 3} more</button>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      <div className="mt-4 flex flex-wrap gap-2 text-xs">
        {(Object.keys(KIND_LABEL) as Item["kind"][]).map((k) => <span key={k} className={cn("rounded-sm border px-1.5 py-0.5", KIND_STYLE[k])}>{KIND_LABEL[k]}</span>)}
      </div>
      <EventDialog editing={editing} defaultDate={newDate} onClose={() => setEditing(null)} />
    </div>
  );
}

function Chip({ item, full }: { item: Item; full?: boolean }) {
  return (
    <button onClick={item.onClick} title={`${KIND_LABEL[item.kind]}: ${item.title}`} className={cn("block w-full truncate rounded-sm border px-1.5 py-0.5 text-left text-[11px] leading-4 hover:brightness-95", KIND_STYLE[item.kind], full && "text-sm")}>
      {full && <span className="mr-2 font-mono text-[11px] opacity-80">{format(item.date, "h:mm a")}</span>}
      {item.title}
      {full && <span className="ml-2 text-[11px] opacity-70">· {KIND_LABEL[item.kind]}</span>}
    </button>
  );
}

const ORG = "__org";
function toLocalInput(d: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function EventDialog({ editing, defaultDate, onClose }: { editing: CalEvent | "new" | null; defaultDate: Date | null; onClose: () => void }) {
  const me = useMe();
  const qc = useQueryClient();
  const { teams, teamById } = useLookup();
  const manageable = teams.filter((t) => !t.archived && canManageTeam(me, t.id));
  const ev = editing && editing !== "new" ? editing : null;
  const canEdit = !ev || (ev.team_id ? canManageTeam(me, ev.team_id) : me.isAdmin);
  const [f, setF] = useState({ title: "", description: "", kind: "event", start: "", end: "", location: "", team: ORG });
  useEffect(() => {
    if (!editing) return;
    const base = defaultDate ? new Date(defaultDate) : new Date();
    if (!ev) base.setHours(18, 0, 0, 0);
    setF({
      title: ev?.title ?? "",
      description: ev?.description ?? "",
      kind: ev?.kind ?? "event",
      start: toLocalInput(ev ? new Date(ev.starts_at) : base),
      end: ev?.ends_at ? toLocalInput(new Date(ev.ends_at)) : "",
      location: ev?.location ?? "",
      team: ev ? ev.team_id ?? ORG : me.isAdmin ? ORG : manageable[0]?.id ?? ORG,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!f.title.trim() || !f.start) { toast.error("Title and start time are required"); return; }
    const payload = {
      title: f.title.trim(),
      description: f.description.trim() || null,
      kind: f.kind as CalEvent["kind"],
      starts_at: new Date(f.start).toISOString(),
      ends_at: f.end ? new Date(f.end).toISOString() : null,
      location: f.location.trim() || null,
      team_id: f.team === ORG ? null : f.team,
    };
    const { error } = ev ? await supabase.from("events").update(payload).eq("id", ev.id) : await supabase.from("events").insert({ ...payload, created_by: me.id });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(ev ? "Event updated" : "Event created");
    qc.invalidateQueries({ queryKey: ["events"] });
    onClose();
  }
  async function del() {
    if (!ev) return;
    const { error } = await supabase.from("events").delete().eq("id", ev.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Event deleted");
    qc.invalidateQueries({ queryKey: ["events"] });
    onClose();
  }

  if (ev && !canEdit) {
    return (
      <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
        <DialogContent>
          <DialogHeader><DialogTitle>{ev.title}</DialogTitle></DialogHeader>
          <div className="space-y-2 text-sm">
            <p className="font-mono text-xs text-muted-foreground">{fmtDateTime(ev.starts_at, me.profile.timezone)}{ev.ends_at && ` – ${fmtDateTime(ev.ends_at, me.profile.timezone)}`}</p>
            <p>{ev.team_id ? teamById.get(ev.team_id)?.name : "Organization-wide"} · {ev.kind}</p>
            {ev.location && <p>📍 {ev.location}</p>}
            {ev.description && <p className="whitespace-pre-wrap text-muted-foreground">{ev.description}</p>}
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>{ev ? "Edit event" : "New event"}</DialogTitle></DialogHeader>
        <form onSubmit={save} className="space-y-4">
          <div className="space-y-1.5"><Label htmlFor="e-t">Title</Label><Input id="e-t" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={f.kind} onValueChange={(v) => setF({ ...f, kind: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="meeting">Team meeting</SelectItem>
                  <SelectItem value="milestone">Milestone</SelectItem>
                  <SelectItem value="deadline">Deadline</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Audience</Label>
              <Select value={f.team} onValueChange={(v) => setF({ ...f, team: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {me.isAdmin && <SelectItem value={ORG}>Organization-wide</SelectItem>}
                  {manageable.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label htmlFor="e-s">Starts</Label><Input id="e-s" type="datetime-local" value={f.start} onChange={(e) => setF({ ...f, start: e.target.value })} required /></div>
            <div className="space-y-1.5"><Label htmlFor="e-e">Ends (optional)</Label><Input id="e-e" type="datetime-local" value={f.end} onChange={(e) => setF({ ...f, end: e.target.value })} /></div>
          </div>
          <div className="space-y-1.5"><Label htmlFor="e-l">Location or meeting link</Label><Input id="e-l" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="e-d">Details</Label><Textarea id="e-d" rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <DialogFooter className="gap-2">
            {ev && <ConfirmAction trigger={<Button type="button" variant="ghost" className="mr-auto"><Trash2 /> Delete</Button>} title="Delete this event?" confirmLabel="Delete" destructive onConfirm={del} />}
            <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
            <Button type="submit">Save</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
