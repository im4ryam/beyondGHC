import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Crown, UsersRound } from "lucide-react";
import { membersQuery, projectsQuery, tasksQuery, useLookup, useMe } from "@/lib/queries";
import { teamColor } from "@/lib/format";
import { EmptyState, PageHeader, ProgressBar, UserAvatar } from "@/components/app/bits";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/teams/")({
  head: () => ({ meta: [{ title: "My Teams — Beyond GHC" }, { name: "description", content: "The teams you belong to." }, { property: "og:title", content: "My Teams — Beyond GHC" }, { property: "og:description", content: "The teams you belong to." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: TeamsPage,
});

function TeamsPage() {
  const me = useMe();
  const members = useQuery(membersQuery).data ?? [];
  const tasks = useQuery(tasksQuery).data ?? [];
  const projects = useQuery(projectsQuery).data ?? [];
  const { teams, profileById } = useLookup();
  const visible = teams.filter((t) => !t.archived && (me.isAdmin || me.teamIds.includes(t.id)));

  return (
    <div>
      <PageHeader eyebrow="Teams" title={me.isAdmin ? "All teams" : "My teams"} description="Open a team to see its members, objectives, projects, resources and announcements." />
      {visible.length === 0 ? (
        <EmptyState icon={<UsersRound />} title="You're not on a team yet" description="An administrator will assign you to one or more teams. You'll get a notification when that happens." />
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {visible.map((t) => {
            const ms = members.filter((m) => m.team_id === t.id);
            const leads = ms.filter((m) => m.is_lead);
            const tt = tasks.filter((x) => x.team_id === t.id);
            const pct = tt.length ? Math.round((tt.filter((x) => x.status === "completed").length / tt.length) * 100) : 0;
            const c = teamColor(t.color);
            const mine = me.memberships.find((m) => m.team_id === t.id);
            return (
              <Link key={t.id} to="/teams/$teamId" params={{ teamId: t.id }} className="window group block overflow-hidden transition-transform hover:-translate-y-0.5">
                <div className={cn("h-1.5", c.dot)} />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="text-lg font-semibold group-hover:underline">{t.name}</h2>
                    {mine?.is_lead && <span className="eyebrow flex items-center gap-1 text-highlight"><Crown className="size-3" /> Lead</span>}
                  </div>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{t.description}</p>
                  <div className="mt-4 flex items-center justify-between gap-3">
                    <div className="flex -space-x-1.5">
                      {ms.slice(0, 6).map((m) => {
                        const p = profileById.get(m.user_id);
                        return <UserAvatar key={m.id} name={p?.full_name} url={p?.avatar_url} size="sm" />;
                      })}
                      {ms.length > 6 && <span className="grid size-6 place-items-center rounded-md border bg-muted font-mono text-[10px]">+{ms.length - 6}</span>}
                    </div>
                    <span className="font-mono text-xs text-muted-foreground">{ms.length} members · {projects.filter((p) => p.team_id === t.id && p.status === "active").length} active projects</span>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">Lead{leads.length === 1 ? "" : "s"}: {leads.length ? leads.map((l) => profileById.get(l.user_id)?.full_name ?? "—").join(", ") : "not assigned yet"}</div>
                  <ProgressBar className="mt-3" value={pct} label={`${t.name} task completion`} />
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
