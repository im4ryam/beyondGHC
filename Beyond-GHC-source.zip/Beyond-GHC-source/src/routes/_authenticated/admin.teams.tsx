import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Archive, ArchiveRestore, Crown, Pencil, Plus, Trash2, UserMinus, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { membersQuery, profilesQuery, teamsQuery, type Team } from "@/lib/queries";
import { TEAM_COLORS, errMsg, teamColor } from "@/lib/format";
import { ConfirmAction, PageHeader, UserAvatar } from "@/components/app/bits";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/teams")({
  head: () => ({ meta: [{ title: "Manage Teams — Admin — Beyond GHC" }, { name: "description", content: "Create, edit and staff teams." }, { property: "og:title", content: "Manage Teams — Admin — Beyond GHC" }, { property: "og:description", content: "Create, edit and staff teams." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: AdminTeams,
});

function AdminTeams() {
  const qc = useQueryClient();
  const teams = useQuery(teamsQuery).data ?? [];
  const members = useQuery(membersQuery).data ?? [];
  const profiles = useQuery(profilesQuery).data ?? [];
  const [editing, setEditing] = useState<Team | "new" | null>(null);
  const [adding, setAdding] = useState<Record<string, string>>({});

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["teams"] });
    qc.invalidateQueries({ queryKey: ["team_members"] });
    qc.invalidateQueries({ queryKey: ["me"] });
  };
  async function membership(team: string, user: string, member: boolean, lead = false) {
    const { error } = await supabase.rpc("set_team_membership", { _team: team, _user: user, _member: member, _lead: lead });
    if (error) { toast.error(errMsg(error)); return; }
    refresh();
  }
  async function archive(t: Team, v: boolean) {
    const { error } = await supabase.from("teams").update({ archived: v }).eq("id", t.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(v ? "Team archived" : "Team restored");
    refresh();
  }
  async function del(t: Team) {
    const { error } = await supabase.from("teams").delete().eq("id", t.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Team deleted");
    refresh();
  }

  return (
    <div>
      <PageHeader crumbs={[{ label: "Admin", to: "/admin" }, { label: "Manage Teams" }]} title="Manage teams" description="Add, rename, archive and staff teams. Archiving hides a team from everyday use but keeps its history." actions={<Button onClick={() => setEditing("new")}><Plus /> New team</Button>} />
      <div className="space-y-5">
        {teams.map((t) => {
          const ms = members.filter((m) => m.team_id === t.id).sort((a, b) => Number(b.is_lead) - Number(a.is_lead));
          const candidates = profiles.filter((p) => p.status === "active" && !ms.some((m) => m.user_id === p.id));
          return (
            <section key={t.id} className={cn("window overflow-hidden", t.archived && "opacity-70")}>
              <div className={cn("h-1.5", teamColor(t.color).dot)} />
              <div className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="flex items-center gap-2 text-lg font-semibold"><Link to="/teams/$teamId" params={{ teamId: t.id }} className="hover:underline">{t.name}</Link>{t.archived && <Badge variant="slate">Archived</Badge>}</h2>
                    <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{t.description}</p>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" onClick={() => setEditing(t)}><Pencil /> Edit</Button>
                    {t.archived ? (
                      <Button size="sm" variant="ghost" onClick={() => archive(t, false)}><ArchiveRestore /> Restore</Button>
                    ) : (
                      <ConfirmAction trigger={<Button size="sm" variant="ghost"><Archive /> Archive</Button>} title={`Archive ${t.name}?`} description="Members keep their history. The team disappears from everyday menus until restored." confirmLabel="Archive" onConfirm={() => archive(t, true)} />
                    )}
                    <ConfirmAction trigger={<Button size="sm" variant="ghost" aria-label="Delete team"><Trash2 /></Button>} title={`Permanently delete ${t.name}?`} description="This deletes the team's projects, tasks, resources and announcements. Archiving is strongly recommended instead." confirmLabel="Delete forever" destructive onConfirm={() => del(t)} />
                  </div>
                </div>
                <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {ms.map((m) => {
                    const p = profiles.find((x) => x.id === m.user_id);
                    return (
                      <div key={m.id} className="flex items-center justify-between gap-2 rounded-md border bg-card px-2.5 py-1.5 text-sm">
                        <span className="flex min-w-0 items-center gap-2"><UserAvatar name={p?.full_name} url={p?.avatar_url} size="sm" /><span className="truncate">{p?.full_name ?? "—"}</span>{m.is_lead && <Crown className="size-3.5 shrink-0 text-highlight" aria-label="Team lead" />}</span>
                        <span className="flex shrink-0">
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => membership(t.id, m.user_id, true, !m.is_lead)}>{m.is_lead ? "Remove lead" : "Make lead"}</Button>
                          <Button size="icon" variant="ghost" className="size-7" aria-label={`Remove ${p?.full_name}`} onClick={() => membership(t.id, m.user_id, false)}><UserMinus /></Button>
                        </span>
                      </div>
                    );
                  })}
                  {ms.length === 0 && <p className="text-sm text-muted-foreground">No members yet.</p>}
                </div>
                <div className="mt-3 flex max-w-md gap-2">
                  <Select value={adding[t.id] ?? ""} onValueChange={(v) => setAdding({ ...adding, [t.id]: v })}>
                    <SelectTrigger aria-label="Add member"><SelectValue placeholder={candidates.length ? "Add an active member…" : "Everyone active is already on this team"} /></SelectTrigger>
                    <SelectContent>{candidates.map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}</SelectContent>
                  </Select>
                  <Button variant="outline" disabled={!adding[t.id]} onClick={async () => { await membership(t.id, adding[t.id]!, true); setAdding({ ...adding, [t.id]: "" }); }}><UserPlus /> Add</Button>
                </div>
              </div>
            </section>
          );
        })}
      </div>
      <TeamDialog editing={editing} onClose={() => setEditing(null)} onSaved={refresh} />
    </div>
  );
}

function TeamDialog({ editing, onClose, onSaved }: { editing: Team | "new" | null; onClose: () => void; onSaved: () => void }) {
  const t = editing && editing !== "new" ? editing : null;
  const [f, setF] = useState({ name: "", description: "", objectives: "", color: "blue" });
  useEffect(() => {
    if (editing) setF({ name: t?.name ?? "", description: t?.description ?? "", objectives: t?.objectives ?? "", color: t?.color ?? "blue" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!f.name.trim()) { toast.error("Name is required"); return; }
    const payload = { name: f.name.trim(), description: f.description.trim() || null, objectives: f.objectives.trim() || null, color: f.color };
    const { error } = t ? await supabase.from("teams").update(payload).eq("id", t.id) : await supabase.from("teams").insert(payload);
    if (error) { toast.error(error.code === "23505" ? "A team with that name already exists" : errMsg(error)); return; }
    toast.success(t ? "Team updated" : "Team created");
    onSaved();
    onClose();
  }
  return (
    <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>{t ? "Edit team" : "New team"}</DialogTitle></DialogHeader>
        <form onSubmit={save} className="space-y-4">
          <div className="space-y-1.5"><Label htmlFor="tm-n">Name</Label><Input id="tm-n" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required /></div>
          <div className="space-y-1.5"><Label htmlFor="tm-d">Description / responsibilities</Label><Textarea id="tm-d" rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="tm-o">Objectives (one per line)</Label><Textarea id="tm-o" rows={3} value={f.objectives} onChange={(e) => setF({ ...f, objectives: e.target.value })} /></div>
          <div className="space-y-1.5">
            <Label>Color</Label>
            <div className="flex gap-2">
              {Object.entries(TEAM_COLORS).map(([k, c]) => (
                <button type="button" key={k} aria-label={k} onClick={() => setF({ ...f, color: k })} className={cn("size-7 rounded-sm border-2", c.dot, f.color === k ? "border-border-strong shadow-pixel-sm" : "border-transparent")} />
              ))}
            </div>
          </div>
          <DialogFooter><Button type="button" variant="ghost" onClick={onClose}>Cancel</Button><Button type="submit">Save</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
