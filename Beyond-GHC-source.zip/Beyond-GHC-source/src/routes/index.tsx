import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CheckSquare, ListChecks, Megaphone, ShieldCheck, UsersRound, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/app/shell";
import hero from "@/assets/hero-retro-desk.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Beyond GHC — Volunteer Portal" },
      {
        name: "description",
        content: "Where Beyond GHC founders, team leads and volunteers coordinate projects, tasks, announcements and events.",
      },
      { property: "og:title", content: "Beyond GHC — Volunteer Portal" },
      {
        property: "og:description",
        content: "Where Beyond GHC founders, team leads and volunteers coordinate projects, tasks, announcements and events.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { icon: <CheckSquare />, title: "Personal task checklist", body: "Every volunteer sees exactly what's on their plate, what's due soon, and what's waiting for review." },
  { icon: <ListChecks />, title: "Shared team checklists", body: "Projects break down into assignable items, with progress that updates as work gets done." },
  { icon: <UsersRound />, title: "Four working teams", body: "Programs & Speakers, Community, Marketing, and Operations — each with its own space." },
  { icon: <Megaphone />, title: "Announcements", body: "Organization-wide and team updates, pinned where everyone will see them." },
  { icon: <CalendarDays />, title: "One calendar", body: "Deadlines, meetings and events in month, week or agenda view." },
  { icon: <ShieldCheck />, title: "Private by default", body: "People only see the teams and member information their role needs." },
];

function Landing() {
  const navigate = useNavigate();
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: "/dashboard", replace: true }); });
  }, [navigate]);
  return (
    <div className="bg-grid min-h-screen bg-background">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <Logo name="Beyond GHC" />
        <Button asChild variant="outline"><Link to="/auth">Sign in</Link></Button>
      </header>

      <main>
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-6 pb-16 pt-8 lg:grid-cols-[1.05fr_1fr] lg:pt-16">
          <div className="animate-rise">
            <div className="eyebrow text-highlight">Volunteer portal · v1.0</div>
            <h1 className="mt-3 text-4xl font-semibold leading-[1.1] text-foreground sm:text-5xl">
              The back office for a community that runs on volunteers.
            </h1>
            <p className="mt-4 max-w-lg text-lg text-muted-foreground">
              Beyond GHC is an independent, community-led virtual tech community. This is where our founders, team leads and volunteers plan sessions, track projects and keep each other in the loop.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild size="lg"><Link to="/auth">Sign in to the portal</Link></Button>
              <Button asChild size="lg" variant="ghost"><Link to="/forgot-password">Forgot password?</Link></Button>
            </div>
            <p className="mt-4 font-mono text-xs text-muted-foreground">
              Access is by invitation. Filling out the interest form does not create an account — an administrator reviews every submission.
            </p>
          </div>
          <div className="window overflow-hidden">
            <div className="titlebar flex items-center gap-2 px-3 py-1.5">
              <span className="flex gap-1" aria-hidden>
                <span className="size-2 border border-border-strong bg-highlight" />
                <span className="size-2 border border-border-strong bg-card" />
              </span>
              <span className="font-mono text-xs font-semibold uppercase">workspace.exe</span>
            </div>
            <img src={hero} alt="Illustration of a retro desktop computer showing a task checklist, surrounded by app windows and a calendar" width={1408} height={1056} className="block h-auto w-full" />
          </div>
        </section>

        <section className="border-y bg-card/60">
          <div className="mx-auto grid max-w-6xl gap-px bg-border px-0 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-card p-6">
                <div className="grid size-9 place-items-center rounded-sm border border-border-strong bg-secondary text-secondary-foreground shadow-pixel-sm [&_svg]:size-4">{f.icon}</div>
                <h2 className="mt-3 font-semibold">{f.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{f.body}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="mx-auto max-w-6xl px-6 py-8 font-mono text-xs text-muted-foreground">
        © {new Date().getFullYear()} Beyond GHC · Independent and community-led
      </footer>
    </div>
  );
}
