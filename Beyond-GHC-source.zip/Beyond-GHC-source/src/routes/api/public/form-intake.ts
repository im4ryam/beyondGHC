import { createFileRoute } from "@tanstack/react-router";
import { mapRecord } from "@/lib/submission-mapping";

async function sha256(s: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
}

function flatten(rec: Record<string, unknown>) {
  // Google Apps Script e.namedValues gives { "Question": ["answer"] }
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(rec)) out[k] = Array.isArray(v) ? v.join(", ") : v;
  return out;
}

/**
 * Receives new interest-form responses (Google Forms via Apps Script, Microsoft Forms via Power Automate,
 * or any tool that can POST JSON). Requires the secret key from Admin → Integrations.
 * Never creates a login — submissions land in the admin review queue.
 */
export const Route = createFileRoute("/api/public/form-intake")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = request.headers.get("x-intake-key") ?? new URL(request.url).searchParams.get("key") ?? "";
        if (!key || key.length < 20) return Response.json({ error: "Missing key" }, { status: 401 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: setting } = await supabaseAdmin.from("integration_settings").select("value").eq("key", "form_intake").maybeSingle();
        const cfg = (setting?.value as Record<string, unknown>) ?? {};
        if (!cfg["key_hash"] || cfg["enabled"] === false) return Response.json({ error: "Intake disabled" }, { status: 403 });
        if ((await sha256(key)) !== cfg["key_hash"]) return Response.json({ error: "Invalid key" }, { status: 401 });

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "Body must be JSON" }, { status: 400 });
        }
        const records = (Array.isArray(body) ? body : [body]).filter((r): r is Record<string, unknown> => !!r && typeof r === "object").slice(0, 500);
        if (!records.length) return Response.json({ error: "No records" }, { status: 400 });

        const source = String(cfg["source_label"] ?? "form_integration");
        const results: Record<string, number> = { inserted: 0, updated: 0, duplicates: 0, skipped: 0 };
        for (const r of records) {
          const row = mapRecord(flatten(r));
          const { data, error } = await supabaseAdmin.rpc("upsert_submission", { _row: row, _source: source });
          if (error) {
            results["skipped"] = (results["skipped"] ?? 0) + 1;
            continue;
          }
          const k = data === "duplicate" ? "duplicates" : String(data);
          results[k] = (results[k] ?? 0) + 1;
        }
        await supabaseAdmin
          .from("integration_settings")
          .update({ value: { ...cfg, last_received_at: new Date().toISOString(), last_result: results } })
          .eq("key", "form_intake");
        return Response.json({ ok: true, ...results });
      },
    },
  },
});
